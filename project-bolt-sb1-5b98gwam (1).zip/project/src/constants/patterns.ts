import { Pattern } from '@/types/patterns';

export const naturalToAi: Record<string, string> = {
  '0': '5', '1': '7', '2': '9', '3': '1', '4': '3',
  '5': '5', '6': '7', '7': '9', '8': '1', '9': '3'
};

export const aiBasePairs: Record<string, string> = {
  '1': '11,13,15',
  '3': '33,35,37',
  '5': '55,57,59',
  '7': '77,79,71',
  '9': '99,91,93'
};

export const patterns: Pattern[] = [
  {
    name: 'Neutral N',
    color: 'bg-red-500',
    example: '123',
    aiConverted: '791',
    rules: ['Numbers in sequential order', 'Same row height']
  },
  {
    name: 'Bottom Up BUC',
    color: 'bg-amber-300',
    example: '456',
    aiConverted: '357',
    rules: ['First number higher', 'Last two same level']
  },
  {
    name: 'Top Up TUC',
    color: 'bg-blue-400',
    example: '789',
    aiConverted: '913',
    rules: ['Ascending pattern', 'Top two numbers same level']
  },
  {
    name: 'Triangle↓ TD',
    color: 'bg-gray-400',
    example: '147',
    aiConverted: '791',
    rules: ['Middle number lower', 'First and last same level']
  },
  {
    name: 'Triangle↑ TU',
    color: 'bg-gray-700',
    example: '369',
    aiConverted: '193',
    rules: ['Middle number higher', 'First and last same level']
  },
  {
    name: 'Slash Up SU',
    color: 'bg-green-200',
    example: '258',
    aiConverted: '951',
    rules: ['Ascending diagonal', 'Each number higher than last']
  },
  {
    name: 'Slash Down SD',
    color: 'bg-orange-300',
    example: '741',
    aiConverted: '937',
    rules: ['Descending diagonal', 'Each number lower than last']
  },
  {
    name: 'Top Down TDC',
    color: 'bg-green-500',
    example: '963',
    aiConverted: '351',
    rules: ['First two numbers same level', 'Last number lower']
  },
  {
    name: 'Bottom Down BDC',
    color: 'bg-purple-600',
    example: '852',
    aiConverted: '159',
    rules: ['Last two numbers same level', 'First number higher']
  }
];