import { CoreShapes } from '@/types/shapes';

export const naturalToAI: Record<string, string> = {
  '0': '5', '1': '7', '2': '9', '3': '1', '4': '3',
  '5': '5', '6': '7', '7': '9', '8': '1', '9': '3'
};

export const coreShapes: CoreShapes = {
  'Neutral N': {
    color: 'bg-red-500',
    cells: [
      { row: 1, col: 0, num: '1' },
      { row: 1, col: 1, num: '2' },
      { row: 1, col: 2, num: '3' }
    ]
  },
  'Bottom Up': {
    color: 'bg-amber-300',
    cells: [
      { row: 2, col: 0, num: '1' },
      { row: 1, col: 1, num: '2' },
      { row: 1, col: 2, num: '3' }
    ]
  },
  'Top Up': {
    color: 'bg-blue-400',
    cells: [
      { row: 1, col: 0, num: '1' },
      { row: 1, col: 1, num: '2' },
      { row: 0, col: 2, num: '3' }
    ]
  },
  'Triangle↓': {
    color: 'bg-gray-400',
    cells: [
      { row: 1, col: 0, num: '1' },
      { row: 2, col: 1, num: '2' },
      { row: 1, col: 2, num: '3' }
    ]
  },
  'Triangle↑': {
    color: 'bg-gray-700',
    cells: [
      { row: 1, col: 0, num: '1' },
      { row: 0, col: 1, num: '2' },
      { row: 1, col: 2, num: '3' }
    ]
  },
  'Slash Up': {
    color: 'bg-green-200',
    cells: [
      { row: 2, col: 0, num: '1' },
      { row: 1, col: 1, num: '2' },
      { row: 0, col: 2, num: '3' }
    ]
  },
  'Slash Down': {
    color: 'bg-orange-300',
    cells: [
      { row: 0, col: 0, num: '1' },
      { row: 1, col: 1, num: '2' },
      { row: 2, col: 2, num: '3' }
    ]
  },
  'Top Down': {
    color: 'bg-green-500',
    cells: [
      { row: 0, col: 0, num: '1' },
      { row: 0, col: 1, num: '2' },
      { row: 1, col: 2, num: '3' }
    ]
  },
  'Bottom Down': {
    color: 'bg-purple-600',
    cells: [
      { row: 1, col: 0, num: '1' },
      { row: 2, col: 1, num: '2' },
      { row: 2, col: 2, num: '3' }
    ]
  }
};