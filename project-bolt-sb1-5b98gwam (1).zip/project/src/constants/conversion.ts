export const naturalToAi: Record<string, string> = {
  '0': '5', '1': '7', '2': '9', '3': '1', '4': '3',
  '5': '5', '6': '7', '7': '9', '8': '1', '9': '3'
};

export const aiBasePairs: Record<string, string> = {
  '1': '11,13,15',
  '3': '33,35,37',
  '5': '55,57,59',
  '7': '77,79,71',
  '9': '99,91,93'
};

export const lArray: Record<string, string> = {
  '5': '0', '7': '1', '9': '2', '1': '3', '3': '4'
};

export const hArray: Record<string, string> = {
  '5': '5', '7': '6', '9': '7', '1': '8', '3': '9'
};