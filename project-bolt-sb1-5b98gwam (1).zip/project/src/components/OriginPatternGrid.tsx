import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { detectShapes } from '@/lib/shapes/shapeDetector';

interface OriginPatternGridProps {
  input: string;
  output: string;
}

export const OriginPatternGrid: React.FC<OriginPatternGridProps> = ({ input, output }) => {
  const generateGrid = () => {
    const grid = Array(10).fill(null).map(() => Array(4).fill(''));
    
    // Fill the grid with sequential numbers
    for (let row = 0; row < 10; row++) {
      for (let col = 0; col < 4; col++) {
        if (col === 3) {
          // Last column shows the AI conversion
          const naturalValue = grid[row][0];
          grid[row][col] = {
            '0': '5', '1': '7', '2': '9', '3': '1', '4': '3',
            '5': '5', '6': '7', '7': '9', '8': '1', '9': '3'
          }[naturalValue] || '';
        } else {
          // First three columns show sequential numbers
          const value = ((parseInt(input[col] || '0') + row) % 10).toString();
          grid[row][col] = value;
        }
      }
    }
    
    return grid;
  };

  const grid = generateGrid();
  const baseRow = Math.floor(grid.length / 2);

  // Detect shape pattern in output
  const outputShapes = output ? detectShapes(output) : [];
  const dominantShape = outputShapes.length > 0 ? outputShapes[0] : null;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="font-medium mb-2">Pattern Properties</div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Base Row</span>
              <Badge variant="secondary">{baseRow}</Badge>
            </div>
            <div className="flex justify-between">
              <span>Pattern Type</span>
              <Badge variant="secondary">
                {dominantShape ? dominantShape.name : 'Unknown'}
              </Badge>
            </div>
            <div className="flex justify-between">
              <span>Shape Confidence</span>
              <Badge variant="secondary">
                {dominantShape ? `${(dominantShape.confidence * 100).toFixed(0)}%` : 'N/A'}
              </Badge>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="font-medium mb-2">Pattern Transformation</div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Input → Output</span>
              <Badge variant="outline">
                {input} → {output || 'N/A'}
              </Badge>
            </div>
            {dominantShape && (
              <div className="flex justify-between">
                <span>Shape Pattern</span>
                <Badge variant="success">{dominantShape.name}</Badge>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="flex justify-center">
        <div className="flex">
          <div className="flex flex-col pr-2">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="h-8 flex items-center justify-end text-xs text-gray-500 w-4">
                {i}
              </div>
            ))}
          </div>
          <div className="border border-gray-300 rounded-lg overflow-hidden">
            {grid.map((row, rowIndex) => (
              <div key={rowIndex} className="flex">
                {row.map((cell, colIndex) => {
                  const isHighlighted = input.includes(cell);
                  const isPatternStart = cell === input[0];
                  const isAIColumn = colIndex === 3;
                  const isShapePosition = dominantShape?.positions.some(
                    ([r, c]) => r === rowIndex && c === colIndex
                  );
                  
                  return (
                    <div
                      key={colIndex}
                      className={`
                        w-8 h-8 border-r border-b border-gray-200
                        flex items-center justify-center text-sm font-mono
                        ${isHighlighted && !isAIColumn ? 'bg-blue-100 font-bold' : 'bg-white'}
                        ${isPatternStart && !isAIColumn ? 'ring-2 ring-blue-400' : ''}
                        ${isAIColumn ? 'bg-orange-50 text-orange-600' : ''}
                        ${rowIndex === baseRow ? 'border-t-2 border-gray-400' : ''}
                        ${isShapePosition ? 'bg-yellow-200 font-bold ring-2 ring-yellow-400' : ''}
                        transition-colors duration-200
                      `}
                    >
                      {cell}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="font-medium mb-2">Grid Legend</div>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-blue-100 border border-blue-200 rounded"></div>
              <span>Pattern Numbers</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-orange-50 border border-orange-200 rounded"></div>
              <span>AI Conversion</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 border-t-2 border-gray-400 rounded"></div>
              <span>Base Row</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-yellow-200 border border-yellow-400 rounded"></div>
              <span>Shape Pattern Match</span>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="font-medium mb-2">Pattern Analysis</div>
          <div className="space-y-1 text-sm">
            <div>• Base pattern starts at row {baseRow}</div>
            <div>• Numbers progress sequentially</div>
            <div>• Last column shows AI conversion</div>
            {dominantShape && dominantShape.reasons.map((reason, idx) => (
              <div key={idx}>• {reason}</div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};