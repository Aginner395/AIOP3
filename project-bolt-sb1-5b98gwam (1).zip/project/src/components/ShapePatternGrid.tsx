import React from 'react';
import { Card } from '@/components/ui/card';
import { naturalToAi } from '@/lib/ai/constants';

interface ShapePatternGridProps {
  pattern: string;
}

export const ShapePatternGrid: React.FC<ShapePatternGridProps> = ({ pattern }) => {
  const grid = Array(10).fill(null).map(() => Array(3).fill(''));
  const baseRow = 4; // Center row

  // Fill the grid
  pattern.split('').forEach((digit, col) => {
    for (let row = 0; row < 10; row++) {
      const offset = row - baseRow;
      const value = ((parseInt(digit) + offset + 10) % 10).toString();
      grid[row][col] = value;
    }
  });

  return (
    <Card className="p-6">
      <div className="space-y-6">
        <div className="grid grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-medium mb-4">Natural Pattern</h3>
            <div className="flex">
              <div className="flex flex-col pr-2">
                {[...Array(10)].map((_, i) => (
                  <div key={i} className="h-8 flex items-center justify-end text-xs text-gray-500 w-4">
                    {i}
                  </div>
                ))}
              </div>
              <div className="border border-gray-300 rounded-lg overflow-hidden">
                {grid.map((row, rowIndex) => (
                  <div key={rowIndex} className="flex">
                    {row.map((cell, colIndex) => (
                      <div
                        key={colIndex}
                        className={`
                          w-8 h-8 border-r border-b border-gray-200
                          flex items-center justify-center text-sm font-mono
                          ${rowIndex === baseRow ? 'bg-blue-100 font-bold' : 'bg-white'}
                        `}
                      >
                        {cell}
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-4">AI Conversion</h3>
            <div className="flex">
              <div className="flex flex-col pr-2">
                {[...Array(10)].map((_, i) => (
                  <div key={i} className="h-8 flex items-center justify-end text-xs text-gray-500 w-4">
                    {i}
                  </div>
                ))}
              </div>
              <div className="border border-gray-300 rounded-lg overflow-hidden">
                {grid.map((row, rowIndex) => (
                  <div key={rowIndex} className="flex">
                    {row.map((cell, colIndex) => (
                      <div
                        key={colIndex}
                        className={`
                          w-8 h-8 border-r border-b border-gray-200
                          flex items-center justify-center text-sm font-mono
                          ${rowIndex === baseRow ? 'bg-blue-100 font-bold' : 'bg-white'}
                        `}
                      >
                        {naturalToAi[cell]}
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8">
          <h3 className="text-lg font-medium mb-4">Pattern Information</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="font-medium mb-2">Natural Pattern</div>
              <div className="font-mono text-2xl">{pattern}</div>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="font-medium mb-2">AI Conversion</div>
              <div className="font-mono text-2xl">
                {pattern.split('').map(d => naturalToAi[d]).join('')}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};