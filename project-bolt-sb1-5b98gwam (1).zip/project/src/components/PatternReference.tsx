import { Card, CardContent } from "@/components/ui/card";
import { PatternList } from './PatternList';
import { patterns } from '@/constants/patterns';
import { useEffect, useState } from 'react';

interface PatternReferenceProps {
  input: string;
}

export const PatternReference = ({ input }: PatternReferenceProps) => {
  const [modifiedPatterns, setModifiedPatterns] = useState(patterns);

  useEffect(() => {
    if (input.length === 3) {
      const newPatterns = patterns.map(pattern => ({
        ...pattern,
        example: input
      }));
      setModifiedPatterns(newPatterns);
    } else {
      setModifiedPatterns(patterns);
    }
  }, [input]);

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-6">Pattern Reference Guide</h2>
        <PatternList patterns={modifiedPatterns} />
      </CardContent>
    </Card>
  );
};