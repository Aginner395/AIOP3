import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Copy, Check, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { naturalToAi, lArray, hArray } from '@/lib/ai/constants';
import { processAI1, processAI4, processAI6 } from '@/lib/ai/processors';
import { detectShapes } from '@/lib/shapes/shapeDetector';
import { PatternGrid } from './PatternGrid';
import { coreShapes } from '@/constants/shapes';

interface LHPatternAnalysisProps {
  input: string;
  output?: string;
}

interface PatternSet {
  original: string;
  variations: {
    lh: string;
    ll: string;
  };
  confidence: number;
  shapes: {
    lh: Array<{
      name: string;
      confidence: number;
      reasons: string[];
    }>;
    ll: Array<{
      name: string;
      confidence: number;
      reasons: string[];
    }>;
  };
  matchingVariation?: 'lh' | 'll';
  matchesOutput?: boolean;
}

export const LHPatternAnalysis: React.FC<LHPatternAnalysisProps> = ({ 
  input,
  output
}) => {
  const [copiedLH, setCopiedLH] = React.useState(false);
  const [copiedLL, setCopiedLL] = React.useState(false);
  const { toast } = useToast();

  const generateVariations = (pattern: string) => {
    const aiNumbers = pattern.split('').map(d => {
      if (Object.values(naturalToAi).includes(d)) return d;
      return naturalToAi[d];
    });

    const lowHighPairs = aiNumbers.map(aiNum => ({
      low: lArray[aiNum],
      high: hArray[aiNum]
    }));

    return {
      lh: lowHighPairs.map((pair, i) => 
        i === 0 ? pair.low : pair.high
      ).join(''),
      ll: lowHighPairs.map(pair => pair.low).join('')
    };
  };

  const getHighConfidencePrediction = (input: string): string | null => {
    if (input.length !== 3) return null;

    const allResults = [
      ...processAI1(input),
      ...processAI4(input),
      ...processAI6(input)
    ];

    const bestMatch = allResults.reduce((best, current) => {
      const currentConfidence = current.isKeyMatch ? 0.9 : 0.7;
      return best.confidence > currentConfidence ? best : {
        pattern: current.aiSet,
        confidence: currentConfidence
      };
    }, { pattern: '', confidence: 0 });

    return bestMatch.pattern || input.split('').map(d => naturalToAi[d]).join('');
  };

  const generatePatternSets = (pattern: string): PatternSet[] => {
    if (pattern.length !== 3) return [];

    const prediction = getHighConfidencePrediction(pattern);
    if (!prediction) return [];

    const [a, b, c] = prediction.split('');
    const sets = [
      prediction,              // Original prediction
      [a, c, b].join(''),     // Back pair inverted
      [b, a, c].join(''),     // First two swapped
      [c, b, a].join('')      // Reverse
    ];

    return sets.map((set, index) => {
      const variations = generateVariations(set);
      
      // Detect shapes for each variation
      const shapes = {
        lh: detectShapes(variations.lh),
        ll: detectShapes(variations.ll)
      };
      
      let matchingVariation: 'lh' | 'll' | undefined;
      if (output) {
        if (variations.lh === output) matchingVariation = 'lh';
        if (variations.ll === output) matchingVariation = 'll';
      }

      return {
        original: set,
        variations,
        confidence: index === 0 ? 0.95 : Math.max(0.7, 0.9 - (index * 0.1)),
        shapes,
        matchingVariation,
        matchesOutput: !!matchingVariation
      };
    });
  };

  const patternSets = React.useMemo(() => {
    return generatePatternSets(input);
  }, [input, output]);

  const matchingPatterns = patternSets.filter(set => set.matchesOutput);

  const copyVariationType = async (type: 'lh' | 'll') => {
    try {
      // Generate sequences for the grid
      const sequences = Array(10).fill(null).map(() => Array(3).fill(''));
      const firstFourSets = patternSets.slice(0, 4);
      
      // For each set, generate its sequence
      const allSequences = firstFourSets.map(set => {
        const pattern = set.variations[type];
        const baseRow = 1; // Center row
        const result = [];
        
        // Generate 10 rows for this pattern
        for (let row = 0; row < 10; row++) {
          const rowNumbers = pattern.split('').map(num => {
            const offset = row - baseRow;
            return ((parseInt(num) + offset + 10) % 10).toString();
          });
          result.push(rowNumbers.join(''));
        }
        
        return result;
      });

      // Flatten and join all sequences
      const allNumbers = allSequences.flat().join(' ');

      await navigator.clipboard.writeText(allNumbers);
      if (type === 'lh') {
        setCopiedLH(true);
        setTimeout(() => setCopiedLH(false), 2000);
      } else {
        setCopiedLL(true);
        setTimeout(() => setCopiedLL(false), 2000);
      }
      
      toast({
        title: "Copied!",
        description: `All ${type === 'lh' ? 'Green' : 'Blue'} sequences copied to clipboard`,
      });
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  const getVariationColor = (type: string, isMatch: boolean) => {
    const baseColors = {
      lh: 'bg-emerald-50 border-emerald-200',
      ll: 'bg-blue-50 border-blue-200'
    };
    
    if (isMatch) {
      return type === 'lh' 
        ? 'bg-emerald-100 border-emerald-500 ring-2 ring-emerald-500'
        : 'bg-blue-100 border-blue-500 ring-2 ring-blue-500';
    }
    
    return baseColors[type as keyof typeof baseColors] || 'bg-gray-50 border-gray-200';
  };

  if (patternSets.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-gray-500">
            Enter a valid 3-digit pattern to generate L/H variations
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div className="space-y-1">
              <h3 className="text-lg font-semibold">L/H Pattern Analysis</h3>
              <p className="text-sm text-gray-500">
                Low/High pattern variations (Sets 1-4) with Shape Analysis
              </p>
            </div>
            <div className="flex items-center gap-4">
              {output && (
                <Badge variant="secondary" className="text-base">
                  {matchingPatterns.length} {matchingPatterns.length === 1 ? 'match' : 'matches'} found
                </Badge>
              )}
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyVariationType('lh')}
                  className="transition-all duration-200 bg-emerald-50 hover:bg-emerald-100"
                >
                  {copiedLH ? (
                    <Check className="h-4 w-4 text-green-500" />
                  ) : (
                    <Copy className="h-4 w-4 text-emerald-600" />
                  )}
                  <span className="ml-2">{copiedLH ? 'Copied!' : 'Copy Green (LH)'}</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyVariationType('ll')}
                  className="transition-all duration-200 bg-blue-50 hover:bg-blue-100"
                >
                  {copiedLL ? (
                    <Check className="h-4 w-4 text-green-500" />
                  ) : (
                    <Copy className="h-4 w-4 text-blue-600" />
                  )}
                  <span className="ml-2">{copiedLL ? 'Copied!' : 'Copy Blue (LL)'}</span>
                </Button>
              </div>
            </div>
          </div>

          <div className="grid gap-4">
            {patternSets.slice(0, 4).map((set, idx) => (
              <div 
                key={idx} 
                className={`bg-white p-4 rounded-lg border border-gray-200 shadow-sm ${
                  set.matchesOutput ? 'ring-2 ring-green-500' : ''
                }`}
              >
                <div className="flex justify-between items-center mb-3">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Set {idx + 1}</Badge>
                    <span className="font-mono text-sm">
                      {input} <ArrowRight className="inline h-4 w-4" /> {set.original}
                    </span>
                    {set.matchesOutput && (
                      <Badge variant="success" className="animate-pulse">
                        Match Found: {set.matchingVariation?.toUpperCase()}
                      </Badge>
                    )}
                  </div>
                  <Badge variant="secondary">
                    {(set.confidence * 100).toFixed(0)}% confidence
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {Object.entries(set.variations).map(([type, value]) => (
                    <div key={type}>
                      <div 
                        className={`
                          flex justify-between items-center p-3 rounded-lg border mb-2
                          ${getVariationColor(type, type === set.matchingVariation)}
                          transition-all duration-300
                        `}
                      >
                        <div className="space-y-1">
                          <span className="text-xs font-medium uppercase">
                            {type}
                          </span>
                          <div className="font-mono text-lg">{value}</div>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <Badge variant="outline" className="ml-2">
                            {type.toUpperCase()}
                          </Badge>
                          {type === set.matchingVariation && (
                            <Badge variant="success" className="animate-pulse">
                              Match!
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      {/* Shape Display */}
                      <div className="mt-2 p-2 bg-gray-50 rounded-lg">
                        <div className="text-xs font-medium text-gray-500 mb-2">
                          Detected Shapes:
                        </div>
                        <div className="space-y-2">
                          {set.shapes[type as keyof typeof set.variations].map((shape, shapeIdx) => (
                            <div key={shapeIdx} className="flex justify-between items-center">
                              <span className="text-sm font-medium">{shape.name}</span>
                              <Badge variant="secondary" className="text-xs">
                                {(shape.confidence * 100).toFixed(0)}%
                              </Badge>
                            </div>
                          ))}
                          {set.shapes[type as keyof typeof set.variations].length === 0 && (
                            <div className="text-sm text-gray-500">No shapes detected</div>
                          )}
                        </div>
                      </div>

                      {/* Pattern Grid */}
                      <div className="mt-2 scale-75 origin-top-left">
                        <PatternGrid
                          pattern={{
                            cells: value.split('').map((num, idx) => ({
                              row: 1,
                              col: idx,
                              num
                            })),
                            color: type === 'lh' ? 'bg-emerald-100' : 'bg-blue-100'
                          }}
                          shapeName={type.toUpperCase()}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <h4 className="font-medium mb-2">Pattern Information</h4>
            <div className="grid grid-cols-3 gap-4">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-emerald-100 border border-emerald-200"></div>
                <span className="text-sm">LH - Low-High Pattern</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-blue-100 border border-blue-200"></div>
                <span className="text-sm">LL - All Low Numbers</span>
              </div>
              {output && (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded border-2 border-green-500"></div>
                  <span className="text-sm">Output Match</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};