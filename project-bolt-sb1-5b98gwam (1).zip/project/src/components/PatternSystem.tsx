import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { ShapeSelector } from './ShapeSelector';
import { PatternGrid } from './PatternGrid';
import { PatternSequences } from './PatternSequences';
import { coreShapes } from '@/constants/shapes';
import { useState, useEffect } from 'react';

interface PatternSystemProps {
  input: string;
}

export const PatternSystem = ({ input }: PatternSystemProps) => {
  const [selectedShape, setSelectedShape] = useState<string | null>(null);
  const [currentPattern, setCurrentPattern] = useState<any>(null);
  const [modifiedShapes, setModifiedShapes] = useState<any>(coreShapes);

  useEffect(() => {
    if (input.length === 3) {
      // Create a new pattern based on the input
      const pattern = {
        color: 'bg-blue-200',
        cells: input.split('').map((num, idx) => ({
          row: 1,
          col: idx,
          num: num
        }))
      };
      setCurrentPattern(pattern);

      // Update shapes with input
      const digits = input.split('');
      const newShapes = Object.entries(coreShapes).reduce((acc, [name, shape]) => {
        const newCells = shape.cells.map((cell, idx) => ({
          ...cell,
          num: digits[idx]
        }));
        acc[name] = { ...shape, cells: newCells };
        return acc;
      }, {} as any);
      setModifiedShapes(newShapes);
    } else {
      setCurrentPattern(null);
      setModifiedShapes(coreShapes);
    }
  }, [input]);

  return (
    <Card className="w-full max-w-7xl mx-auto">
      <CardContent className="p-8">
        <div className="space-y-8">
          {input.length === 3 && (
            <>
              {currentPattern && (
                <div className="flex justify-center gap-8">
                  <div>
                    <Label>Natural Pattern</Label>
                    <PatternGrid
                      pattern={currentPattern}
                      showConversion={false}
                      showInput={true}
                    />
                  </div>
                </div>
              )}

              <ShapeSelector
                shapes={modifiedShapes}
                selectedShape={selectedShape}
                onSelectShape={setSelectedShape}
              />

              {selectedShape && (
                <>
                  <div className="flex justify-center gap-8">
                    <div>
                      <Label>Pattern Shape</Label>
                      <PatternGrid
                        pattern={modifiedShapes[selectedShape]}
                        showConversion={false}
                        showInput={true}
                      />
                    </div>
                  </div>

                  <div className="mt-8">
                    <Label className="mb-4 block">Pattern Sequences</Label>
                    <PatternSequences pattern={input} rows={10} />
                  </div>
                </>
              )}
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
};