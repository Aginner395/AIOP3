import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { detectPatternTransition } from '@/lib/shapes/patternTransition';
import { PatternGrid } from './PatternGrid';
import { coreShapes } from '@/constants/shapes';

interface PatternTransitionProps {
  fromPattern: string;
  toPattern: string;
}

export const PatternTransition: React.FC<PatternTransitionProps> = ({
  fromPattern,
  toPattern
}) => {
  const transition = React.useMemo(
    () => detectPatternTransition(fromPattern, toPattern),
    [fromPattern, toPattern]
  );

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Pattern Transition Analysis</h3>
            <Badge variant="secondary">
              {transition.type.charAt(0).toUpperCase() + transition.type.slice(1)} Transition
            </Badge>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex justify-between items-center mb-4">
                <span className="font-medium">From: {transition.from}</span>
                <span className="text-sm text-gray-500">Original Pattern</span>
              </div>
              <div className="scale-75 origin-left">
                <PatternGrid pattern={coreShapes['Triangle↓']} />
              </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex justify-between items-center mb-4">
                <span className="font-medium">To: {transition.to}</span>
                <span className="text-sm text-gray-500">Transformed Pattern</span>
              </div>
              <div className="scale-75 origin-left">
                <PatternGrid pattern={coreShapes['Neutral N']} />
              </div>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex justify-between items-center mb-4">
              <span className="font-medium">Transition Analysis</span>
              <Badge variant="outline">
                {(transition.confidence * 100).toFixed(0)}% confidence
              </Badge>
            </div>

            <div className="space-y-4">
              <div>
                <div className="text-sm font-medium text-gray-500 mb-2">
                  Transition Characteristics
                </div>
                <ul className="space-y-1 text-sm">
                  {transition.reasons.map((reason, i) => (
                    <li key={i} className="text-gray-600">• {reason}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};