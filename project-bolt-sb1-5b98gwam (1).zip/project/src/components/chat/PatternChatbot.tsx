import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Bot, Send, User, Calculator, Shapes, Brain } from "lucide-react";
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { detectShapes } from "@/lib/shapes/shapeDetector";
import { processAI1, processAI4, processAI6 } from '@/lib/ai/processors';
import { naturalToAi } from '@/lib/ai/constants';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  type?: 'pattern' | 'shape' | 'ai' | 'general';
  matrix?: {
    title: string;
    data: string[][];
    highlight?: number[];
  };
  grid?: {
    natural: string[][];
    ai: string[][];
    repeatsAt: number[];
    outputPattern: string;
  };
}

interface PatternChatbotProps {
  currentPattern?: string;
}

export const PatternChatbot: React.FC<PatternChatbotProps> = ({ currentPattern }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "👋 Hello! I'm your Pattern Analysis Assistant. I can help you with:\n\n" +
        "1. 🔢 Pattern Analysis - Enter any 3-digit number\n" +
        "2. 📐 Shape Detection - Understand pattern formations\n" +
        "3. 🤖 AI Conversions - See how patterns transform\n" +
        "4. 📊 Predictions - Get pattern forecasts\n\n" +
        "What would you like to explore?",
      timestamp: new Date(),
      type: 'general'
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generatePatternGrids = (pattern: string) => {
    const naturalGrid: string[][] = Array(10).fill(null).map(() => Array(3).fill(''));
    const aiGrid: string[][] = Array(10).fill(null).map(() => Array(3).fill(''));
    const repeatsAt: number[] = [];
    
    // Generate natural grid using the AI converted pattern
    const aiConverted = pattern.split('').map(d => naturalToAi[d]).join('');
    const outputDigits = aiConverted.split('').map(Number);
    
    for (let row = 0; row < 10; row++) {
      for (let col = 0; col < 3; col++) {
        // Use output digits for natural grid
        naturalGrid[row][col] = ((outputDigits[col] + row) % 10).toString();
        
        // Generate AI conversion for the same position
        const naturalValue = naturalGrid[row][col];
        aiGrid[row][col] = naturalToAi[naturalValue];
      }
      
      // Check for pattern repetition in AI grid
      if (aiGrid[row].join('') === aiConverted) {
        repeatsAt.push(row);
      }
    }

    return {
      natural: naturalGrid,
      ai: aiGrid,
      repeatsAt,
      outputPattern: aiConverted
    };
  };

  const generateComputationMatrix = (pattern: string) => {
    const digits = pattern.split('').map(Number);
    const matrix: string[][] = [];
    const aiConverted = pattern.split('').map(d => naturalToAi[d]);
    
    // Header row
    matrix.push(['Operation', 'D1', 'D2', 'D3', 'Result', 'Type']);

    // Base pattern
    matrix.push(['Input', ...digits.map(String), pattern, 'Natural']);

    // AI Conversion
    matrix.push(['AI Conv', ...aiConverted, aiConverted.join(''), 'Transform']);

    // Neutral N specific transformations
    const neutralBase = digits.map(d => ((d + 4) % 10).toString());
    matrix.push(['Neutral N', ...neutralBase, neutralBase.join(''), 'Base']);

    // Horizontal progressions
    for (let i = 0; i < 3; i++) {
      const progression = digits.map(d => ((d + i) % 10).toString());
      matrix.push([`H+${i}`, ...progression, progression.join(''), 'Horizontal']);
    }

    // AI Progressions
    const aiSeq = aiConverted.map(d => ((parseInt(d) + 2) % 10).toString());
    matrix.push(['AI+2', ...aiSeq, aiSeq.join(''), 'Transform']);

    // Shape-based transformations
    const shapes = detectShapes(pattern);
    if (shapes.length > 0) {
      const shape = shapes[0];
      matrix.push(['Shape', 
        shape.name.slice(0,1), 
        shape.name.slice(1,2), 
        shape.name.slice(2,3), 
        shape.name,
        'Pattern'
      ]);
    }

    // AI Set matches
    const aiSets = [
      ...processAI1(pattern),
      ...processAI4(pattern),
      ...processAI6(pattern)
    ].filter(set => set.isKeyMatch).slice(0, 2);

    aiSets.forEach((set, idx) => {
      matrix.push([
        `AI Set ${idx + 1}`,
        ...set.aiSet.split(''),
        set.aiSet,
        'Key Match'
      ]);
    });

    return matrix;
  };

  const analyzePattern = (pattern: string) => {
    const shapes = detectShapes(pattern);
    const aiSets = [
      ...processAI1(pattern),
      ...processAI4(pattern),
      ...processAI6(pattern)
    ];
    
    const aiConversion = pattern.split('').map(d => naturalToAi[d]).join('');
    const matrix = generateComputationMatrix(pattern);
    const grids = generatePatternGrids(pattern);
    
    return {
      shapes,
      aiSets,
      aiConversion,
      matrix,
      grids
    };
  };

  const generateResponse = (userInput: string): { 
    content: string; 
    type: 'pattern' | 'shape' | 'ai' | 'general';
    matrix?: {
      title: string;
      data: string[][];
      highlight?: number[];
    };
    grid?: {
      natural: string[][];
      ai: string[][];
      repeatsAt: number[];
      outputPattern: string;
    };
  } => {
    if (userInput.includes('pattern') || /\d{3}/.test(userInput)) {
      const matches = userInput.match(/\d{3}/);
      const pattern = matches ? matches[0] : currentPattern;

      if (pattern) {
        const analysis = analyzePattern(pattern);
        const isNeutral = analysis.shapes.some(shape => shape.name === 'Neutral N');
        
        return {
          type: 'pattern',
          content: `
Here's my analysis of pattern ${pattern}:

1. **Shape Detection** 🔷
${analysis.shapes.map(shape => `- ${shape.name} (${(shape.confidence * 100).toFixed(0)}% confidence)
  ${shape.reasons.map(reason => `  • ${reason}`).join('\n')}`).join('\n')}

2. **AI Conversion** 🤖
${pattern} → ${analysis.aiConversion}

3. **AI Set Analysis** 📊
${analysis.aiSets.slice(0, 3).map(set => `- ${set.aiSet} (${set.isKeyMatch ? '🎯 Key Match' : 'Regular Set'})
  • LLL: ${set.patterns.lll}
  • LLH: ${set.patterns.llh}`).join('\n')}

Below you'll find the pattern grids showing natural and AI progressions, along with a computation matrix showing all transformations.
${isNeutral ? '\n**Note:** This pattern follows the Neutral N formation with horizontal progression.' : ''}

Would you like to explore any specific aspect in more detail?`,
          matrix: {
            title: 'Pattern Computation Matrix',
            data: analysis.matrix,
            highlight: isNeutral ? [1, 2, 3] : [1, 2, 8]
          },
          grid: analysis.grids
        };
      }
    }

    // Default response
    return {
      type: 'general',
      content: "I can help you with:\n\n" +
        "1. 🔢 Analyzing number patterns (enter any 3-digit number)\n" +
        "2. 📐 Understanding shape formations (Triangle, Slash, Neutral)\n" +
        "3. 🤖 Exploring AI conversions\n" +
        "4. 📊 Pattern predictions and transformations\n\n" +
        "What would you like to learn about?"
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate typing delay
    setTimeout(() => {
      const response = generateResponse(input);
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.content,
        timestamp: new Date(),
        type: response.type,
        matrix: response.matrix,
        grid: response.grid
      };

      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 500);
  };

  const getMessageIcon = (type?: string) => {
    switch (type) {
      case 'pattern':
        return <Calculator className="w-4 h-4" />;
      case 'shape':
        return <Shapes className="w-4 h-4" />;
      case 'ai':
        return <Brain className="w-4 h-4" />;
      default:
        return <Bot className="w-4 h-4" />;
    }
  };

  const renderGrid = (grid: string[][], title: string, highlightPattern: string) => (
    <div className="flex-1">
      <div className="text-sm font-medium mb-2">{title}</div>
      <div className="flex">
        <div className="flex flex-col pr-2">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="h-8 flex items-center justify-end text-xs text-gray-500 w-4">
              {i}
            </div>
          ))}
        </div>
        <div className="border border-gray-200 rounded-lg overflow-hidden">
          {grid.map((row, rowIndex) => (
            <div key={rowIndex} className="flex">
              {row.map((cell, colIndex) => {
                const isHighlighted = row.join('') === highlightPattern;
                return (
                  <div
                    key={colIndex}
                    className={`
                      w-8 h-8 border-r border-b border-gray-200
                      flex items-center justify-center text-sm font-mono
                      ${isHighlighted ? 'bg-blue-100 font-bold' : 'bg-white'}
                      transition-colors duration-200
                    `}
                  >
                    {cell}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderPatternGrids = (gridData: { 
    natural: string[][]; 
    ai: string[][]; 
    repeatsAt: number[]; 
    outputPattern: string;
  }) => (
    <div className="mt-4 space-y-4">
      <div className="flex gap-8">
        {renderGrid(gridData.natural, "Natural Pattern Grid", gridData.outputPattern)}
        {renderGrid(gridData.ai, "Output AI Pattern Grid", gridData.outputPattern)}
      </div>
      <div className="text-sm text-gray-600">
        Pattern repeats at rows: {gridData.repeatsAt.join(', ')}
      </div>
    </div>
  );

  const renderMatrix = (matrix: { title: string; data: string[][]; highlight?: number[] }) => (
    <div className="mt-4 bg-gray-50 p-4 rounded-lg overflow-x-auto">
      <div className="text-sm font-medium mb-2">{matrix.title}</div>
      <table className="min-w-full">
        <thead>
          <tr>
            {matrix.data[0].map((header, idx) => (
              <th key={idx} className="px-4 py-2 text-left text-sm font-medium text-gray-700 border border-gray-200">
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {matrix.data.slice(1).map((row, rowIndex) => (
            <tr key={rowIndex} className={`
              ${matrix.highlight?.includes(rowIndex + 1) ? 'bg-blue-50' : ''}
              hover:bg-gray-100 transition-colors
            `}>
              {row.map((cell, cellIndex) => (
                <td 
                  key={cellIndex}
                  className={`
                    px-4 py-2 border border-gray-200
                    ${cellIndex === 0 ? 'font-medium text-gray-700' : 'font-mono'}
                    ${cellIndex === 4 ? 'font-bold' : ''}
                    ${matrix.highlight?.includes(rowIndex + 1) ? 'text-blue-600' : ''}
                  `}
                >
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  return (
    <Card className="w-full h-[600px] flex flex-col">
      <CardContent className="p-4 flex-1 flex flex-col">
        <div className="flex items-center gap-2 mb-4">
          <Bot className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-semibold">Pattern Analysis Assistant</h2>
          {currentPattern && (
            <Badge variant="secondary" className="ml-auto">
              Current Pattern: {currentPattern}
            </Badge>
          )}
        </div>

        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex items-start gap-3 ${
                  message.role === 'assistant' ? 'flex-row' : 'flex-row-reverse'
                }`}
              >
                <Avatar className={`w-8 h-8 ${
                  message.role === 'assistant' 
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted'
                }`}>
                  {message.role === 'assistant' ? (
                    getMessageIcon(message.type)
                  ) : (
                    <User className="w-4 h-4" />
                  )}
                </Avatar>
                
                <div className={`
                  flex-1 rounded-lg p-4 text-sm
                  ${message.role === 'assistant' 
                    ? 'bg-muted' 
                    : 'bg-primary text-primary-foreground'
                  }
                `}>
                  <ReactMarkdown
                    remarkPlugins={[remarkGfm]}
                    components={{
                      p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
                      ul: ({ children }) => <ul className="list-disc pl-4 mb-2">{children}</ul>,
                      li: ({ children }) => <li className="mb-1">{children}</li>,
                      code: ({ children }) => (
                        <code className="bg-muted-foreground/20 rounded px-1">{children}</code>
                      )
                    }}
                  >
                    {message.content}
                  </ReactMarkdown>

                  {message.grid && renderPatternGrids(message.grid)}
                  {message.matrix && renderMatrix(message.matrix)}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Bot className="w-4 h-4 animate-pulse" />
                <span className="text-sm">Analyzing patterns...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        <form onSubmit={handleSubmit} className="mt-4 flex gap-2">
          <Input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about patterns, shapes, or enter a 3-digit number..."
            className="flex-1"
          />
          <Button type="submit" size="icon">
            <Send className="w-4 h-4" />
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};