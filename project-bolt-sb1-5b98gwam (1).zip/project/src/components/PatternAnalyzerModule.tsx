import React, { useState, useCallback, useMemo } from 'react';
import { Card } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { PatternGrid } from './PatternGrid';
import { naturalToAi } from '@/lib/ai/constants';
import { processAI1, processAI4, processAI6 } from '@/lib/ai/processors';

interface Props {
  instanceId: string;
  pattern: string;
  onAnalysisComplete?: (results: any) => void;
}

const aiColors = {
  ai1: {
    bg: 'bg-indigo-50',
    border: 'border-indigo-100',
    text: 'text-indigo-700',
    title: 'text-indigo-600'
  },
  ai4: {
    bg: 'bg-emerald-50',
    border: 'border-emerald-100',
    text: 'text-emerald-700',
    title: 'text-emerald-600'
  },
  ai6: {
    bg: 'bg-blue-50',
    border: 'border-blue-100',
    text: 'text-blue-700',
    title: 'text-blue-600'
  }
};

function getConcatenatedPattern(pattern: string): string {
  if (!pattern || pattern.length !== 3) return '';
  return Array(10).fill(0).map((_, i) => 
    pattern.split('').map(d => ((Number(d) + i) % 10).toString()).join('')
  ).join(' ');
}

export const PatternAnalyzerModule = React.memo(({ instanceId, pattern, onAnalysisComplete }: Props) => {
  const [selectedPattern, setSelectedPattern] = useState<{engine: string, pattern: string} | null>(null);

  // Memoize AI results to prevent recalculation
  const aiResults = useMemo(() => ({
    ai1: processAI1(pattern),
    ai4: processAI4(pattern),
    ai6: processAI6(pattern)
  }), [pattern]);

  const handlePatternClick = useCallback((engine: string, patternStr: string) => {
    setSelectedPattern(prev => 
      prev?.engine === engine && prev?.pattern === patternStr ? null : { engine, pattern: patternStr }
    );
  }, []);

  // Calculate total patterns once
  const totals = useMemo(() => 
    Object.entries(aiResults).reduce((acc, [engine, results]) => ({
      ...acc,
      [engine]: results.reduce((sum, set) => sum + Object.values(set.patterns).length, 0)
    }), {} as Record<string, number>)
  , [aiResults]);

  if (!pattern || pattern.length !== 3) return null;

  return (
    <div className="relative" data-instance-id={instanceId}>
      {Object.entries(aiResults).map(([aiType, results]) => (
        <Card key={aiType} className="mb-2 p-3">
          <div className="flex justify-between items-center mb-2">
            <h3 className={`text-sm font-semibold ${aiColors[aiType]?.title}`}>
              {aiType.toUpperCase()}
            </h3>
            <span className="text-xs text-gray-500">
              Total Sets: {totals[aiType]}
            </span>
          </div>

          {/* Concatenated Patterns */}
          <ScrollArea className="h-24 mb-2">
            <div className="text-xs font-mono space-y-1">
              {results.map((set, idx) => (
                <div key={idx} className="grid grid-cols-4 gap-1">
                  {Object.entries(set.patterns).map(([type, pattern]) => (
                    <div key={type} className="truncate">
                      <span className="text-gray-500">{type}:</span>
                      <span className="ml-1">{getConcatenatedPattern(pattern)}</span>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </ScrollArea>

          <div className="grid grid-cols-2 gap-2">
            {/* Pattern Sets */}
            <div className="grid grid-cols-2 gap-1">
              {results.map((set, idx) => (
                <div
                  key={idx}
                  onClick={() => handlePatternClick(aiType, set.aiSet)}
                  className={`${aiColors[aiType]?.bg} p-2 rounded cursor-pointer text-xs ${
                    selectedPattern?.engine === aiType && selectedPattern?.pattern === set.aiSet
                      ? 'ring-2 ring-blue-500'
                      : ''
                  }`}
                >
                  <div className="font-mono mb-1">{set.aiSet}</div>
                  <div className="grid grid-cols-2 gap-x-2 gap-y-0.5">
                    {Object.entries(set.patterns).map(([key, val]) => (
                      <div key={key}>{key}: {val}</div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Shape Visualization */}
            {selectedPattern?.engine === aiType && (
              <div className="bg-gray-50 p-2 rounded">
                <div className="grid grid-cols-2 gap-1">
                  {['LLL', 'LLH', 'LHL', 'LHH'].map((type) => {
                    const pattern = results.find(r => r.aiSet === selectedPattern.pattern)
                      ?.patterns[type.toLowerCase()];
                    return pattern ? (
                      <div key={type}>
                        <div className="text-[10px] font-medium text-gray-500 mb-0.5">{type}</div>
                        <PatternGrid 
                          pattern={pattern}
                          displayType="natural"
                          size="sm"
                        />
                      </div>
                    ) : null;
                  })}
                </div>
              </div>
            )}
          </div>
        </Card>
      ))}
    </div>
  );
});

PatternAnalyzerModule.displayName = 'PatternAnalyzerModule';