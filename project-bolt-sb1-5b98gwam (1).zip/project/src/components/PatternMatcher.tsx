import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { naturalToAi } from '@/lib/ai/constants';

interface PatternMatcherProps {
  input: string;
}

interface PatternSet {
  value: string;
  type: 'natural' | 'ai' | 'slashDown';
  confidence: number;
  matches: string[];
}

export const PatternMatcher: React.FC<PatternMatcherProps> = ({ input }) => {
  const [sets, setSets] = React.useState<PatternSet[]>([]);

  React.useEffect(() => {
    if (input.length === 3) {
      analyzeSets();
    }
  }, [input]);

  const generateNaturalSets = (pattern: string): string[] => {
    const sets: string[] = [];
    const baseNum = parseInt(pattern);
    
    // Generate natural progression (+111)
    for (let i = 0; i < 5; i++) {
      const num = (baseNum + (i * 111)) % 1000;
      sets.push(num.toString().padStart(3, '0'));
    }
    
    return sets;
  };

  const generateAISets = (pattern: string): string[] => {
    const sets: string[] = [];
    const aiPattern = pattern.split('').map(d => naturalToAi[d]).join('');
    let current = parseInt(aiPattern);
    
    // Generate AI progression (+222)
    for (let i = 0; i < 5; i++) {
      const num = (current + (i * 222)) % 1000;
      sets.push(num.toString().padStart(3, '0'));
    }
    
    return sets;
  };

  const generateSlashDownSets = (pattern: string): string[] => {
    const sets: string[] = [];
    let current = parseInt(pattern);
    
    // Generate Slash Down progression (+111)
    for (let i = 0; i < 5; i++) {
      const num = (current + (i * 111)) % 1000;
      sets.push(num.toString().padStart(3, '0'));
    }
    
    return sets;
  };

  const analyzeSets = () => {
    const naturalSets = generateNaturalSets(input);
    const aiSets = generateAISets(input);
    const slashDownSets = generateSlashDownSets(input);

    const patternSets: PatternSet[] = [
      {
        value: input,
        type: 'natural',
        confidence: 0.95,
        matches: naturalSets
      },
      {
        value: input.split('').map(d => naturalToAi[d]).join(''),
        type: 'ai',
        confidence: 0.9,
        matches: aiSets
      },
      {
        value: input,
        type: 'slashDown',
        confidence: 0.85,
        matches: slashDownSets
      }
    ];

    setSets(patternSets);
  };

  const getPatternColor = (type: string) => {
    switch (type) {
      case 'natural':
        return 'bg-blue-50 border-blue-200 text-blue-700';
      case 'ai':
        return 'bg-orange-50 border-orange-200 text-orange-700';
      case 'slashDown':
        return 'bg-emerald-50 border-emerald-200 text-emerald-700';
      default:
        return 'bg-gray-50 border-gray-200 text-gray-700';
    }
  };

  if (!input || input.length !== 3) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-gray-500">
            Enter a 3-digit pattern to analyze sets
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Pattern Set Analysis</h3>
            <Badge variant="secondary">
              Base Pattern: {input}
            </Badge>
          </div>

          <div className="grid gap-6">
            {sets.map((set, idx) => (
              <div 
                key={idx}
                className={`p-4 rounded-lg border ${getPatternColor(set.type)}`}
              >
                <div className="flex justify-between items-center mb-3">
                  <div className="flex items-center gap-2">
                    <span className="font-medium capitalize">{set.type} Pattern</span>
                    <Badge variant="outline">
                      {(set.confidence * 100).toFixed(0)}% confidence
                    </Badge>
                  </div>
                  <span className="font-mono text-lg">{set.value}</span>
                </div>

                <div className="space-y-3">
                  <div className="text-sm font-medium">Pattern Sequence:</div>
                  <div className="grid grid-cols-5 gap-2">
                    {set.matches.map((match, i) => (
                      <div 
                        key={i}
                        className="bg-white bg-opacity-50 p-2 rounded border border-current border-opacity-20"
                      >
                        <div className="text-xs opacity-75 mb-1">Set {i + 1}</div>
                        <div className="font-mono">{match}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-4 text-sm space-y-1 opacity-75">
                  {set.type === 'natural' && (
                    <>
                      <p>• Natural number progression (+111)</p>
                      <p>• Example: 880 → 991 → 002 → 113 → 224</p>
                    </>
                  )}
                  {set.type === 'ai' && (
                    <>
                      <p>• AI conversion progression (+222)</p>
                      <p>• Example: 115 → 337 → 559 → 771 → 993</p>
                    </>
                  )}
                  {set.type === 'slashDown' && (
                    <>
                      <p>• Slash Down progression (+111)</p>
                      <p>• Example: 880 → 991 → 002 → 113 → 224</p>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-3 gap-4 bg-gray-50 p-4 rounded-lg">
            <div className="space-y-2">
              <div className="font-medium">Natural Pattern</div>
              <div className="text-sm text-gray-600">
                Sequential progression with +111 increment
              </div>
            </div>
            <div className="space-y-2">
              <div className="font-medium">AI Pattern</div>
              <div className="text-sm text-gray-600">
                AI conversion with +222 increment
              </div>
            </div>
            <div className="space-y-2">
              <div className="font-medium">Slash Down</div>
              <div className="text-sm text-gray-600">
                Diagonal pattern with +111 increment
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};