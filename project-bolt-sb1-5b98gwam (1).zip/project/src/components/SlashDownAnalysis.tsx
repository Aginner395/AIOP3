import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface SlashDownAnalysisProps {
  pattern: string;
}

export const SlashDownAnalysis: React.FC<SlashDownAnalysisProps> = ({ pattern }) => {
  const [copied, setCopied] = React.useState(false);
  const { toast } = useToast();

  const generateSlashDownSequence = (basePattern: string) => {
    const sequences: string[] = [];
    let currentNum = parseInt(basePattern);
    
    // Generate 10 sequences
    for (let i = 0; i < 10; i++) {
      // Format number as 3 digits with leading zeros
      const formattedNum = currentNum.toString().padStart(3, '0');
      sequences.push(formattedNum);
      
      // Add 111 for next sequence, wrapping around 1000
      currentNum = (currentNum + 111) % 1000;
    }
    
    return sequences;
  };

  const copySequences = async () => {
    try {
      const sequences = generateSlashDownSequence(pattern);
      await navigator.clipboard.writeText(sequences.join(' '));
      setCopied(true);
      toast({
        title: "Copied!",
        description: "All sequences copied to clipboard",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  const sequences = generateSlashDownSequence(pattern);

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-semibold">Slash Down Pattern Sequence</h3>
              <p className="text-sm text-gray-500 mt-1">
                Pattern progression with +111 increment
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={copySequences}
              className="transition-all duration-200"
            >
              {copied ? (
                <Check className="h-4 w-4 text-green-500" />
              ) : (
                <Copy className="h-4 w-4" />
              )}
              <span className="ml-2">{copied ? 'Copied!' : 'Copy All'}</span>
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {sequences.map((seq, idx) => (
              <div 
                key={idx}
                className="bg-gray-50 p-4 rounded-lg border-l-4 border-orange-300"
              >
                <div className="flex justify-between items-center">
                  <div>
                    <span className="font-medium">Set {idx + 1}</span>
                    <div className="text-sm text-gray-600 mt-1">
                      +111 progression
                    </div>
                  </div>
                  <Badge variant="outline" className="font-mono">
                    {seq}
                  </Badge>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-medium text-blue-800 mb-2">Pattern Information</h4>
            <div className="space-y-2 text-sm text-blue-700">
              <p>• Each number increases by 111</p>
              <p>• Sequence wraps around at 1000</p>
              <p>• Maintains consistent progression</p>
              <p>• Example: 880 → 991 → 002 → 113 → 224</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};