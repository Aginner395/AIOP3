import React, { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, RotateCcw, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { detectShapes } from '@/lib/shapes/shapeDetector';
import { naturalToAi } from '@/lib/ai/constants';

interface PatternControlProps {
  onInputChange?: (input: string) => void;
  onOutputChange?: (output: string) => void;
  onPatternMatch?: (matched: boolean) => void;
}

export const PatternControl: React.FC<PatternControlProps> = ({
  onInputChange,
  onOutputChange,
  onPatternMatch
}) => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [analysis, setAnalysis] = useState<{
    inputShape?: string;
    outputShape?: string;
    aiConversion?: string;
    matches?: boolean;
  }>({});
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (input.length === 3) {
      analyzePatterns();
      onInputChange?.(input);
    }
  }, [input]);

  useEffect(() => {
    if (output.length === 3) {
      analyzePatterns();
      onOutputChange?.(output);
    }
  }, [output]);

  const analyzePatterns = () => {
    if (input.length === 3) {
      const inputShapes = detectShapes(input);
      const aiConversion = input.split('').map(d => naturalToAi[d]).join('');
      
      const analysis: any = {
        inputShape: inputShapes[0]?.name,
        aiConversion
      };

      if (output.length === 3) {
        const outputShapes = detectShapes(output);
        analysis.outputShape = outputShapes[0]?.name;
        analysis.matches = output === aiConversion;
        onPatternMatch?.(analysis.matches);
      }

      setAnalysis(analysis);
    }
  };

  const handleInputChange = (value: string) => {
    const cleanValue = value.replace(/[^0-9]/g, '').slice(0, 3);
    setInput(cleanValue);
  };

  const handleOutputChange = (value: string) => {
    const cleanValue = value.replace(/[^0-9]/g, '').slice(0, 3);
    setOutput(cleanValue);
  };

  const handleClear = () => {
    setInput('');
    setOutput('');
    setAnalysis({});
  };

  const copyPattern = async () => {
    try {
      await navigator.clipboard.writeText(`${input} → ${output}`);
      setCopied(true);
      toast({
        title: "Copied!",
        description: "Pattern copied to clipboard",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="w-full">
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-semibold">Pattern Control</h2>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={copyPattern}
                className="transition-all duration-200"
              >
                {copied ? (
                  <Check className="h-4 w-4 text-green-500" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
                <span className="ml-2">{copied ? 'Copied!' : 'Copy Pattern'}</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleClear}
                className="flex items-center gap-2"
              >
                <RotateCcw className="h-4 w-4" />
                Clear
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            {/* Input Pattern */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-medium">Input Pattern</h3>
                {analysis.inputShape && (
                  <Badge variant="secondary">
                    {analysis.inputShape}
                  </Badge>
                )}
              </div>
              <Input
                value={input}
                onChange={(e) => handleInputChange(e.target.value)}
                placeholder="Enter 3 digits"
                className="text-2xl text-center font-mono"
                maxLength={3}
              />
              {analysis.aiConversion && (
                <div className="text-sm text-gray-500 text-center">
                  AI Conversion: {analysis.aiConversion}
                </div>
              )}
            </div>

            {/* Arrow */}
            <div className="flex justify-center">
              <ArrowRight className="w-6 h-6 text-gray-400" />
            </div>

            {/* Output Pattern */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-medium">Output Pattern</h3>
                {analysis.outputShape && (
                  <Badge variant="secondary">
                    {analysis.outputShape}
                  </Badge>
                )}
              </div>
              <Input
                value={output}
                onChange={(e) => handleOutputChange(e.target.value)}
                placeholder="Enter 3 digits"
                className={`text-2xl text-center font-mono ${
                  analysis.matches ? 'ring-2 ring-green-500' : ''
                }`}
                maxLength={3}
              />
              {analysis.matches && (
                <div className="text-center">
                  <Badge variant="success">AI Match!</Badge>
                </div>
              )}
            </div>
          </div>

          {/* Analysis Section */}
          {(analysis.inputShape || analysis.outputShape) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium mb-2">Pattern Analysis</h4>
                <div className="space-y-2 text-sm">
                  {analysis.inputShape && (
                    <div className="flex justify-between">
                      <span>Input Shape:</span>
                      <span className="font-medium">{analysis.inputShape}</span>
                    </div>
                  )}
                  {analysis.outputShape && (
                    <div className="flex justify-between">
                      <span>Output Shape:</span>
                      <span className="font-medium">{analysis.outputShape}</span>
                    </div>
                  )}
                  {analysis.aiConversion && (
                    <div className="flex justify-between">
                      <span>AI Conversion:</span>
                      <span className="font-medium">{analysis.aiConversion}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium mb-2">Pattern Status</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Input Complete:</span>
                    <Badge variant={input.length === 3 ? "success" : "secondary"}>
                      {input.length === 3 ? 'Yes' : 'No'}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Output Complete:</span>
                    <Badge variant={output.length === 3 ? "success" : "secondary"}>
                      {output.length === 3 ? 'Yes' : 'No'}
                    </Badge>
                  </div>
                  {input.length === 3 && output.length === 3 && (
                    <div className="flex justify-between">
                      <span>AI Match:</span>
                      <Badge variant={analysis.matches ? "success" : "destructive"}>
                        {analysis.matches ? 'Yes' : 'No'}
                      </Badge>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};