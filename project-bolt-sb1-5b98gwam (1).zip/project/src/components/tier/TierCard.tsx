import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy } from "lucide-react";

interface TierCardProps {
  title: string;
  value: string;
  input: string;
  onCopy: () => void;
  isCopied: boolean;
  colors: {
    text: string;
    bg: string;
    border: string;
  };
}

export const TierCard: React.FC<TierCardProps> = ({
  title,
  value,
  input,
  onCopy,
  isCopied,
  colors
}) => {
  return (
    <Card 
      className={`
        w-28 h-32 transition-all hover:shadow-md cursor-pointer
        ${colors.bg} border ${colors.border}
      `}
    >
      <CardContent className="p-3 relative">
        <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100">
          <Button
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0"
            onClick={(e) => {
              e.stopPropagation();
              onCopy();
            }}
          >
            <Copy className="h-3 w-3" />
          </Button>
        </div>

        <div className="flex flex-col items-center h-full">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-gray-600 truncate">
              {title}
            </span>
            <Badge variant="secondary" className="text-[10px] px-1">
              Match
            </Badge>
          </div>
          <div className="flex-1 flex items-center justify-center">
            <span className={`text-xl font-mono font-bold ${colors.text}`}>
              {value}
            </span>
          </div>
          <span className="text-xs text-gray-500 mt-1">{input}</span>
        </div>

        {isCopied && (
          <div className={`absolute inset-0 ${colors.bg} bg-opacity-90 flex items-center justify-center rounded-lg`}>
            <span className={`${colors.text} text-sm font-medium`}>
              Copied!
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
};