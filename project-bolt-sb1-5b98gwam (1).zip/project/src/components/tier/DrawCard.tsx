import React from 'react';
import { Card, CardContent } from "@/components/ui/card";

interface DrawCardProps {
  number?: string;
}

export const DrawCard: React.FC<DrawCardProps> = ({ number }) => (
  <Card className="w-28 h-32 transition-all hover:shadow-md">
    <CardContent className="p-3">
      <div className="flex flex-col items-center h-full">
        <span className="text-xs font-medium text-gray-600 truncate w-full text-center">
          Draw
        </span>
        <div className="flex-1 flex items-center justify-center">
          <span className="text-2xl font-mono font-bold text-gray-800">
            {number || '---'}
          </span>
        </div>
      </div>
    </CardContent>
  </Card>
);