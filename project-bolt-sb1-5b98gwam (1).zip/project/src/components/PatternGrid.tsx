import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Copy, Check } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { PatternCell } from '@/types/patterns';
import { GridCalibrator } from '@/lib/analysis/gridCalibrator';
import { detectShapes } from '@/lib/shapes/shapeDetector';

interface PatternGridProps {
  pattern: {
    cells: PatternCell[];
    color: string;
  };
  shapeName: string;
  showConversion?: boolean;
  showInput?: boolean;
  scale?: string;
  historicalPatterns?: string[];
}

export const PatternGrid: React.FC<PatternGridProps> = ({
  pattern,
  shapeName,
  showConversion = false,
  showInput = false,
  scale = 'scale-100',
  historicalPatterns = []
}) => {
  const { toast } = useToast();
  const [copied, setCopied] = React.useState(false);
  const [copiedAll, setCopiedAll] = React.useState(false);

  // Memoize the pattern string
  const patternString = React.useMemo(() => 
    pattern.cells
      .sort((a, b) => a.col - b.col)
      .map(cell => cell.num)
      .join(''),
    [pattern.cells]
  );

  // Memoize shape detection
  const { dominantShape } = React.useMemo(() => {
    const detectedShapes = detectShapes(patternString);
    return {
      dominantShape: detectedShapes[0]
    };
  }, [patternString]);

  // Memoize sequence generation
  const { sequences, horizontalSets, calibration } = React.useMemo(() => {
    const generateSequences = (cells: PatternCell[]) => {
      const newSequences = Array(10).fill(null).map(() => Array(3).fill(''));
      
      cells.forEach(cell => {
        const baseRow = cell.row;
        const baseNum = parseInt(cell.num);
        
        for (let row = 0; row < 10; row++) {
          let num;
          if (row < baseRow) {
            num = (baseNum - (baseRow - row) + 10) % 10;
          } else if (row > baseRow) {
            num = (baseNum + (row - baseRow)) % 10;
          } else {
            num = baseNum;
          }
          newSequences[row][cell.col] = num.toString();
        }
      });

      return newSequences;
    };

    let newSequences: string[][];
    let newCalibration = null;

    if (historicalPatterns.length > 0 && pattern.cells.length === 3) {
      const calibrator = new GridCalibrator();
      newCalibration = calibrator.calibrate(historicalPatterns);
      const optimizedCells = calibrator.generateOptimalGrid(patternString, newCalibration);
      newSequences = generateSequences(optimizedCells);
    } else {
      newSequences = generateSequences(pattern.cells);
    }

    const newHorizontalSets = newSequences.map(row => row.join(''));
    
    return {
      sequences: newSequences,
      horizontalSets: newHorizontalSets,
      calibration: newCalibration
    };
  }, [patternString, historicalPatterns, pattern.cells]);

  const copyNumbers = React.useCallback(async () => {
    try {
      const numbersList = horizontalSets.join('\n');
      await navigator.clipboard.writeText(numbersList);
      setCopied(true);
      toast({
        title: "Copied!",
        description: "Numbers have been copied to clipboard",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please try again",
        variant: "destructive",
      });
    }
  }, [horizontalSets, toast]);

  const copyAllNumbers = React.useCallback(async () => {
    try {
      const allNumbers = horizontalSets.join(' ');
      await navigator.clipboard.writeText(allNumbers);
      setCopiedAll(true);
      toast({
        title: "Copied All!",
        description: "All numbers have been copied to clipboard",
      });
      setTimeout(() => setCopiedAll(false), 2000);
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please try again",
        variant: "destructive",
      });
    }
  }, [horizontalSets, toast]);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="text-lg font-semibold flex items-center gap-2">
          {shapeName} Pattern
          {dominantShape && (
            <Badge variant="secondary">
              {dominantShape.name} ({(dominantShape.confidence * 100).toFixed(0)}%)
            </Badge>
          )}
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={copyAllNumbers}
          className="transition-all duration-200"
        >
          {copiedAll ? (
            <Check className="h-4 w-4 text-green-500" />
          ) : (
            <Copy className="h-4 w-4" />
          )}
          <span className="ml-2">{copiedAll ? 'Copied All!' : 'Copy All Numbers'}</span>
        </Button>
      </div>
      
      <div className={`flex justify-center ${scale}`}>
        <div className="flex flex-col pr-2">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="h-8 flex items-center justify-end text-xs text-gray-500 w-4">
              {i}
            </div>
          ))}
        </div>
        <div>
          <div className="border border-gray-300 rounded-lg overflow-hidden">
            {sequences.map((row, rowIndex) => (
              <div key={rowIndex} className="flex group relative hover:bg-gray-50 transition-colors">
                {row.map((cell, colIndex) => {
                  const originalCell = pattern.cells.find(
                    c => c.row === rowIndex && c.col === colIndex
                  );
                  const isBaseCell = Boolean(originalCell);
                  const hasHighWeight = calibration?.cellWeights[rowIndex][colIndex] > 0.7;
                  
                  return (
                    <div
                      key={colIndex}
                      className={`
                        w-8 h-8 border-r border-b border-gray-200
                        flex items-center justify-center text-sm font-mono
                        ${isBaseCell ? pattern.color + ' font-bold' : 
                          cell ? 'bg-blue-50' : 'bg-white'}
                        ${hasHighWeight ? 'ring-2 ring-blue-200' : ''}
                        ${showInput ? 'cursor-pointer hover:bg-gray-100' : ''}
                        transition-colors duration-200
                      `}
                    >
                      {cell}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>

      <Card className="mt-4 p-4">
        <div className="flex justify-between items-center mb-4">
          <div className="text-sm font-medium">Pattern Sets:</div>
          <Button
            variant="outline"
            size="sm"
            onClick={copyNumbers}
            className="transition-all duration-200"
          >
            {copied ? (
              <Check className="h-4 w-4 text-green-500" />
            ) : (
              <Copy className="h-4 w-4" />
            )}
            <span className="ml-2">{copied ? 'Copied!' : 'Copy Numbers'}</span>
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {horizontalSets.map((set, index) => (
            <div key={index} className="flex items-center space-x-3">
              <span className="text-gray-500 w-6">#{index}:</span>
              <span className="font-mono bg-gray-50 px-2 py-1 rounded">
                {set}
              </span>
            </div>
          ))}
        </div>
      </Card>

      {calibration && (
        <Card className="mt-4 p-4">
          <div className="text-sm font-medium mb-2">Grid Calibration:</div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Base Row:</span>
              <Badge variant="secondary">{calibration.baseRow}</Badge>
            </div>
            <div className="flex justify-between">
              <span>Shape Alignment:</span>
              <Badge variant="secondary">
                {(calibration.shapeAlignment.confidence * 100).toFixed(0)}%
              </Badge>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
};