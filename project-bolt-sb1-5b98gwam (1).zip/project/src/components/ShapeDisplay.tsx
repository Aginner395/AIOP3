import { Label } from "@/components/ui/label";
import { ShapeGrid } from "./ShapeGrid";
import { CoreShape } from "@/types/patterns";

interface ShapeDisplayProps {
  shape: CoreShape;
}

export const ShapeDisplay = ({ shape }: ShapeDisplayProps) => {
  return (
    <div className="flex justify-center gap-8">
      <div>
        <Label>Natural Pattern</Label>
        <ShapeGrid
          {...shape}
          showConversion={false}
          showInput={true}
        />
      </div>
      <div>
        <Label>AI Conversion</Label>
        <ShapeGrid
          {...shape}
          showConversion={true}
          showInput={false}
        />
      </div>
    </div>
  );
};