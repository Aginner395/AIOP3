interface ShapeVisualizerProps {
  shape: 'straight' | 'reverse' | 'diagonal' | 'zigzag' | 'pyramid';
}

export const ShapeVisualizer = ({ shape }: ShapeVisualizerProps) => {
  const getShapePath = () => {
    const size = 100;
    const padding = 10;
    const width = size - 2 * padding;
    const height = size - 2 * padding;

    switch (shape) {
      case 'straight':
        return `M ${padding} ${padding} L ${width + padding} ${padding}`;
      case 'reverse':
        return `M ${width + padding} ${padding} L ${padding} ${padding}`;
      case 'diagonal':
        return `M ${padding} ${padding} L ${width + padding} ${height + padding}`;
      case 'zigzag':
        return `M ${padding} ${padding} 
                L ${width/2 + padding} ${height + padding} 
                L ${width + padding} ${padding}`;
      case 'pyramid':
        return `M ${padding} ${height + padding} 
                L ${width/2 + padding} ${padding} 
                L ${width + padding} ${height + padding}`;
      default:
        return '';
    }
  };

  return (
    <svg 
      viewBox="0 0 100 100" 
      className="w-full h-full stroke-current"
      style={{ strokeWidth: 3, fill: 'none' }}
    >
      <path d={getShapePath()} />
    </svg>
  );
};