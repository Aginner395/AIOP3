import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { AILogicAnalyzer } from './AILogicAnalyzer';

interface SequenceDisplayProps {
  input: string;
}

export default function SequenceDisplay({ input }: SequenceDisplayProps) {
  const [showAnalysis, setShowAnalysis] = React.useState(false);

  React.useEffect(() => {
    setShowAnalysis(input.length === 3);
  }, [input]);

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardContent className="p-6">
        <div className="space-y-6">
          {showAnalysis && (
            <>
              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-4">Pattern Analysis</h3>
                <AILogicAnalyzer input={input} />
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
};