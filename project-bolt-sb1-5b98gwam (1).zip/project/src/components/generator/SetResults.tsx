import { Card } from "@/components/ui/card";
import type { AISet } from '@/types/generator';

interface SetResultsProps {
  sets: AISet[];
}

const aiColors = {
  'AI#1': 'bg-indigo-50 border-indigo-100 text-indigo-700',
  'AI#2': 'bg-amber-50 border-amber-100 text-amber-700',
  'AI#3': 'bg-rose-50 border-rose-100 text-rose-700',
  'AI#4': 'bg-emerald-50 border-emerald-100 text-emerald-700'
};

export const SetResults = ({ sets }: SetResultsProps) => {
  // Group sets by AI type
  const groupedSets = sets.reduce((acc, set) => {
    if (!acc[set.type]) acc[set.type] = [];
    acc[set.type].push(set);
    return acc;
  }, {} as Record<string, AISet[]>);

  return (
    <div className="space-y-6">
      {Object.entries(aiColors).map(([aiType, colors]) => {
        const typeSets = groupedSets[aiType] || [];
        return (
          <div key={aiType} className="space-y-3">
            <h3 className="text-xl font-bold">{aiType}</h3>
            <div className="grid gap-3">
              {typeSets.map((set, idx) => (
                <Card key={idx} className={`${colors} p-3`}>
                  <div className="font-mono text-sm mb-2 font-bold">
                    {set.aiSet}
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                    <div>LLL: {set.patterns.lll}</div>
                    <div>LLH: {set.patterns.llh}</div>
                    <div>LHL: {set.patterns.lhl}</div>
                    <div>LHH: {set.patterns.lhh}</div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
};