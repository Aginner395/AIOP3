import { useState } from 'react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { validatePattern } from '@/lib/validators/patternValidator';

interface SetInputProps {
  onGenerate: (pattern: string) => void;
}

export const SetInput = ({ onGenerate }: SetInputProps) => {
  const [input, setInput] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = () => {
    const validationError = validatePattern(input);
    if (validationError) {
      setError(validationError);
      return;
    }
    setError('');
    onGenerate(input);
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Enter Pattern (3 digits)</Label>
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value.replace(/[^0-9]/g, '').slice(0, 3))}
            placeholder="123"
            className="text-2xl text-center font-mono"
            maxLength={3}
          />
          <Button onClick={handleSubmit} disabled={input.length !== 3}>
            Generate Sets
          </Button>
        </div>
      </div>
      {error && <p className="text-sm text-red-500">{error}</p>}
    </div>
  );
};