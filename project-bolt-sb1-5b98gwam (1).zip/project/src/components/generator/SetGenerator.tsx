import { Card, CardContent } from "@/components/ui/card";
import { SetResults } from './SetResults';
import { generateAISets } from '@/lib/aiSetGenerator';
import { useEffect, useState } from 'react';
import type { AISet } from '@/types/generator';

interface SetGeneratorProps {
  input: string;
}

export const SetGenerator = ({ input }: SetGeneratorProps) => {
  const [aiSets, setAISets] = useState<AISet[] | null>(null);

  useEffect(() => {
    if (input.length === 3) {
      const sets = generateAISets(input);
      setAISets(sets);
    } else {
      setAISets(null);
    }
  }, [input]);

  return (
    <Card className="w-full">
      <CardContent className="p-6 space-y-6">
        {aiSets && <SetResults sets={aiSets} />}
      </CardContent>
    </Card>
  );
};