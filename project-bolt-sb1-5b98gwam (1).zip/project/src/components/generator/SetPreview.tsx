import { Card } from "@/components/ui/card";
import type { PatternSet } from '@/types/generator';

interface SetPreviewProps {
  set: PatternSet;
}

export const SetPreview = ({ set }: SetPreviewProps) => (
  <div className="space-y-4">
    <h3 className="text-lg font-semibold">Generated Pattern Set</h3>
    <div className="grid grid-cols-2 gap-4">
      {set.patterns.map((pattern, idx) => (
        <Card key={idx} className="p-4">
          <div className="flex justify-between items-center">
            <span className="font-medium">{pattern.type}</span>
            <span className="text-sm text-gray-500">{pattern.probability}%</span>
          </div>
          <div className="mt-2 text-2xl font-bold">{pattern.value}</div>
        </Card>
      ))}
    </div>
  </div>
);