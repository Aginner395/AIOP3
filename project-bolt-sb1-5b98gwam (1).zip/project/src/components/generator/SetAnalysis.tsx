import { Card } from "@/components/ui/card";
import type { PatternSet } from '@/types/generator';

interface SetAnalysisProps {
  set: PatternSet;
}

export const SetAnalysis = ({ set }: SetAnalysisProps) => (
  <div className="space-y-4">
    <h3 className="text-lg font-semibold">Pattern Analysis</h3>
    <div className="grid grid-cols-2 gap-4">
      <Card className="p-4">
        <h4 className="font-medium mb-2">Distribution</h4>
        <div className="space-y-2">
          {set.analysis.distribution.map((item, idx) => (
            <div key={idx} className="flex justify-between">
              <span>{item.type}</span>
              <span className="text-gray-500">{item.percentage}%</span>
            </div>
          ))}
        </div>
      </Card>
      <Card className="p-4">
        <h4 className="font-medium mb-2">Insights</h4>
        <ul className="space-y-2 text-sm">
          {set.analysis.insights.map((insight, idx) => (
            <li key={idx}>• {insight}</li>
          ))}
        </ul>
      </Card>
    </div>
  </div>
);