import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RotateCcw } from 'lucide-react';
import { acrMappings, crlMappings, atraxMappings } from '@/lib/mappings';

interface SystemResult {
  system: string;
  values: string[];
  input: string;
  confidence: number;
}

const getSystemColor = (system: string, values: string[]) => {
  if (!values || values.length === 0) return 'text-gray-400';
  
  switch (system) {
    case 'ACR':
      return 'text-blue-600';
    case 'CRL':
      return 'text-emerald-600';
    case 'ATRAX':
      return 'text-red-600';
    default:
      return 'text-gray-800';
  }
};

const NumberDisplay = ({ title, numbers, subtitle, color = 'text-blue-600', confidence }: {
  title: string;
  numbers: string[];
  subtitle?: string;
  color?: string;
  confidence?: number;
}) => (
  <Card className="w-64 bg-white">
    <CardContent className="p-3">
      <div className="flex flex-col h-full">
        <span className="text-xs font-medium text-gray-600 truncate w-full text-center">
          {title}
        </span>
        <div className="flex-1 flex items-center justify-center">
          <div className="grid grid-cols-3 gap-1">
            {numbers.map((num, idx) => (
              <span key={idx} className={`text-lg font-mono font-bold ${color}`}>
                {num}
              </span>
            ))}
          </div>
        </div>
        <div className="flex flex-col items-center gap-1">
          {confidence && (
            <Badge variant="secondary" className="text-xs">
              {confidence}%
            </Badge>
          )}
          {subtitle && (
            <span className="text-xs text-gray-500">
              {subtitle}
            </span>
          )}
        </div>
      </div>
    </CardContent>
  </Card>
);

const MultiTierLookup = () => {
  const [drawNumber, setDrawNumber] = useState('');
  const [results, setResults] = useState<SystemResult[]>([]);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);

  const handleSearch = (value: string) => {
    if (value.length === 3) {
      const acrValues = acrMappings[value] || [];
      const crlValues = crlMappings[value] || [];
      const atraxValues = atraxMappings[value] || [];

      const newResults = [
        {
          system: 'ACR',
          values: acrValues,
          input: value,
          confidence: 95
        },
        {
          system: 'CRL',
          values: crlValues,
          input: value,
          confidence: 90
        },
        {
          system: 'ATRAX',
          values: atraxValues,
          input: value,
          confidence: 85
        }
      ];

      setResults(newResults);
      updateRecentSearches(value);
    } else {
      setResults([]);
    }
  };

  const updateRecentSearches = (value: string) => {
    if (!recentSearches.includes(value)) {
      setRecentSearches(prev => [value, ...prev.slice(0, 4)]);
    }
  };

  const handleClear = () => {
    setDrawNumber('');
    setResults([]);
  };

  return (
    <Card className="w-full max-w-full mx-auto">
      <CardContent className="p-6">
        <div className="space-y-6">
          <div>
            <h2 className="text-lg font-semibold mb-4">Multi-System Lookup</h2>
            <div className="flex gap-2">
              <Input
                type="text"
                placeholder="Enter 3-digit number"
                value={drawNumber}
                onChange={(e) => {
                  const value = e.target.value.replace(/\D/g, '').slice(0, 3);
                  setDrawNumber(value);
                  handleSearch(value);
                }}
                className="text-lg font-mono w-full max-w-[200px]"
                maxLength={3}
              />
              {drawNumber && (
                <Button 
                  variant="outline"
                  onClick={handleClear}
                  className="flex items-center gap-2"
                >
                  <RotateCcw className="h-4 w-4" />
                  Clear
                </Button>
              )}
            </div>
          </div>

          <div className="overflow-x-auto">
            <div className="flex gap-4 min-w-min p-2">
              <NumberDisplay 
                title="INPUT" 
                numbers={[drawNumber]} 
                color="text-gray-900"
              />
              {results.map((result) => (
                <NumberDisplay
                  key={result.system}
                  title={result.system}
                  numbers={result.values}
                  subtitle={result.input}
                  color={getSystemColor(result.system, result.values)}
                  confidence={result.confidence}
                />
              ))}
            </div>
          </div>

          {recentSearches.length > 0 && (
            <div className="pt-4 border-t">
              <h3 className="text-sm font-medium text-gray-600 mb-2">Recent Searches</h3>
              <div className="flex gap-2 flex-wrap">
                {recentSearches.map((search) => (
                  <Button
                    key={search}
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setDrawNumber(search);
                      handleSearch(search);
                    }}
                  >
                    {search}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default MultiTierLookup;