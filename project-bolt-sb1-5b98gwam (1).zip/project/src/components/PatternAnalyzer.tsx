import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { NaturalGrid } from './NaturalGrid';
import { AIGrid } from './AIGrid';
import { ShapeDetection } from './ShapeDetection';
import { PatternComparison } from './PatternComparison';
import { OriginPatternGrid } from './OriginPatternGrid';
import { SlashDownAnalysis } from './SlashDownAnalysis';
import { SlashUpAnalysis } from './SlashUpAnalysis';
import { detectShapes } from '@/lib/shapes/shapeDetector';

interface PatternAnalyzerProps {
  input: string;
  output: string;
}

export const PatternAnalyzer: React.FC<PatternAnalyzerProps> = ({ input, output }) => {
  // Detect shapes for both input and output
  const inputShapes = detectShapes(input);
  const outputShapes = detectShapes(output);
  
  const inputShape = inputShapes.length > 0 ? inputShapes[0] : null;
  const outputShape = outputShapes.length > 0 ? outputShapes[0] : null;

  return (
    <div className="space-y-8">
      {/* Origin Pattern Grid */}
      <Card>
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">Pattern Origin Analysis</h2>
            <div className="flex gap-2">
              <Badge variant="secondary">
                Input: {input} ({inputShape?.name || 'Unknown'})
              </Badge>
              <Badge variant="success">
                Output: {output} ({outputShape?.name || 'Unknown'})
              </Badge>
            </div>
          </div>
          <OriginPatternGrid input={input} output={output} />
        </CardContent>
      </Card>

      {/* Pattern Comparison Analysis */}
      <PatternComparison input={input} output={output} />

      {/* Input Pattern Grids */}
      <div className="space-y-2">
        <h2 className="text-xl font-semibold">Input Pattern Analysis</h2>
        <div className="grid grid-cols-2 gap-6">
          <NaturalGrid pattern={input} />
          <AIGrid pattern={input} isOutput={false} />
        </div>
      </div>

      {/* Output Pattern Grids */}
      {output && (
        <div className="space-y-2">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            Output Pattern Analysis
            {outputShape && (
              <Badge variant="success" className="text-base">
                {outputShape.name} Pattern ({(outputShape.confidence * 100).toFixed(0)}%)
              </Badge>
            )}
          </h2>
          <div className="grid grid-cols-2 gap-6">
            <NaturalGrid pattern={output} />
            <AIGrid pattern={output} isOutput={true} />
          </div>
          
          {/* Output Shape Analysis */}
          {outputShape && (
            <Card className="mt-4 p-6 border-2 border-green-200">
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-green-800">Output Shape Analysis</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Shape Characteristics</h4>
                    <div className="space-y-2 text-sm text-green-700">
                      {outputShape.reasons.map((reason, idx) => (
                        <p key={idx}>• {reason}</p>
                      ))}
                    </div>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Pattern Transformation</h4>
                    <div className="space-y-2 text-sm text-green-700">
                      <p>• Type: {outputShape.transformation?.type}</p>
                      <p>• Increment: {outputShape.transformation?.increment}</p>
                      <p>• Direction: {outputShape.transformation?.direction}</p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          )}
        </div>
      )}

      {/* Shape Detection */}
      <div className="space-y-2">
        <h2 className="text-xl font-semibold">Shape Analysis</h2>
        <ShapeDetection pattern={input} />
        {output && (
          <div className="mt-4">
            <h3 className="text-lg font-medium mb-4">Output Shape Analysis</h3>
            <ShapeDetection pattern={output} />
          </div>
        )}
      </div>

      {/* Pattern Analysis */}
      <div className="grid grid-cols-2 gap-6">
        <div className="space-y-2">
          <h2 className="text-xl font-semibold">Slash Down Pattern Analysis</h2>
          <SlashDownAnalysis pattern={output} />
        </div>
        <div className="space-y-2">
          <h2 className="text-xl font-semibold">Slash Up Pattern Analysis</h2>
          <SlashUpAnalysis pattern={output} />
        </div>
      </div>
    </div>
  );
};