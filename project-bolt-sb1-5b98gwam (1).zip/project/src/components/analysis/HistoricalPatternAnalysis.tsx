import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  AreaChart,
  Area
} from 'recharts';
import { detectShapes } from '@/lib/shapes/shapeDetector';
import { processAI1, processAI4, processAI6 } from '@/lib/ai/processors';
import { naturalToAi } from '@/lib/ai/constants';

interface Draw {
  date: string;
  midday: {
    pick3: string;
    pick4: string;
  };
  evening: {
    pick3: string;
    pick4: string;
  };
}

interface PatternProgression {
  date: string;
  numbers: string;
  aiConverted: string;
  shape: string;
  setTypes: string[];
  progression: {
    fromPrevious: number;
    trend: 'ascending' | 'descending' | 'stable';
    continuity: number;
  };
}

interface HistoricalPatternAnalysisProps {
  data: Draw[];
}

export const HistoricalPatternAnalysis: React.FC<HistoricalPatternAnalysisProps> = ({ data }) => {
  const [analysisType, setAnalysisType] = React.useState<'set' | 'shape'>('set');
  const [viewMode, setViewMode] = React.useState<'trend' | 'progression'>('trend');
  
  const patternProgression = React.useMemo(() => {
    const progression: PatternProgression[] = [];
    let previousPattern: string | null = null;

    data.forEach(draw => {
      [draw.midday.pick3, draw.evening.pick3].forEach(numbers => {
        if (!numbers || typeof numbers !== 'string' || !/^\d{3}$/.test(numbers)) return;

        try {
          const aiSets = [
            ...processAI1(numbers),
            ...processAI4(numbers),
            ...processAI6(numbers)
          ];
          
          const shapes = detectShapes(numbers);
          const setTypes = Array.from(new Set(aiSets.map(s => s.aiSet.slice(0, 2))));
          
          progression.push({
            date: draw.date,
            numbers,
            aiConverted: numbers.split('').map(d => naturalToAi[d]).join(''),
            shape: shapes[0]?.name || 'Unclassified',
            setTypes,
            progression: analyzePatternProgression(numbers, previousPattern)
          });

          previousPattern = numbers;
        } catch (error) {
          console.error('Error analyzing pattern progression:', numbers, error);
        }
      });
    });

    return progression;
  }, [data]);

  const analyzePatternProgression = (current: string, previous: string | null): PatternProgression['progression'] => {
    if (!previous) {
      return { fromPrevious: 0, trend: 'stable', continuity: 0 };
    }

    const currentNums = current.split('').map(Number);
    const previousNums = previous.split('').map(Number);
    
    // Calculate numerical progression
    const fromPrevious = currentNums.reduce((acc, num, idx) => {
      return acc + Math.abs(num - previousNums[idx]);
    }, 0) / 3;

    // Determine trend
    const trend = currentNums.reduce((acc, num, idx) => {
      if (idx === 0) return acc;
      return num > currentNums[idx - 1] ? acc + 1 : acc - 1;
    }, 0);

    // Calculate pattern continuity
    const continuity = currentNums.reduce((acc, num, idx) => {
      return acc + (Math.abs(num - previousNums[idx]) <= 1 ? 1 : 0);
    }, 0);

    return {
      fromPrevious,
      trend: trend > 0 ? 'ascending' : trend < 0 ? 'descending' : 'stable',
      continuity: (continuity / 3) * 100
    };
  };

  const progressionChartData = React.useMemo(() => {
    return patternProgression.map(prog => ({
      date: prog.date,
      continuity: prog.progression.continuity,
      progression: prog.progression.fromPrevious * 100,
      shape: prog.shape,
      setCount: prog.setTypes.length
    }));
  }, [patternProgression]);

  const dominantPatterns = React.useMemo(() => {
    const patterns = patternProgression.reduce((acc, curr) => {
      // Track shape patterns
      if (!acc.shapes[curr.shape]) {
        acc.shapes[curr.shape] = { count: 0, progression: [] };
      }
      acc.shapes[curr.shape].count++;
      acc.shapes[curr.shape].progression.push(curr.progression.continuity);

      // Track set patterns
      curr.setTypes.forEach(set => {
        if (!acc.sets[set]) {
          acc.sets[set] = { count: 0, progression: [] };
        }
        acc.sets[set].count++;
        acc.sets[set].progression.push(curr.progression.continuity);
      });

      return acc;
    }, { shapes: {}, sets: {} } as Record<string, Record<string, { count: number; progression: number[] }>>);

    return {
      shapes: Object.entries(patterns.shapes)
        .map(([shape, data]) => ({
          pattern: shape,
          count: data.count,
          avgContinuity: data.progression.reduce((a, b) => a + b, 0) / data.progression.length
        }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 5),
      sets: Object.entries(patterns.sets)
        .map(([set, data]) => ({
          pattern: set,
          count: data.count,
          avgContinuity: data.progression.reduce((a, b) => a + b, 0) / data.progression.length
        }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 5)
    };
  }, [patternProgression]);

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Pattern Progression Analysis</h3>
            <div className="flex gap-4">
              <div className="flex gap-2">
                <Badge 
                  variant={analysisType === 'set' ? 'default' : 'outline'}
                  className="cursor-pointer"
                  onClick={() => setAnalysisType('set')}
                >
                  Set Analysis
                </Badge>
                <Badge 
                  variant={analysisType === 'shape' ? 'default' : 'outline'}
                  className="cursor-pointer"
                  onClick={() => setAnalysisType('shape')}
                >
                  Shape Analysis
                </Badge>
              </div>
              <div className="flex gap-2">
                <Badge 
                  variant={viewMode === 'trend' ? 'default' : 'outline'}
                  className="cursor-pointer"
                  onClick={() => setViewMode('trend')}
                >
                  Trend View
                </Badge>
                <Badge 
                  variant={viewMode === 'progression' ? 'default' : 'outline'}
                  className="cursor-pointer"
                  onClick={() => setViewMode('progression')}
                >
                  Progression
                </Badge>
              </div>
            </div>
          </div>

          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              {viewMode === 'trend' ? (
                <LineChart data={progressionChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="continuity" 
                    stroke="#8884d8" 
                    name="Pattern Continuity %"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="progression" 
                    stroke="#82ca9d" 
                    name="Progression Score"
                  />
                </LineChart>
              ) : (
                <AreaChart data={progressionChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey={analysisType === 'shape' ? 'shape' : 'setCount'}
                    stackId="1"
                    stroke="#8884d8"
                    fill="#8884d8"
                    name={analysisType === 'shape' ? 'Shape Patterns' : 'Set Patterns'}
                  />
                </AreaChart>
              )}
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="font-medium mb-2">Dominant Patterns</div>
              <div className="space-y-2">
                {(analysisType === 'shape' ? dominantPatterns.shapes : dominantPatterns.sets)
                  .map(({ pattern, count, avgContinuity }) => (
                    <div key={pattern} className="flex justify-between items-center">
                      <span className="font-mono">{pattern}</span>
                      <div className="text-sm">
                        <span className="mr-4">{count} occurrences</span>
                        <span className="text-gray-500">{avgContinuity.toFixed(1)}% continuity</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="font-medium mb-2">Pattern Progression Stats</div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Average Continuity</span>
                  <span>
                    {(patternProgression.reduce((sum, curr) => 
                      sum + curr.progression.continuity, 0) / patternProgression.length).toFixed(1)}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Stable Patterns</span>
                  <span>
                    {patternProgression.filter(p => p.progression.trend === 'stable').length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Pattern Changes</span>
                  <span>
                    {patternProgression.filter(p => p.progression.fromPrevious > 1).length}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};