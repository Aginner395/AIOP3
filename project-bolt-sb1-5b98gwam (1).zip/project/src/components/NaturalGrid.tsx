import React from 'react';
import { Card } from '@/components/ui/card';

interface NaturalGridProps {
  pattern: string;
}

export const NaturalGrid: React.FC<NaturalGridProps> = ({ pattern }) => {
  const generateGrid = () => {
    const grid = Array(10).fill(null).map(() => Array(3).fill(''));
    const patternDigits = pattern.split('').map(Number);
    
    // Fill the grid with sequential values
    for (let row = 0; row < 10; row++) {
      for (let col = 0; col < 3; col++) {
        const value = ((patternDigits[col] + row) % 10).toString();
        grid[row][col] = value;
      }
    }
    
    return grid;
  };

  const grid = generateGrid();

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <h3 className="text-lg font-medium">Natural Pattern Grid</h3>
        <div className="flex justify-center">
          <div className="flex">
            <div className="flex flex-col pr-2">
              {[...Array(10)].map((_, i) => (
                <div key={i} className="h-8 flex items-center justify-end text-xs text-gray-500 w-4">
                  {i}
                </div>
              ))}
            </div>
            <div className="border border-gray-300 rounded-lg overflow-hidden">
              {grid.map((row, rowIndex) => (
                <div key={rowIndex} className="flex">
                  {row.map((cell, colIndex) => {
                    const isInputDigit = cell === pattern[colIndex];
                    return (
                      <div
                        key={colIndex}
                        className={`
                          w-8 h-8 border-r border-b border-gray-200
                          flex items-center justify-center text-sm font-mono
                          ${isInputDigit ? 'bg-blue-100 font-bold ring-2 ring-blue-400' : 'bg-white'}
                          transition-colors duration-200
                        `}
                      >
                        {cell}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};