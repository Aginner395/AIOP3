import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { aiColors } from '@/lib/ai/constants';
import { processAI1, processAI4, processAI6 } from '@/lib/ai/processors';

interface AIPatternAnalysisProps {
  input: string;
  output?: string;
  onPrediction?: (prediction: string) => void;
}

interface ResultSetProps {
  items: any[];
  colors: {
    bg: string;
    border: string;
    text: string;
    title: string;
  };
  title: string;
}

const ResultSet = ({ items, colors, title }: ResultSetProps) => (
  <div className="space-y-3">
    <h3 className={`text-xl font-bold ${colors.title}`}>{title}</h3>
    <div className="space-y-2">
      {items.map((item, idx) => (
        <div 
          key={idx} 
          className={`${colors.bg} ${colors.border} border p-3 rounded-lg`}
        >
          <div className="flex justify-between items-center mb-1">
            <div className={`font-mono text-sm font-bold ${colors.text}`}>
              {item.aiSet}
            </div>
            {item.isKeyMatch && (
              <Badge variant="secondary" className="text-xs">Key Match</Badge>
            )}
          </div>
          <div className="grid grid-cols-2 gap-1 text-xs font-mono">
            <div className="text-gray-600">LLL: {item.patterns.lll}</div>
            <div className="text-gray-600">LLH: {item.patterns.llh}</div>
            <div className="text-gray-600">LHL: {item.patterns.lhl}</div>
            <div className="text-gray-600">LHH: {item.patterns.lhh}</div>
          </div>
        </div>
      ))}
    </div>
  </div>
);

export const AIPatternAnalysis: React.FC<AIPatternAnalysisProps> = ({ 
  input, 
  output, 
  onPrediction 
}) => {
  const [processedResults, setProcessedResults] = React.useState<any>(null);
  
  // Memoize the processing function to prevent unnecessary recalculations
  const processInput = React.useCallback((input: string) => {
    if (input.length !== 3) return null;

    try {
      return {
        ai1: processAI1(input),
        ai4: processAI4(input),
        ai6: processAI6(input)
      };
    } catch (error) {
      console.error('Processing error:', error);
      return null;
    }
  }, []);

  // Memoize the pattern extraction function
  const extractPatterns = React.useCallback((results: any) => {
    if (!results) return new Set<string>();

    const patterns = new Set<string>();
    Object.values(results).forEach((aiResult: any[]) => {
      aiResult.forEach(result => {
        Object.values(result.patterns).forEach(pattern => {
          patterns.add(pattern as string);
        });
      });
    });
    return patterns;
  }, []);

  React.useEffect(() => {
    const results = processInput(input);
    setProcessedResults(results);

    if (results && onPrediction) {
      const patterns = extractPatterns(results);
      patterns.forEach(onPrediction);
    }
  }, [input, processInput, extractPatterns]);

  if (!processedResults) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-gray-500">
            Enter a valid 3-digit pattern to analyze
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          <ResultSet items={processedResults.ai1} colors={aiColors.ai1} title="AI#1" />
          <ResultSet items={processedResults.ai4} colors={aiColors.ai4} title="AI#4" />
          <ResultSet items={processedResults.ai6} colors={aiColors.ai6} title="AI#6" />
        </div>
      </CardContent>
    </Card>
  );
};