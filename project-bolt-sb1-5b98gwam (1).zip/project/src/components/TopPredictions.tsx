import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { processAI1, processAI4, processAI6 } from '@/lib/ai/processors';
import { coreShapes } from '@/constants/shapes';
import { PatternGrid } from './PatternGrid';

interface TopPredictionsProps {
  input: string;
  output?: string;
}

interface ShapeVariation {
  name: string;
  pattern: any;
  sequences: string[];
  type: 'original' | 'swap';
  matchesOutput?: boolean;
}

export const TopPredictions: React.FC<TopPredictionsProps> = ({ input, output }) => {
  const [copied, setCopied] = React.useState(false);
  const { toast } = useToast();

  const generateSequences = (pattern: any) => {
    const sequences: string[] = [];
    
    pattern.cells.forEach(cell => {
      const baseRow = cell.row;
      const baseNum = parseInt(cell.num);
      
      for (let row = 0; row < 10; row++) {
        if (!sequences[row]) {
          sequences[row] = Array(3).fill('0');
        }
        let num;
        if (row < baseRow) {
          num = (baseNum - (baseRow - row) + 10) % 10;
        } else if (row > baseRow) {
          num = (baseNum + (row - baseRow)) % 10;
        } else {
          num = baseNum;
        }
        sequences[row][cell.col] = num.toString();
      }
    });

    return sequences.map(row => row.join(''));
  };

  const generateSwapVariations = (originalPattern: any): any[] => {
    const variations = [];
    const digits = input.split('');
    
    const swaps = [
      [0, 1], // Swap first two
      [1, 2], // Swap last two
      [0, 2]  // Swap first and last
    ];

    swaps.forEach(([i, j]) => {
      const swappedDigits = [...digits];
      [swappedDigits[i], swappedDigits[j]] = [swappedDigits[j], swappedDigits[i]];
      
      const swappedCells = originalPattern.cells.map((cell, idx) => ({
        ...cell,
        num: swappedDigits[idx]
      }));

      variations.push({
        ...originalPattern,
        cells: swappedCells
      });
    });

    return variations;
  };

  const copyAllShapesNumbers = async () => {
    try {
      const allVariations = getUpdatedShapes();
      const allNumbers = allVariations.map(variation => 
        variation.sequences.join(' ')
      ).join(' ');

      await navigator.clipboard.writeText(allNumbers);
      setCopied(true);
      toast({
        title: "Copied!",
        description: "All shape numbers and variations copied to clipboard",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  const checkOutputMatch = (sequences: string[]): boolean => {
    if (!output) return false;
    return sequences.includes(output);
  };

  const getUpdatedShapes = () => {
    if (input.length !== 3) return [];

    const variations: ShapeVariation[] = [];

    Object.entries(coreShapes).forEach(([name, pattern]) => {
      // Original pattern
      const updatedCells = pattern.cells.map((cell, idx) => ({
        ...cell,
        num: input[idx] || '0'
      }));
      
      const originalPattern = {
        ...pattern,
        cells: updatedCells
      };

      const originalSequences = generateSequences(originalPattern);
      variations.push({
        name: `${name} (Original)`,
        pattern: originalPattern,
        sequences: originalSequences,
        type: 'original',
        matchesOutput: checkOutputMatch(originalSequences)
      });

      // Add swap variations
      const swapVariations = generateSwapVariations(pattern);
      swapVariations.forEach((swapPattern, idx) => {
        const swapSequences = generateSequences(swapPattern);
        variations.push({
          name: `${name} (Swap ${idx + 1})`,
          pattern: swapPattern,
          sequences: swapSequences,
          type: 'swap',
          matchesOutput: checkOutputMatch(swapSequences)
        });
      });
    });

    return variations;
  };

  const shapes = React.useMemo(() => getUpdatedShapes(), [input, output]);
  const matchingShapes = shapes.filter(shape => shape.matchesOutput);

  if (input.length !== 3) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-gray-500">
            Enter a valid 3-digit pattern to see shape variations
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div className="space-y-1">
              <h3 className="text-lg font-semibold">Shape Pattern Variations</h3>
              <p className="text-sm text-gray-500">
                Pattern variations with digit swaps for each shape
              </p>
            </div>
            <div className="flex items-center gap-4">
              {output && (
                <Badge variant="secondary">
                  {matchingShapes.length} matches found
                </Badge>
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={copyAllShapesNumbers}
                className="transition-all duration-200"
              >
                {copied ? (
                  <Check className="h-4 w-4 text-green-500" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
                <span className="ml-2">{copied ? 'Copied!' : 'Copy All Numbers'}</span>
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            {shapes.map(({ name, pattern, sequences, type, matchesOutput }, idx) => (
              <div
                key={`${name}-${idx}`}
                className={`p-4 rounded-lg border transition-colors hover:bg-accent ${
                  type === 'swap' ? 'bg-gray-50' : ''
                } ${matchesOutput ? 'ring-2 ring-green-500' : ''}`}
              >
                <div className="flex flex-col items-center gap-2">
                  <div className="flex items-center gap-2">
                    <div className="text-sm font-medium">{name}</div>
                    {type === 'swap' && (
                      <Badge variant="secondary" className="text-xs">
                        Swap
                      </Badge>
                    )}
                    {matchesOutput && (
                      <Badge variant="success" className="text-xs">
                        Match
                      </Badge>
                    )}
                  </div>
                  <div className="scale-75">
                    <PatternGrid 
                      pattern={pattern} 
                      shapeName={name}
                      showConversion={false}
                      showInput={true}
                    />
                  </div>
                  <div className="w-full mt-2">
                    <div className="text-xs font-medium text-gray-500 mb-1">Sequences:</div>
                    <div className="grid grid-cols-2 gap-1 text-xs font-mono">
                      {sequences.map((seq, idx) => (
                        <div 
                          key={idx} 
                          className={`px-1 rounded ${
                            seq === output ? 'bg-green-100 font-bold' : 
                            type === 'swap' ? 'bg-gray-100' : 'bg-gray-50'
                          }`}
                        >
                          #{idx}: {seq}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <h4 className="font-medium mb-2">Pattern Information</h4>
            <div className="grid grid-cols-3 gap-4">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-white border"></div>
                <span className="text-sm">Original Pattern</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-gray-50 border"></div>
                <span className="text-sm">Swap Variation</span>
              </div>
              {output && (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded border-2 border-green-500"></div>
                  <span className="text-sm">Output Match</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};