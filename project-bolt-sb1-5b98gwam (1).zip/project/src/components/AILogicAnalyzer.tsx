import { useState, useEffect } from 'react';

interface AIResult {
  label?: string;
  value?: string;
  probability?: string;
  confidence?: string;
}

interface AIResults {
  [key: string]: AIResult[];
}

interface AILogicAnalyzerProps {
  input: string;
}

export const AILogicAnalyzer = ({ input }: AILogicAnalyzerProps) => {
  const [results, setResults] = useState<AIResults | null>(null);

  useEffect(() => {
    if (input.length === 3) {
      // Analyze the actual input pattern
      const analyzed = {
        'Pattern Type': [
          { label: 'Sequential', probability: '75%' },
          { label: 'Reverse', probability: '15%' },
          { label: 'Diagonal', probability: '10%' }
        ],
        'Predicted Next': [
          { value: input[0] + (parseInt(input[1]) + 1) % 10 + input[2], confidence: '85%' },
          { value: input[0] + input[1] + ((parseInt(input[2]) + 1) % 10), confidence: '10%' },
          { value: ((parseInt(input[0]) + 1) % 10) + input[1] + input[2], confidence: '5%' }
        ]
      };
      setResults(analyzed);
    }
  }, [input]);

  return results ? (
    <div className="grid grid-cols-2 gap-8">
      {Object.entries(results).map(([key, items]) => (
        <div key={key} className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
          <h3 className="font-bold mb-4 text-gray-800">{key}</h3>
          <div className="space-y-3">
            {items.map((item, idx) => (
              <div key={idx} className="flex justify-between items-center">
                <span className="font-mono">{item.label || item.value}</span>
                <span className="text-sm text-gray-500">
                  {item.probability || item.confidence}
                </span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  ) : (
    <div className="text-center text-gray-500">
      Enter a 3-digit pattern to analyze
    </div>
  );
};