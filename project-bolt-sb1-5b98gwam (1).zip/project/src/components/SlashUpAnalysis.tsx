import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface SlashUpAnalysisProps {
  pattern: string;
}

export const SlashUpAnalysis: React.FC<SlashUpAnalysisProps> = ({ pattern }) => {
  const [copied, setCopied] = React.useState(false);
  const { toast } = useToast();

  const generateSlashUpSequence = (basePattern: string) => {
    const sequences: string[] = [];
    let currentNum = parseInt(basePattern);
    
    // Generate 10 sequences
    for (let i = 0; i < 10; i++) {
      // Format number as 3 digits with leading zeros
      const formattedNum = currentNum.toString().padStart(3, '0');
      sequences.push(formattedNum);
      
      // Add 222 for next sequence, wrapping around 1000
      currentNum = (currentNum + 222) % 1000;
    }
    
    return sequences;
  };

  const copySequences = async () => {
    try {
      const sequences = generateSlashUpSequence(pattern);
      await navigator.clipboard.writeText(sequences.join(' '));
      setCopied(true);
      toast({
        title: "Copied!",
        description: "All sequences copied to clipboard",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  const sequences = generateSlashUpSequence(pattern);

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-semibold">Slash Up Pattern Sequence</h3>
              <p className="text-sm text-gray-500 mt-1">
                Pattern progression with +222 increment
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={copySequences}
              className="transition-all duration-200"
            >
              {copied ? (
                <Check className="h-4 w-4 text-green-500" />
              ) : (
                <Copy className="h-4 w-4" />
              )}
              <span className="ml-2">{copied ? 'Copied!' : 'Copy All'}</span>
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {sequences.map((seq, idx) => (
              <div 
                key={idx}
                className="bg-gray-50 p-4 rounded-lg border-l-4 border-green-300"
              >
                <div className="flex justify-between items-center">
                  <div>
                    <span className="font-medium">Set {idx + 1}</span>
                    <div className="text-sm text-gray-600 mt-1">
                      +222 progression
                    </div>
                  </div>
                  <Badge variant="outline" className="font-mono">
                    {seq}
                  </Badge>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-green-50 p-4 rounded-lg">
            <h4 className="font-medium text-green-800 mb-2">Pattern Information</h4>
            <div className="space-y-2 text-sm text-green-700">
              <p>• Each number increases by 222</p>
              <p>• Sequence wraps around at 1000</p>
              <p>• Maintains consistent upward progression</p>
              <p>• Example: 115 → 337 → 559 → 771 → 993</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};