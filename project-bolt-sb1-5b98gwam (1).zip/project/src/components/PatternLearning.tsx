import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend
} from 'recharts';
import { patternLearningConfig, lineConfig } from '@/lib/charts/config';

interface PatternLearningProps {
  history: Array<{input: string, output: string}>;
  currentInput: string;
  currentOutput: string;
}

interface PatternRule {
  type: string;
  description: string;
  confidence: number;
  examples: Array<{input: string, output: string}>;
}

export const PatternLearning = ({ history, currentInput, currentOutput }: PatternLearningProps) => {
  const [rules, setRules] = React.useState<PatternRule[]>([]);
  const [learningProgress, setLearningProgress] = React.useState(0);

  React.useEffect(() => {
    if (history.length > 0) {
      analyzePatterns();
    }
  }, [history, currentInput, currentOutput]);

  const analyzePatterns = () => {
    const newRules: PatternRule[] = [];
    
    // Analyze numerical relationships
    const numericalRules = findNumericalRules();
    newRules.push(...numericalRules);

    // Analyze position-based patterns
    const positionRules = findPositionRules();
    newRules.push(...positionRules);

    // Calculate learning progress
    const progress = Math.min(history.length * 10, 100);
    setLearningProgress(progress);
    
    setRules(newRules);
  };

  const findNumericalRules = (): PatternRule[] => {
    const rules: PatternRule[] = [];
    const patterns = history.map(({ input, output }) => ({
      input: input.split('').map(Number),
      output: output.split('').map(Number)
    }));

    // Check for consistent differences
    const differences = patterns.map(({ input, output }) =>
      input.map((num, idx) => output[idx] - num)
    );

    const hasConsistentDiff = differences.every(diff =>
      diff.every(d => d === diff[0])
    );

    if (hasConsistentDiff) {
      rules.push({
        type: 'Numerical Progression',
        description: `Consistent numerical difference pattern detected`,
        confidence: 0.85,
        examples: history.slice(-3)
      });
    }

    return rules;
  };

  const findPositionRules = (): PatternRule[] => {
    const rules: PatternRule[] = [];
    
    // Check for position-based transformations
    const positionPatterns = history.map(({ input, output }) =>
      input.split('').map((num, idx) => ({
        position: idx,
        input: num,
        output: output[idx]
      }))
    );

    // Analyze each position
    for (let pos = 0; pos < 3; pos++) {
      const positionData = positionPatterns.map(pattern => pattern[pos]);
      const hasConsistentTransform = positionData.every(
        (data, idx, arr) => idx === 0 || 
          (parseInt(data.output) - parseInt(data.input)) === 
          (parseInt(arr[0].output) - parseInt(arr[0].input))
      );

      if (hasConsistentTransform) {
        rules.push({
          type: `Position ${pos + 1} Pattern`,
          description: `Consistent transformation at position ${pos + 1}`,
          confidence: 0.9,
          examples: history.slice(-2)
        });
      }
    }

    return rules;
  };

  const chartData = React.useMemo(() => {
    return history.map((entry, idx) => ({
      index: idx + 1,
      input: parseInt(entry.input),
      output: parseInt(entry.output),
      difference: parseInt(entry.output) - parseInt(entry.input)
    }));
  }, [history]);

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Pattern Learning Analysis</h3>
            <Badge variant="secondary">
              Learning Progress: {learningProgress}%
            </Badge>
          </div>

          <div className="bg-white p-4 rounded-lg">
            <div className="font-medium mb-4">Pattern History Analysis</div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid {...patternLearningConfig.grid} />
                  <XAxis {...patternLearningConfig.axis} dataKey="index" />
                  <YAxis {...patternLearningConfig.axis} />
                  <Tooltip contentStyle={patternLearningConfig.tooltip.style} />
                  <Legend {...patternLearningConfig.legend} />
                  
                  {Object.entries(patternLearningConfig.lines).map(([key, config]) => (
                    <Line
                      key={key}
                      {...lineConfig}
                      dataKey={key}
                      stroke={config.stroke}
                      name={config.name}
                    />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="font-medium">Learned Pattern Rules</h4>
            <div className="grid gap-4">
              {rules.map((rule, idx) => (
                <div 
                  key={idx}
                  className="bg-gray-50 p-4 rounded-lg border-l-4 border-blue-500"
                >
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium">{rule.type}</span>
                    <Badge variant="outline">
                      {(rule.confidence * 100).toFixed(0)}% confidence
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">
                    {rule.description}
                  </p>
                  <div className="text-sm">
                    <div className="font-medium text-gray-500 mb-2">Examples:</div>
                    <div className="space-y-1">
                      {rule.examples.map((example, i) => (
                        <div key={i} className="flex gap-4 font-mono">
                          <span>{example.input}</span>
                          <span>→</span>
                          <span>{example.output}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}

              {rules.length === 0 && (
                <div className="text-center text-gray-500 py-4">
                  Add more pattern examples to start learning rules
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};