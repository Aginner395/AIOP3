import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { naturalToAi } from '@/lib/ai/constants';
import { processAI1, processAI4, processAI6 } from '@/lib/ai/processors';
import { detectShapes } from '@/lib/shapes/shapeDetector';

interface AutomatedPredictionProps {
  input: string;
  predictions: string[];
}

interface PredictionResult {
  value: string;
  confidence: number;
  sources: string[];
  reasoning: string[];
  matchType?: 'ai' | 'natural' | 'shape';
}

export const AutomatedPrediction: React.FC<AutomatedPredictionProps> = ({
  input,
  predictions
}) => {
  const [results, setResults] = React.useState<PredictionResult[]>([]);

  React.useEffect(() => {
    if (input.length === 3) {
      analyzePredictions();
    }
  }, [input, predictions]);

  const analyzePredictions = () => {
    const allResults = new Map<string, PredictionResult>();

    // Process all AI sets
    const aiSets = [
      ...processAI1(input),
      ...processAI4(input),
      ...processAI6(input)
    ];

    // Analyze AI patterns
    aiSets.forEach(set => {
      Object.values(set.patterns).forEach(pattern => {
        if (!allResults.has(pattern)) {
          allResults.set(pattern, {
            value: pattern,
            confidence: 0,
            sources: [],
            reasoning: [],
            matchType: 'ai'
          });
        }
        
        const result = allResults.get(pattern)!;
        result.confidence += 0.15;
        result.sources.push(`AI Set ${set.aiSet}`);
        result.reasoning.push('Matches AI pattern transformation');
      });
    });

    // Natural number progression (+111)
    const naturalBase = parseInt(input);
    for (let i = 0; i < 3; i++) {
      const nextNum = ((naturalBase + ((i + 1) * 111)) % 1000).toString().padStart(3, '0');
      if (!allResults.has(nextNum)) {
        allResults.set(nextNum, {
          value: nextNum,
          confidence: 0.8 - (i * 0.1),
          sources: ['Natural Progression'],
          reasoning: ['Sequential +111 pattern'],
          matchType: 'natural'
        });
      }
    }

    // Shape-based predictions
    const shapes = detectShapes(input);
    shapes.forEach(shape => {
      const shapeBase = parseInt(input);
      const shapeIncrement = shape.name.includes('Up') ? 222 : 111;
      const nextNum = ((shapeBase + shapeIncrement) % 1000).toString().padStart(3, '0');
      
      if (!allResults.has(nextNum)) {
        allResults.set(nextNum, {
          value: nextNum,
          confidence: shape.confidence * 0.9,
          sources: [`Shape Pattern: ${shape.name}`],
          reasoning: shape.reasons,
          matchType: 'shape'
        });
      }
    });

    // Check for direct AI conversion
    const aiConverted = input.split('').map(d => naturalToAi[d]).join('');
    if (!allResults.has(aiConverted)) {
      allResults.set(aiConverted, {
        value: aiConverted,
        confidence: 0.95,
        sources: ['Direct AI Conversion'],
        reasoning: ['Standard AI number transformation'],
        matchType: 'ai'
      });
    }

    // Add predictions from components
    predictions.forEach(pred => {
      if (!allResults.has(pred)) {
        allResults.set(pred, {
          value: pred,
          confidence: 0.7,
          sources: ['Pattern Analysis'],
          reasoning: ['Derived from pattern analysis'],
          matchType: 'ai'
        });
      }
      const result = allResults.get(pred)!;
      result.confidence += 0.2;
      result.sources.push('Component Analysis');
    });

    // Sort by confidence and limit to top predictions
    const sortedResults = Array.from(allResults.values())
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, 5);

    setResults(sortedResults);
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Automated Pattern Prediction</h3>
            <Badge variant="secondary">
              {results.length} predictions generated
            </Badge>
          </div>

          <div className="grid gap-4">
            {results.map((result, idx) => (
              <div 
                key={idx} 
                className={`bg-gray-50 p-4 rounded-lg border-l-4 ${
                  result.matchType === 'ai' ? 'border-blue-500' :
                  result.matchType === 'natural' ? 'border-green-500' :
                  'border-purple-500'
                }`}
              >
                <div className="flex justify-between items-center mb-3">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xl">{result.value}</span>
                    {idx === 0 && (
                      <Badge variant="success">Most Likely</Badge>
                    )}
                    {result.matchType && (
                      <Badge variant="outline" className="capitalize">
                        {result.matchType} Pattern
                      </Badge>
                    )}
                  </div>
                  <Badge variant="outline">
                    {(result.confidence * 100).toFixed(0)}% confidence
                  </Badge>
                </div>

                <div className="space-y-3">
                  <div>
                    <div className="text-sm font-medium text-gray-500">Sources:</div>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {Array.from(new Set(result.sources)).map((source, i) => (
                        <Badge key={i} variant="secondary">
                          {source}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-sm font-medium text-gray-500">Reasoning:</div>
                    <div className="text-sm space-y-1 mt-1">
                      {Array.from(new Set(result.reasoning)).map((reason, i) => (
                        <div key={i} className="text-gray-600">• {reason}</div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {results.length === 0 && (
              <div className="text-center text-gray-500 py-4">
                Analyzing patterns to generate predictions...
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};