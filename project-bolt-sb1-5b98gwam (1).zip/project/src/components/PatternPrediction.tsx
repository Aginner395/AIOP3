import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { naturalToAi } from '@/lib/ai/constants';
import { processAI1, processAI2, processAI3, processAI4, processAI5, processAI6 } from '@/lib/ai/processors';

interface PatternPredictionProps {
  input: string;
  prediction: string;
}

interface PredictionAnalysis {
  type: string;
  confidence: number;
  reasoning: string[];
  matchedSets: string[];
}

export const PatternPrediction: React.FC<PatternPredictionProps> = ({
  input,
  prediction
}) => {
  const [analysis, setAnalysis] = React.useState<PredictionAnalysis[]>([]);

  React.useEffect(() => {
    if (input.length === 3 && prediction.length === 3) {
      analyzePrediction();
    }
  }, [input, prediction]);

  const analyzePrediction = () => {
    const analyses: PredictionAnalysis[] = [];

    // Get all AI sets for analysis
    const ai1Sets = processAI1(input);
    const ai2Sets = processAI2(input);
    const ai3Sets = processAI3(input);
    const ai4Sets = processAI4(input);
    const ai5Sets = processAI5(input);
    const ai6Sets = processAI6(input);

    // Check for direct AI conversion match
    const aiConverted = input.split('').map(d => naturalToAi[d]).join('');
    if (prediction === aiConverted) {
      analyses.push({
        type: 'AI Conversion',
        confidence: 0.95,
        reasoning: [
          'Direct AI number conversion pattern',
          'Follows standard conversion rules',
          'High probability transformation'
        ],
        matchedSets: [aiConverted]
      });
    }

    // Check for pattern matches in AI sets
    const allSets = [...ai1Sets, ...ai2Sets, ...ai3Sets, ...ai4Sets, ...ai5Sets, ...ai6Sets];
    const matchingSets = allSets.filter(set => {
      const patterns = Object.values(set.patterns);
      return patterns.includes(prediction);
    });

    if (matchingSets.length > 0) {
      analyses.push({
        type: 'AI Set Match',
        confidence: 0.9,
        reasoning: [
          'Matches known AI pattern sets',
          `Found in ${matchingSets.length} AI combinations`,
          'Follows established transformation rules'
        ],
        matchedSets: matchingSets.map(set => set.aiSet)
      });
    }

    // Check for numerical relationships
    const inputNums = input.split('').map(Number);
    const predictionNums = prediction.split('').map(Number);
    const differences = inputNums.map((num, idx) => predictionNums[idx] - num);

    if (differences.every(d => d === differences[0])) {
      analyses.push({
        type: 'Linear Pattern',
        confidence: 0.85,
        reasoning: [
          `Consistent difference of ${differences[0]}`,
          'Regular numerical progression',
          'Follows mathematical sequence'
        ],
        matchedSets: [prediction]
      });
    }

    setAnalysis(analyses);
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Prediction Analysis</h3>
            <Badge variant="secondary">
              {analysis.length} pattern matches found
            </Badge>
          </div>

          <div className="grid gap-4">
            {analysis.map((result, idx) => (
              <div key={idx} className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-medium">{result.type}</span>
                  <Badge variant="outline">
                    {(result.confidence * 100).toFixed(0)}% confidence
                  </Badge>
                </div>

                <div className="space-y-3">
                  <div className="text-sm space-y-1">
                    {result.reasoning.map((reason, i) => (
                      <div key={i} className="text-gray-600">• {reason}</div>
                    ))}
                  </div>

                  <div className="mt-3">
                    <div className="text-sm font-medium text-gray-500">Matched Sets:</div>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {result.matchedSets.map((set, i) => (
                        <Badge key={i} variant="secondary" className="font-mono">
                          {set}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {analysis.length === 0 && (
              <div className="text-center text-gray-500 py-4">
                No matching patterns found for this prediction
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};