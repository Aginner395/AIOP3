import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import lotteryData from '@/data/lottery.json';

interface HistoricalDataProps {
  pattern: string;
}

export const HistoricalData: React.FC<HistoricalDataProps> = ({ pattern }) => {
  const [page, setPage] = React.useState(1);
  const itemsPerPage = 10;

  const data = React.useMemo(() => {
    // Reverse the array to show oldest first (bottom to top)
    const reversedDraws = [...lotteryData.draws].reverse();
    
    // Create separate arrays for each analysis type
    const middayToEvening = reversedDraws.map(draw => ({
      date: draw.date,
      from: draw.midday.pick3,
      to: draw.evening.pick3,
      matches: calculateMatches(draw.midday.pick3, draw.evening.pick3)
    }));

    const middayToMidday = reversedDraws.slice(0, -1).map((draw, i) => ({
      date: `${draw.date} → ${reversedDraws[i + 1].date}`,
      from: draw.midday.pick3,
      to: reversedDraws[i + 1].midday.pick3,
      matches: calculateMatches(draw.midday.pick3, reversedDraws[i + 1].midday.pick3)
    }));

    const eveningToEvening = reversedDraws.slice(0, -1).map((draw, i) => ({
      date: `${draw.date} → ${reversedDraws[i + 1].date}`,
      from: draw.evening.pick3,
      to: reversedDraws[i + 1].evening.pick3,
      matches: calculateMatches(draw.evening.pick3, reversedDraws[i + 1].evening.pick3)
    }));

    return {
      middayToEvening,
      middayToMidday,
      eveningToEvening
    };
  }, []);

  function calculateMatches(from: string, to: string): number {
    if (!from || !to) return 0;
    return from.split('').filter(digit => to.includes(digit)).length;
  }

  const renderTable = (items: Array<{ date: string; from: string; to: string; matches: number }>) => {
    const paginatedItems = items.slice((page - 1) * itemsPerPage, page * itemsPerPage);
    const totalMatches = items.reduce((sum, item) => sum + item.matches, 0);
    const perfectMatches = items.filter(item => item.matches === 3).length;
    const matchRate = (totalMatches / (items.length * 3) * 100).toFixed(1);

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="font-medium mb-2">Total Matches</div>
            <div className="text-2xl font-bold">{totalMatches}</div>
            <div className="text-sm text-gray-500">From {items.length} comparisons</div>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="font-medium mb-2">Match Rate</div>
            <div className="text-2xl font-bold">{matchRate}%</div>
            <div className="text-sm text-gray-500">Average match frequency</div>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="font-medium mb-2">Perfect Matches</div>
            <div className="text-2xl font-bold">{perfectMatches}</div>
            <div className="text-sm text-gray-500">Complete pattern matches</div>
          </div>
        </div>

        <div className="bg-white rounded-lg border">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="p-3 text-left">Date</th>
                <th className="p-3 text-left">From</th>
                <th className="p-3 text-left">To</th>
                <th className="p-3 text-left">Matches</th>
              </tr>
            </thead>
            <tbody>
              {paginatedItems.map((item, idx) => (
                <tr key={idx} className="border-b">
                  <td className="p-3">{item.date}</td>
                  <td className="p-3 font-mono">{item.from}</td>
                  <td className="p-3 font-mono">{item.to}</td>
                  <td className="p-3">{item.matches}</td>
                </tr>
              ))}
            </tbody>
          </table>
          
          <div className="flex justify-end p-4 gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
            >
              <ChevronLeft className="h-4 w-4" />
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage(p => p + 1)}
              disabled={page * itemsPerPage >= items.length}
            >
              Next
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Historical Analysis</h3>
            <Badge variant="secondary">
              {lotteryData.metadata.dateRange.start} - {lotteryData.metadata.dateRange.end}
            </Badge>
          </div>

          <Tabs defaultValue="middayToEvening" onValueChange={() => setPage(1)}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="middayToEvening">Midday → Evening</TabsTrigger>
              <TabsTrigger value="middayToMidday">Midday → Midday</TabsTrigger>
              <TabsTrigger value="eveningToEvening">Evening → Evening</TabsTrigger>
            </TabsList>

            <TabsContent value="middayToEvening">
              {renderTable(data.middayToEvening)}
            </TabsContent>

            <TabsContent value="middayToMidday">
              {renderTable(data.middayToMidday)}
            </TabsContent>

            <TabsContent value="eveningToEvening">
              {renderTable(data.eveningToEvening)}
            </TabsContent>
          </Tabs>
        </div>
      </CardContent>
    </Card>
  );
};