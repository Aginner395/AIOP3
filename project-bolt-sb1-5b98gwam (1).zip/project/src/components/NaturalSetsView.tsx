import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PatternResult } from '@/types/generator';
import { processAI1, processAI4, processAI6 } from '@/lib/ai/processors';
import { naturalToAi } from '@/lib/ai/constants';
import { NaturalGrid } from './NaturalGrid';

interface NaturalSet {
  aiEngine: string;
  aiSet: string;
  pattern: string;
  type: 'lll' | 'llh' | 'lhl' | 'lhh';
}

interface NaturalSetsViewProps {
  input: string;
}

export const NaturalSetsView: React.FC<NaturalSetsViewProps> = ({ input }) => {
  const [naturalSets, setNaturalSets] = React.useState<NaturalSet[]>([]);
  const [aiSets, setAiSets] = React.useState<NaturalSet[]>([]);

  React.useEffect(() => {
    if (input.length === 3) {
      const allNaturalSets: NaturalSet[] = [];
      const allAiSets: NaturalSet[] = [];

      // Process each AI engine
      const processEngines = [
        { fn: processAI1, name: 'AI#1' },
        { fn: processAI4, name: 'AI#4' },
        { fn: processAI6, name: 'AI#6' }
      ];

      processEngines.forEach(({ fn, name }) => {
        const results = fn(input);
        results.forEach((result: PatternResult) => {
          // Add each pattern type for natural sets
          Object.entries(result.patterns).forEach(([type, pattern]) => {
            allNaturalSets.push({
              aiEngine: name,
              aiSet: result.aiSet,
              pattern,
              type: type as 'lll' | 'llh' | 'lhl' | 'lhh'
            });
          });

          // Add AI converted patterns
          const aiPattern = result.aiSet;
          allAiSets.push({
            aiEngine: name,
            aiSet: result.aiSet,
            pattern: aiPattern,
            type: 'lll'
          });
        });
      });

      // Sort sets by pattern for grouping
      const sortedNaturalSets = allNaturalSets.sort((a, b) => a.pattern.localeCompare(b.pattern));
      const sortedAiSets = allAiSets.sort((a, b) => a.pattern.localeCompare(b.pattern));
      
      setNaturalSets(sortedNaturalSets);
      setAiSets(sortedAiSets);
    }
  }, [input]);

  // Group sets by pattern
  const groupedNaturalSets = React.useMemo(() => {
    const groups: Record<string, NaturalSet[]> = {};
    naturalSets.forEach(set => {
      if (!groups[set.pattern]) {
        groups[set.pattern] = [];
      }
      groups[set.pattern].push(set);
    });
    return groups;
  }, [naturalSets]);

  const groupedAiSets = React.useMemo(() => {
    const groups: Record<string, NaturalSet[]> = {};
    aiSets.forEach(set => {
      if (!groups[set.pattern]) {
        groups[set.pattern] = [];
      }
      groups[set.pattern].push(set);
    });
    return groups;
  }, [aiSets]);

  const renderSetGroup = (pattern: string, sets: NaturalSet[]) => (
    <Card key={pattern} className="p-4">
      <div className="flex justify-between items-center mb-4">
        <div className="text-xl font-mono">{pattern}</div>
        <Badge variant="secondary">
          {sets.length} occurrences
        </Badge>
      </div>

      <div className="grid gap-2">
        {sets.map((set, idx) => (
          <div 
            key={`${set.aiEngine}-${set.aiSet}-${idx}`}
            className="flex items-center justify-between bg-gray-50 p-2 rounded"
          >
            <div className="flex items-center gap-4">
              <Badge variant="outline">{set.aiEngine}</Badge>
              <span className="font-mono">{set.aiSet}</span>
            </div>
            <Badge>{set.type}</Badge>
          </div>
        ))}
      </div>
    </Card>
  );

  return (
    <div className="space-y-8">
      <NaturalGrid pattern={input} />
      
      <div className="grid grid-cols-2 gap-8">
        {/* Natural Sets */}
        <Card className="w-full">
          <CardContent className="p-6">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold">Natural Sets</h2>
                <div className="text-sm text-gray-500">
                  Total Patterns: {Object.keys(groupedNaturalSets).length}
                </div>
              </div>

              <div className="grid gap-4">
                {Object.entries(groupedNaturalSets).map(([pattern, sets]) => 
                  renderSetGroup(pattern, sets)
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AI Sets */}
        <Card className="w-full">
          <CardContent className="p-6">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold">AI Sets</h2>
                <div className="text-sm text-gray-500">
                  Total Patterns: {Object.keys(groupedAiSets).length}
                </div>
              </div>

              <div className="grid gap-4">
                {Object.entries(groupedAiSets).map(([pattern, sets]) => 
                  renderSetGroup(pattern, sets)
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};