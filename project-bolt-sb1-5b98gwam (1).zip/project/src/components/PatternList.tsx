import { Pattern } from '@/types/patterns';
import { PatternDisplay } from './PatternDisplay';

interface PatternListProps {
  patterns: Pattern[];
}

export const PatternList = ({ patterns }: PatternListProps) => (
  <div className="grid grid-cols-1 gap-4">
    {patterns.map((pattern, idx) => (
      <PatternDisplay key={idx} pattern={pattern} />
    ))}
  </div>
);