import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { detectShapes } from '@/lib/shapes/shapeDetector';
import { PatternGrid } from './PatternGrid';
import { coreShapes } from '@/constants/shapes';

interface ShapeDetectionProps {
  pattern: string;
}

export const ShapeDetection: React.FC<ShapeDetectionProps> = ({ pattern }) => {
  const matches = React.useMemo(() => detectShapes(pattern), [pattern]);

  if (matches.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-gray-500">
            No pattern shape detected
          </div>
        </CardContent>
      </Card>
    );
  }

  const bestMatch = matches[0];

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Shape Pattern Analysis</h3>
            <Badge variant="success">
              {bestMatch.name} Pattern Detected
            </Badge>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg border-l-4 border-green-500">
            <div className="flex justify-between items-center mb-4">
              <span className="font-medium">{bestMatch.name}</span>
              <Badge variant="outline">
                {(bestMatch.confidence * 100).toFixed(0)}% confidence
              </Badge>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <div className="text-sm font-medium text-gray-500 mb-2">Pattern Shape</div>
                <div className="scale-75 origin-left">
                  <PatternGrid pattern={coreShapes[bestMatch.name]} />
                </div>
              </div>

              <div>
                <div className="text-sm font-medium text-gray-500 mb-2">Pattern Characteristics</div>
                <ul className="space-y-1 text-sm">
                  {bestMatch.reasons.map((reason, i) => (
                    <li key={i} className="text-gray-600">• {reason}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {matches.length > 1 && (
            <div className="mt-4">
              <div className="text-sm font-medium text-gray-500 mb-2">Alternative Patterns</div>
              <div className="grid gap-2">
                {matches.slice(1).map((match, idx) => (
                  <div key={idx} className="bg-gray-50 p-3 rounded-lg">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">{match.name}</span>
                      <Badge variant="outline">
                        {(match.confidence * 100).toFixed(0)}% confidence
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};