import { PatternCell } from '@/types/patterns';
import { naturalToAi } from '@/constants/patterns';

interface ShapeGridProps {
  cells: PatternCell[];
  color: string;
  showConversion?: boolean;
  showInput?: boolean;
  scale?: string;
}

export const ShapeGrid = ({ 
  cells, 
  color, 
  showConversion = false, 
  showInput = false,
  scale = 'scale-100'
}: ShapeGridProps) => {
  return (
    <div className={`flex ${scale}`}>
      <div className="flex flex-col pr-2">
        {[...Array(10)].map((_, i) => (
          <div key={i} className="h-6 flex items-center justify-end text-xs text-gray-500 w-4">
            {i}
          </div>
        ))}
      </div>
      <div className="border border-gray-300">
        {[...Array(10)].map((_, row) => (
          <div key={row} className="flex">
            {[...Array(3)].map((_, col) => {
              const cell = cells.find(c => c.row === row && c.col === col);
              return (
                <div 
                  key={col} 
                  className={`
                    w-6 h-6 border-r border-b border-gray-300 
                    flex items-center justify-center text-sm
                    ${cell ? color + ' text-black' : 'bg-white'}
                    ${showInput ? 'cursor-pointer hover:bg-gray-50' : ''}
                  `}
                >
                  {cell && (showConversion ? naturalToAi[cell.num] : cell.num)}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};