import React from 'react';
import { Card } from '@/components/ui/card';
import { naturalToAi } from '@/lib/ai/constants';
import { detectShapes } from '@/lib/shapes/shapeDetector';

interface AIGridProps {
  pattern: string;
  isOutput?: boolean;
}

export const AIGrid: React.FC<AIGridProps> = ({ pattern, isOutput = false }) => {
  const generateGrid = () => {
    const grid = Array(10).fill(null).map(() => Array(3).fill(''));
    
    // Convert initial pattern to AI format
    const aiPattern = pattern.split('').map(d => naturalToAi[d]).join('');
    
    // Generate Slash Up sequence (+222 progression)
    for (let row = 0; row < 10; row++) {
      for (let col = 0; col < 3; col++) {
        let baseNum = parseInt(aiPattern[col]);
        // Add 222 for each row progression, wrapping around at 10
        let value = ((baseNum + (row * 2)) % 10).toString();
        grid[row][col] = value;
      }
    }
    
    return grid;
  };

  const findPatternRepetitions = (grid: string[][]) => {
    const repetitions: number[] = [];
    const aiPattern = pattern.split('').map(d => naturalToAi[d]).join('');
    
    // Check each row for pattern matches
    grid.forEach((row, idx) => {
      const rowPattern = row.join('');
      if (rowPattern === aiPattern) {
        repetitions.push(idx);
      }
    });
    
    return repetitions;
  };

  const grid = generateGrid();
  const aiPattern = pattern.split('').map(d => naturalToAi[d]).join('');
  const repetitions = findPatternRepetitions(grid);

  // Detect shapes in the pattern
  const shapes = detectShapes(pattern);
  const dominantShape = shapes.length > 0 ? shapes[0] : null;

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <h3 className="text-lg font-medium">
          {isOutput ? 'Output AI Pattern Grid' : 'AI Pattern Grid'}
        </h3>
        <div className="flex justify-center">
          <div className="flex">
            <div className="flex flex-col pr-2">
              {[...Array(10)].map((_, i) => (
                <div key={i} className="h-8 flex items-center justify-end text-xs text-gray-500 w-4">
                  {i}
                </div>
              ))}
            </div>
            <div className="border border-gray-300 rounded-lg overflow-hidden">
              {grid.map((row, rowIndex) => {
                const isPatternRow = repetitions.includes(rowIndex);
                const isShapeRow = dominantShape?.positions.some(([r]) => r === rowIndex);
                
                return (
                  <div key={rowIndex} className="flex relative">
                    {/* Pattern repetition indicator */}
                    {isPatternRow && (
                      <div className="absolute -left-2 top-1/2 -translate-y-1/2 w-1 h-1 bg-green-500 rounded-full" />
                    )}
                    {row.map((cell, colIndex) => {
                      const isInputDigit = cell === aiPattern[colIndex];
                      const isShapePosition = dominantShape?.positions.some(
                        ([r, c]) => r === rowIndex && c === colIndex
                      );
                      
                      return (
                        <div
                          key={colIndex}
                          className={`
                            w-8 h-8 border-r border-b border-gray-200
                            flex items-center justify-center text-sm font-mono
                            ${isInputDigit && isPatternRow ? 'bg-green-100 font-bold ring-2 ring-green-400' : 'bg-white'}
                            ${isPatternRow ? 'bg-green-50' : ''}
                            ${isShapePosition ? 'bg-yellow-100 font-bold ring-2 ring-yellow-400' : ''}
                            text-green-600
                            transition-colors duration-200
                          `}
                        >
                          {cell}
                        </div>
                      );
                    })}
                    {/* Pattern shape line */}
                    {isPatternRow && rowIndex > 0 && repetitions.includes(rowIndex - 1) && (
                      <div className="absolute left-0 -top-[1px] w-full h-[2px] bg-green-300" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        <div className="text-sm text-gray-500 text-center">
          Pattern repeats at rows: {repetitions.join(', ')}
        </div>
        {dominantShape && (
          <div className="bg-yellow-50 p-4 rounded-lg">
            <h4 className="font-medium text-yellow-800 mb-2">Detected Shape Pattern</h4>
            <div className="space-y-2 text-sm text-yellow-700">
              <p>• Pattern Type: {dominantShape.name}</p>
              <p>• Confidence: {(dominantShape.confidence * 100).toFixed(0)}%</p>
              {dominantShape.reasons.map((reason, idx) => (
                <p key={idx}>• {reason}</p>
              ))}
            </div>
          </div>
        )}
        <div className="bg-green-50 p-4 rounded-lg">
          <h4 className="font-medium text-green-800 mb-2">AI Pattern Sequence</h4>
          <div className="space-y-2 text-sm text-green-700">
            <p>• Slash Up progression (+222)</p>
            <p>• Example: 115 → 337 → 559 → 771 → 993</p>
            <p>• Each number increases by 222</p>
            <p>• Maintains consistent upward pattern</p>
          </div>
        </div>
      </div>
    </Card>
  );
};