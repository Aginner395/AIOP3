import { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { ShapeSelector } from './ShapeSelector';
import { ShapeDisplay } from './ShapeDisplay';
import { coreShapes } from '@/constants/shapes';

export const CoreShapesPanel = () => {
  const [selectedShape, setSelectedShape] = useState<string | null>(null);

  return (
    <Card className="w-full">
      <CardContent className="p-8">
        <h2 className="text-3xl font-bold mb-8 text-gray-800">Core Pattern Shapes</h2>
        
        <div className="space-y-8">
          <ShapeSelector
            shapes={coreShapes}
            selectedShape={selectedShape}
            onSelectShape={setSelectedShape}
          />

          {selectedShape && (
            <ShapeDisplay shape={coreShapes[selectedShape]} />
          )}
        </div>
      </CardContent>
    </Card>
  );
};