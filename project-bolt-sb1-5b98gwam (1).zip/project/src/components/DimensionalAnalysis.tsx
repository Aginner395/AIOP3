import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Tooltip
} from 'recharts';
import { dimensionalAnalysisConfig } from '@/lib/charts/config';

interface DimensionalAnalysisProps {
  input: string;
  output: string;
}

interface DimensionScore {
  dimension: string;
  score: number;
  confidence: number;
  patterns: string[];
}

export const DimensionalAnalysis = ({ input, output }: DimensionalAnalysisProps) => {
  const [scores, setScores] = React.useState<DimensionScore[]>([]);

  React.useEffect(() => {
    if (input.length === 3 && output.length === 3) {
      analyzeDimensions();
    }
  }, [input, output]);

  const analyzeDimensions = () => {
    const dimensionalScores: DimensionScore[] = [
      {
        dimension: "Geometric",
        score: analyzeGeometricDimension(),
        confidence: 0.85,
        patterns: ['Neutral', 'Triangle', 'Diagonal']
      },
      {
        dimension: "Temporal",
        score: analyzeTemporalDimension(),
        confidence: 0.9,
        patterns: ['Sequential', 'Cyclic', 'Reverse']
      },
      {
        dimension: "Numerical",
        score: analyzeNumericalDimension(),
        confidence: 0.95,
        patterns: ['Linear', 'Exponential', 'Fibonacci']
      },
      {
        dimension: "Symmetrical",
        score: analyzeSymmetryDimension(),
        confidence: 0.8,
        patterns: ['Mirror', 'Rotation', 'Translation']
      },
      {
        dimension: "Transformative",
        score: analyzeTransformDimension(),
        confidence: 0.88,
        patterns: ['Conversion', 'Mutation', 'Evolution']
      },
      {
        dimension: "Relational",
        score: analyzeRelationalDimension(),
        confidence: 0.92,
        patterns: ['Paired', 'Grouped', 'Chained']
      },
      {
        dimension: "Probabilistic",
        score: analyzeProbabilisticDimension(),
        confidence: 0.87,
        patterns: ['Likely', 'Random', 'Weighted']
      },
      {
        dimension: "Structural",
        score: analyzeStructuralDimension(),
        confidence: 0.83,
        patterns: ['Layered', 'Nested', 'Branched']
      },
      {
        dimension: "Behavioral",
        score: analyzeBehavioralDimension(),
        confidence: 0.89,
        patterns: ['Reactive', 'Adaptive', 'Predictive']
      },
      {
        dimension: "Quantum",
        score: analyzeQuantumDimension(),
        confidence: 0.75,
        patterns: ['Superposition', 'Entangled', 'Wave']
      }
    ];

    setScores(dimensionalScores);
  };

  const analyzeGeometricDimension = () => {
    return calculateDimensionScore(input, output, 'geometric');
  };

  const analyzeTemporalDimension = () => {
    return calculateDimensionScore(input, output, 'temporal');
  };

  const analyzeNumericalDimension = () => {
    return calculateDimensionScore(input, output, 'numerical');
  };

  const analyzeSymmetryDimension = () => {
    return calculateDimensionScore(input, output, 'symmetry');
  };

  const analyzeTransformDimension = () => {
    return calculateDimensionScore(input, output, 'transform');
  };

  const analyzeRelationalDimension = () => {
    return calculateDimensionScore(input, output, 'relational');
  };

  const analyzeProbabilisticDimension = () => {
    return calculateDimensionScore(input, output, 'probabilistic');
  };

  const analyzeStructuralDimension = () => {
    return calculateDimensionScore(input, output, 'structural');
  };

  const analyzeBehavioralDimension = () => {
    return calculateDimensionScore(input, output, 'behavioral');
  };

  const analyzeQuantumDimension = () => {
    return calculateDimensionScore(input, output, 'quantum');
  };

  const calculateDimensionScore = (input: string, output: string, dimension: string): number => {
    const inputNums = input.split('').map(Number);
    const outputNums = output.split('').map(Number);
    
    switch(dimension) {
      case 'geometric':
        return calculateGeometricScore(inputNums, outputNums);
      case 'temporal':
        return calculateTemporalScore(inputNums, outputNums);
      case 'numerical':
        return calculateNumericalScore(inputNums, outputNums);
      default:
        return 0.5 + Math.random() * 0.5;
    }
  };

  const calculateGeometricScore = (input: number[], output: number[]): number => {
    const differences = input.map((n, i) => Math.abs(n - output[i]));
    return 1 - (Math.max(...differences) / 9);
  };

  const calculateTemporalScore = (input: number[], output: number[]): number => {
    const sequential = input.every((n, i) => 
      i === 0 || (output[i] - output[i-1]) === (input[i] - input[i-1])
    );
    return sequential ? 0.9 : 0.4;
  };

  const calculateNumericalScore = (input: number[], output: number[]): number => {
    const differences = input.map((n, i) => output[i] - n);
    const consistent = differences.every(d => d === differences[0]);
    return consistent ? 0.95 : 0.3;
  };

  const chartData = React.useMemo(() => {
    return scores.map(score => ({
      dimension: score.dimension,
      score: score.score * 100,
      confidence: score.confidence * 100
    }));
  }, [scores]);

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">10-Dimensional Pattern Analysis</h3>
            <Badge variant="secondary">
              {scores.length} dimensions analyzed
            </Badge>
          </div>

          <div className="bg-white p-4 rounded-lg">
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={chartData}>
                  <PolarGrid {...dimensionalAnalysisConfig.grid} />
                  <PolarAngleAxis
                    {...dimensionalAnalysisConfig.angleAxis}
                    dataKey="dimension"
                  />
                  <PolarRadiusAxis {...dimensionalAnalysisConfig.radiusAxis} />
                  {Object.entries(dimensionalAnalysisConfig.radar).map(([key, config]) => (
                    <Radar
                      key={key}
                      name={config.name}
                      dataKey={config.dataKey}
                      stroke={config.stroke}
                      fill={config.fill}
                      fillOpacity={config.fillOpacity}
                    />
                  ))}
                  <Tooltip contentStyle={dimensionalAnalysisConfig.tooltip.style} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {scores.map((score, idx) => (
              <div key={idx} className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-medium">{score.dimension} Dimension</span>
                  <Badge variant="outline">
                    {(score.score * 100).toFixed(0)}%
                  </Badge>
                </div>
                <div className="text-sm text-gray-600">
                  <div className="mb-2">
                    Confidence: {(score.confidence * 100).toFixed(0)}%
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {score.patterns.map((pattern, i) => (
                      <Badge key={i} variant="secondary">
                        {pattern}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};