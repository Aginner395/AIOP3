import React from 'react';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { VideoPatternAnalyzer } from './VideoPatternAnalyzer';
import { VideoPatternSequence } from './VideoPatternSequence';
import { VideoPatternFormation } from './VideoPatternFormation';

interface CombinedVideoProps {
  pattern: string;
}

export const CombinedVideoAnalysis: React.FC<CombinedVideoProps> = ({
  pattern
}) => {
  const [activeFormation, setActiveFormation] = React.useState<'neutral' | 'bottomUp' | 'topUp' | 'triangle'>('neutral');

  const handleAnalysisComplete = (result: any) => {
    setActiveFormation(result.type);
  };

  return (
    <Card className="p-6">
      <Tabs defaultValue="analyzer">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="analyzer">Pattern Analysis</TabsTrigger>
          <TabsTrigger value="sequence">Sequence</TabsTrigger>
          <TabsTrigger value="formation">Formation</TabsTrigger>
        </TabsList>

        <TabsContent value="analyzer" className="mt-4">
          <VideoPatternAnalyzer 
            pattern={pattern}
            onAnalysisComplete={handleAnalysisComplete}
          />
        </TabsContent>

        <TabsContent value="sequence" className="mt-4">
          <VideoPatternSequence 
            startPattern={pattern}
            rows={10}
          />
        </TabsContent>

        <TabsContent value="formation" className="mt-4">
          <VideoPatternFormation 
            pattern={pattern}
            type={activeFormation}
          />
        </TabsContent>
      </Tabs>
    </Card>
  );
};