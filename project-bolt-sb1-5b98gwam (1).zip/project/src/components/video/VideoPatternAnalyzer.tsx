import React from 'react';
import { Card } from '@/components/ui/card';
import { motion } from 'framer-motion';

interface VideoPatternProps {
  pattern: string;
  onAnalysisComplete?: (result: VideoAnalysisResult) => void;
}

interface VideoAnalysisResult {
  type: 'neutral' | 'bottomUp' | 'topUp' | 'triangle';
  confidence: number;
  videoCode: VideoCode[];
}

interface VideoCode {
  value: string;
  position: number;
  set: number;
}

// Get positions for active shapes based on formation type
const getFormationPositions = (type: 'neutral' | 'bottomUp' | 'topUp' | 'triangle'): number[] => {
  switch (type) {
    case 'neutral':
      return [3, 4, 5]; // Middle row horizontal
    case 'bottomUp':
      return [6, 4, 2]; // Bottom to top diagonal
    case 'topUp':
      return [0, 1, 2]; // Top row horizontal
    case 'triangle':
      return [3, 4, 5]; // Middle row with middle number higher
    default:
      return [3, 4, 5];
  }
};

// Generate video codes for a pattern
const generateVideoCode = (pattern: string, formationType: 'neutral' | 'bottomUp' | 'topUp' | 'triangle'): VideoCode[] => {
  const positions = getFormationPositions(formationType);
  const codes: VideoCode[] = [];

  // Generate 10 sets (0-9)
  for (let set = 0; set < 10; set++) {
    // For each set, generate codes for all 9 positions
    for (let pos = 0; pos < 9; pos++) {
      // Only add value if position is active for this formation
      const isActivePosition = positions.includes(pos);
      if (isActivePosition) {
        codes.push({
          value: set.toString(),
          position: pos,
          set: set
        });
      }
    }
  }

  return codes;
};

const determineFormationType = (pattern: string): 'neutral' | 'bottomUp' | 'topUp' | 'triangle' => {
  const digits = pattern.split('').map(Number);

  if (digits[1] > digits[0] && digits[1] > digits[2]) {
    return 'triangle';
  } else if (digits[2] < digits[1] && digits[1] === digits[0]) {
    return 'bottomUp';
  } else if (digits[0] > digits[1] && digits[1] === digits[2]) {
    return 'topUp';
  }
  return 'neutral';
};

export const VideoPatternAnalyzer: React.FC<VideoPatternProps> = ({
  pattern,
  onAnalysisComplete
}) => {
  const [formationType, setFormationType] = React.useState<'neutral' | 'bottomUp' | 'topUp' | 'triangle'>('neutral');
  const [videoCodes, setVideoCodes] = React.useState<VideoCode[]>([]);

  React.useEffect(() => {
    if (pattern) {
      const type = determineFormationType(pattern);
      setFormationType(type);
      const codes = generateVideoCode(pattern, type);
      setVideoCodes(codes);

      onAnalysisComplete?.({
        type,
        confidence: 0.9,
        videoCode: codes
      });
    }
  }, [pattern, onAnalysisComplete]);

  const renderGridSet = (setNumber: number) => {
    // Create empty grid
    const gridCells = Array(9).fill(null);

    // Fill grid with values from current set
    videoCodes
      .filter(code => code.set === setNumber)
      .forEach(code => {
        gridCells[code.position] = code.value;
      });

    return (
      <motion.div
        key={setNumber}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: setNumber * 0.1 }}
        className="border rounded p-4"
      >
        <div className="text-sm font-medium mb-2">Set {setNumber + 1}</div>
        <div className="grid grid-cols-3 gap-2">
          {gridCells.map((value, index) => (
            <div
              key={index}
              className={`
                w-12 h-12
                flex items-center justify-center
                rounded
                ${value !== null ? 'bg-blue-100' : 'bg-gray-50'}
                transition-colors
                duration-200
                ${getFormationPositions(formationType).includes(index) ? 'border-2 border-blue-300' : ''}
              `}
            >
              {value !== null && <span className="font-mono text-lg">{value}</span>}
            </div>
          ))}
        </div>
      </motion.div>
    );
  };

  return (
    <Card className="p-6">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="font-medium">Video Pattern Analysis</h3>
          <span className="text-sm text-gray-500">Formation: {formationType}</span>
        </div>

        <div className="space-y-4 max-h-[600px] overflow-y-auto">
          {Array.from({ length: 10 }, (_, i) => renderGridSet(i))}
        </div>
      </div>
    </Card>
  );
};