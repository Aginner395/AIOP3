import React from 'react';
import { Card } from '@/components/ui/card';
import { motion } from 'framer-motion';

interface VideoSequenceProps {
  startPattern: string;
  rows?: number;
}

export const VideoPatternSequence: React.FC<VideoSequenceProps> = ({
  startPattern,
  rows = 10
}) => {
  const generateVerticalSequence = (pattern: string): string[] => {
    const sequences: string[] = [pattern];
    let currentNum = parseInt(pattern);
    
    for (let i = 1; i < rows; i++) {
      currentNum = (currentNum + 1) % 1000;
      sequences.push(currentNum.toString().padStart(3, '0'));
    }
    
    return sequences;
  };

  const sequences = generateVerticalSequence(startPattern);

  return (
    <Card className="p-4">
      <div className="space-y-4">
        <h3 className="font-medium">Vertical Video Sequence</h3>
        <div className="grid grid-cols-1 gap-2">
          {sequences.map((seq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center space-x-4 bg-gray-50 p-2 rounded"
            >
              <span className="text-sm text-gray-500">{index + 1}</span>
              <span className="font-mono">{seq}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </Card>
  );
};