import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface VideoFormationProps {
  pattern: string;
  type: 'neutral' | 'bottomUp' | 'topUp' | 'triangle';
}

const formationDescriptions = {
  neutral: 'Sequential progression with equal intervals',
  bottomUp: 'Horizontal base with upward movement',
  topUp: 'Descending start with horizontal end',
  triangle: 'Middle digit forms center point with sides'
};

export const VideoPatternFormation: React.FC<VideoFormationProps> = ({
  pattern,
  type
}) => {
  const getFormationDisplay = () => {
    const digits = pattern.split('').map(Number);
    const gridCells = Array(9).fill(null);
    
    // Map pattern digits to grid based on formation type
    switch (type) {
      case 'neutral':
        // Horizontal line in middle row
        gridCells[3] = digits[0];
        gridCells[4] = digits[1];
        gridCells[5] = digits[2];
        break;
      case 'bottomUp':
        // Start at bottom, move up diagonally
        gridCells[6] = digits[0];
        gridCells[4] = digits[1];
        gridCells[2] = digits[2];
        break;
      case 'topUp':
        // Start at top, move horizontally
        gridCells[0] = digits[0];
        gridCells[1] = digits[1];
        gridCells[2] = digits[2];
        break;
      case 'triangle':
        // Triangle formation with middle number in center
        gridCells[3] = digits[0]; // Left
        gridCells[4] = digits[1]; // Middle
        gridCells[5] = digits[2]; // Right
        break;
    }
    
    return gridCells;
  };

  const displayCells = getFormationDisplay();

  return (
    <Card className="p-4">
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="font-medium">Formation Display</h3>
          <Badge variant="secondary">{type}</Badge>
        </div>
        
        <div className="grid grid-cols-3 gap-2">
          {displayCells.map((cell, index) => (
            <div
              key={index}
              className={`
                w-10 h-10 flex items-center justify-center rounded
                ${cell !== null ? 'bg-blue-100' : 'bg-gray-50'}
              `}
            >
              {cell !== null && <span className="font-mono">{cell}</span>}
            </div>
          ))}
        </div>
        
        <p className="text-sm text-gray-600">
          {formationDescriptions[type]}
        </p>
      </div>
    </Card>
  );
};