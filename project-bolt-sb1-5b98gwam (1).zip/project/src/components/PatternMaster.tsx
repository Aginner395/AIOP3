import { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PatternSystem } from './PatternSystem';
import { AIPatternAnalysis } from './AIPatternAnalysis';
import { NaturalSetsView } from './NaturalSetsView';
import { AutomatedPrediction } from './AutomatedPrediction';
import { PatternLearning } from './PatternLearning';
import { DimensionalAnalysis } from './DimensionalAnalysis';
import { PatternAnalyzer } from './PatternAnalyzer';
import { HistoricalData } from './HistoricalData';
import { HistoricalPatternAnalysis } from './analysis/HistoricalPatternAnalysis';
import { LLLPatternAnalysis } from './LLLPatternAnalysis';
import { LHPatternAnalysis } from './LHPatternAnalysis';
import { TopPredictions } from './TopPredictions';
import { TierAnalysis } from './tier/TierAnalysis';
import { PatternChatbot } from './chat/PatternChatbot';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import lotteryData from '@/data/lottery.json';

export const PatternMaster = () => {
  const [input, setInput] = useState('701');
  const [output, setOutput] = useState('331');
  const [activeTab, setActiveTab] = useState('origin');
  const [predictions, setPredictions] = useState<string[]>([]);
  const [patternHistory, setPatternHistory] = useState<Array<{input: string, output: string}>>([]);

  const handleInputChange = (value: string) => {
    const cleanValue = value.replace(/[^0-9]/g, '').slice(0, 3);
    setInput(cleanValue);
  };

  const handleOutputChange = (value: string) => {
    const cleanValue = value.replace(/[^0-9]/g, '').slice(0, 3);
    setOutput(cleanValue);
  };

  useEffect(() => {
    if (input.length === 3) {
      generatePredictions();
    } else {
      setPredictions([]);
    }
  }, [input]);

  useEffect(() => {
    if (input.length === 3 && output.length === 3) {
      setPatternHistory(prev => [...prev, { input, output }]);
    }
  }, [input, output]);

  const generatePredictions = () => {
    setPredictions([]);
  };

  return (
    <Card className="w-full">
      <CardContent className="p-8">
        <div className="space-y-6">
          {/* Input/Output Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-lg font-semibold">Input Pattern</Label>
              <div className="mt-2">
                <Input
                  value={input}
                  onChange={(e) => handleInputChange(e.target.value)}
                  placeholder="Enter 3 digits"
                  className="w-32 text-center text-xl font-mono"
                  maxLength={3}
                />
              </div>
            </div>
            <div>
              <Label className="text-lg font-semibold">Output Pattern</Label>
              <div className="mt-2">
                <Input
                  value={output}
                  onChange={(e) => handleOutputChange(e.target.value)}
                  placeholder="Enter 3 digits"
                  className="w-32 text-center text-xl font-mono"
                  maxLength={3}
                />
              </div>
            </div>
          </div>

          {/* Tabs Section */}
          {input.length === 3 && (
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <div className="overflow-x-auto">
                <TabsList className="inline-flex min-w-max w-full justify-start p-1 h-auto gap-1">
                  <TabsTrigger value="origin" className="px-3 py-2">Pattern Origin</TabsTrigger>
                  <TabsTrigger value="dimensions" className="px-3 py-2">10D Analysis</TabsTrigger>
                  <TabsTrigger value="shapes" className="px-3 py-2">Pattern Shapes</TabsTrigger>
                  <TabsTrigger value="ai" className="px-3 py-2">AI Analysis</TabsTrigger>
                  <TabsTrigger value="natural" className="px-3 py-2">Natural Sets</TabsTrigger>
                  <TabsTrigger value="prediction" className="px-3 py-2">Automated Prediction</TabsTrigger>
                  <TabsTrigger value="learning" className="px-3 py-2">Pattern Learning</TabsTrigger>
                  <TabsTrigger value="historical" className="px-3 py-2">Historical Data</TabsTrigger>
                  <TabsTrigger value="lll" className="px-3 py-2">LLL Patterns</TabsTrigger>
                  <TabsTrigger value="lh" className="px-3 py-2">L/H Patterns</TabsTrigger>
                  <TabsTrigger value="top" className="px-3 py-2">Top Predictions</TabsTrigger>
                  <TabsTrigger value="tier" className="px-3 py-2">Tier Analysis</TabsTrigger>
                  <TabsTrigger value="chat" className="px-3 py-2">AI Assistant</TabsTrigger>
                </TabsList>
              </div>

              <div className="mt-6">
                <TabsContent value="origin">
                  <PatternAnalyzer input={input} output={output} />
                </TabsContent>

                <TabsContent value="dimensions">
                  <DimensionalAnalysis input={input} output={output} />
                </TabsContent>

                <TabsContent value="shapes">
                  <PatternSystem 
                    input={input} 
                    output={output}
                    onPrediction={(pred) => setPredictions(prev => [...new Set([...prev, pred])])} 
                  />
                </TabsContent>

                <TabsContent value="ai">
                  <AIPatternAnalysis 
                    input={input} 
                    output={output}
                    onPrediction={(pred) => setPredictions(prev => [...new Set([...prev, pred])])} 
                  />
                </TabsContent>

                <TabsContent value="natural">
                  <NaturalSetsView input={input} />
                </TabsContent>

                <TabsContent value="prediction">
                  <AutomatedPrediction 
                    input={input} 
                    predictions={predictions}
                  />
                </TabsContent>

                <TabsContent value="learning">
                  <PatternLearning 
                    history={patternHistory}
                    currentInput={input}
                    currentOutput={output}
                  />
                </TabsContent>

                <TabsContent value="historical">
                  <div className="space-y-6">
                    <HistoricalData pattern={input} />
                    <HistoricalPatternAnalysis data={lotteryData.draws} />
                  </div>
                </TabsContent>

                <TabsContent value="lll">
                  <LLLPatternAnalysis input={input} output={output} />
                </TabsContent>

                <TabsContent value="lh">
                  <LHPatternAnalysis input={input} output={output} />
                </TabsContent>

                <TabsContent value="top">
                  <TopPredictions input={input} output={output} />
                </TabsContent>

                <TabsContent value="tier">
                  <TierAnalysis />
                </TabsContent>

                <TabsContent value="chat">
                  <PatternChatbot currentPattern={input} />
                </TabsContent>
              </div>
            </Tabs>
          )}
        </div>
      </CardContent>
    </Card>
  );
};