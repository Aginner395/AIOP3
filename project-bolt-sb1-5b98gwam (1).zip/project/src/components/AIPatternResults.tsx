import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { aiColors } from '@/lib/ai/constants';
import { processAI1, processAI4, processAI6, type PatternResult } from '@/lib/ai/processors';

interface ResultSetProps {
  items: PatternResult[];
  colors: {
    bg: string;
    border: string;
    text: string;
    title: string;
  };
  title: string;
}

const ResultSet: React.FC<ResultSetProps> = ({ items, colors, title }) => (
  <div className="space-y-3">
    <h3 className={`text-xl font-bold ${colors.title}`}>{title}</h3>
    <div className="space-y-2">
      {items.map((item, idx) => (
        <div key={idx} className={`${colors.bg} ${colors.border} border p-3 rounded-lg`}>
          <div className="flex justify-between items-center mb-1">
            <div className={`font-mono text-sm font-bold ${colors.text}`}>
              {item.aiSet}
            </div>
            {item.isKeyMatch && (
              <Badge variant="secondary" className="text-xs">Key Match</Badge>
            )}
          </div>
          <div className="grid grid-cols-2 gap-1 text-xs font-mono">
            <div className="text-gray-600">LLL: {item.patterns.lll}</div>
            <div className="text-gray-600">LLH: {item.patterns.llh}</div>
            <div className="text-gray-600">LHL: {item.patterns.lhl}</div>
            <div className="text-gray-600">LHH: {item.patterns.lhh}</div>
          </div>
        </div>
      ))}
    </div>
  </div>
);

interface AIPatternResultsProps {
  pattern: string;
}

export const AIPatternResults: React.FC<AIPatternResultsProps> = ({ pattern }) => {
  const results = React.useMemo(() => {
    if (pattern.length === 3) {
      try {
        return {
          ai1: processAI1(pattern),
          ai4: processAI4(pattern),
          ai6: processAI6(pattern)
        };
      } catch (error) {
        console.error('Processing error:', error);
      }
    }
    return null;
  }, [pattern]);

  if (!results) return null;

  return (
    <Card className="p-4">
      <CardContent>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          <ResultSet items={results.ai1} colors={aiColors.ai1} title="AI#1" />
          <ResultSet items={results.ai4} colors={aiColors.ai4} title="AI#4" />
          <ResultSet items={results.ai6} colors={aiColors.ai6} title="AI#6" />
        </div>
      </CardContent>
    </Card>
  );
};