import React, { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, ArrowDown } from "lucide-react";

const naturalToAI = {
  '0': '5', '1': '7', '2': '9', '3': '1', '4': '3',
  '5': '5', '6': '7', '7': '9', '8': '1', '9': '3'
};

// Pattern transformation rules
const patternRules = {
  'Neutral N': (input: string) => {
    const nums = input.split('').map(Number);
    return {
      natural: nums.map(n => ((n + 4) % 10).toString()).join(''),
      ai: nums.map(n => naturalToAI[((n + 4) % 10).toString()]).join('')
    };
  },
  'Bottom Up BUC': (input: string) => {
    const nums = input.split('').map(Number);
    const last = (nums[2] + 1) % 10;
    return {
      natural: [nums[0], nums[1], last].join(''),
      ai: [nums[0], nums[1], last].map(n => naturalToAI[n.toString()]).join('')
    };
  },
  'Top Up C TUC': (input: string) => {
    const nums = input.split('').map(Number);
    const first = (nums[0] - 1 + 10) % 10;
    return {
      natural: [first, nums[1], nums[2]].join(''),
      ai: [first, nums[1], nums[2]].map(n => naturalToAI[n.toString()]).join('')
    };
  },
  'Triangle Up TU': (input: string) => {
    const nums = input.split('').map(Number);
    const middle = (nums[1] + 1) % 10;
    return {
      natural: [nums[0], middle, nums[2]].join(''),
      ai: [nums[0], middle, nums[2]].map(n => naturalToAI[n.toString()]).join('')
    };
  },
  'Triangle Down TD': (input: string) => {
    const nums = input.split('').map(Number);
    const middle = (nums[1] - 1 + 10) % 10;
    return {
      natural: [nums[0], middle, nums[2]].join(''),
      ai: [nums[0], middle, nums[2]].map(n => naturalToAI[n.toString()]).join('')
    };
  },
  'Slash Up SU': (input: string) => {
    const nums = input.split('').map(Number);
    return {
      natural: [(nums[0] - 1 + 10) % 10, nums[1], (nums[2] + 1) % 10].join(''),
      ai: [(nums[0] - 1 + 10) % 10, nums[1], (nums[2] + 1) % 10].map(n => naturalToAI[n.toString()]).join('')
    };
  },
  'Slash Down SD': (input: string) => {
    const nums = input.split('').map(Number);
    return {
      natural: [(nums[0] + 1) % 10, nums[1], (nums[2] - 1 + 10) % 10].join(''),
      ai: [(nums[0] + 1) % 10, nums[1], (nums[2] - 1 + 10) % 10].map(n => naturalToAI[n.toString()]).join('')
    };
  },
  'Bottom Down BDC': (input: string) => {
    const nums = input.split('').map(Number);
    const first = (nums[0] + 1) % 10;
    return {
      natural: [first, nums[1], nums[2]].join(''),
      ai: [first, nums[1], nums[2]].map(n => naturalToAI[n.toString()]).join('')
    };
  },
  'Top Down TDC': (input: string) => {
    const nums = input.split('').map(Number);
    const last = (nums[2] - 1 + 10) % 10;
    return {
      natural: [nums[0], nums[1], last].join(''),
      ai: [nums[0], nums[1], last].map(n => naturalToAI[n.toString()]).join('')
    };
  }
};

interface PredictionRowProps {
  name: string;
  prediction: {
    natural: string;
    ai: string;
  };
  output?: string;
  description: string;
  transform: string;
}

const PredictionRow: React.FC<PredictionRowProps> = ({ 
  name, 
  prediction, 
  output,
  description,
  transform
}) => {
  const outputAI = output ? output.split('').map(d => naturalToAI[d]).join('') : undefined;
  const isMatch = output && (prediction.natural === output || prediction.ai === outputAI);
  
  return (
    <div className={`
      flex items-start gap-8 p-4 rounded-lg border-l-4 transition-all
      ${isMatch 
        ? 'bg-green-50 border-green-500' 
        : 'bg-gray-50 border-transparent hover:border-gray-200'
      }
    `}>
      <div className="w-48">
        <div className="font-medium text-gray-700 mb-2">{name}</div>
        <div className="space-y-1 text-xs text-gray-600">
          <div>{description}</div>
          <div className="font-medium text-gray-700">{transform}</div>
        </div>
      </div>
      
      <div className="flex gap-8 flex-1">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-medium text-gray-700">Natural Prediction</span>
            {output && prediction.natural === output && (
              <Badge variant="success" className="text-xs">Match!</Badge>
            )}
          </div>
          <div className="font-mono text-lg bg-white p-2 rounded border">
            {prediction.natural}
          </div>
        </div>
        
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-medium text-gray-700">AI Prediction</span>
            {output && prediction.ai === outputAI && (
              <Badge variant="success" className="text-xs">Match!</Badge>
            )}
          </div>
          <div className="font-mono text-lg bg-white p-2 rounded border">
            {prediction.ai}
          </div>
        </div>
      </div>
    </div>
  );
};

const patternDescriptions = {
  'Neutral N': {
    description: 'Horizontal line pattern with sequential progression',
    transform: 'Natural +4 / AI conversion'
  },
  'Bottom Up BUC': {
    description: 'First two digits form base, last digit higher',
    transform: 'Third position +1'
  },
  'Top Up C TUC': {
    description: 'Last two digits form top, first digit lower',
    transform: 'First position -1'
  },
  'Triangle Up TU': {
    description: 'Middle number higher than outer numbers',
    transform: 'Middle position +1'
  },
  'Triangle Down TD': {
    description: 'Middle number lower than outer numbers',
    transform: 'Middle position -1'
  },
  'Slash Up SU': {
    description: 'Ascending diagonal pattern',
    transform: 'First -1, Third +1'
  },
  'Slash Down SD': {
    description: 'Descending diagonal pattern',
    transform: 'First +1, Third -1'
  },
  'Bottom Down BDC': {
    description: 'Last two digits form bottom, first digit higher',
    transform: 'First position +1'
  },
  'Top Down TDC': {
    description: 'First two digits form top, last digit lower',
    transform: 'Third position -1'
  }
};

export default function PatternDisplay() {
  const [input, setInput] = useState('567');
  const [output, setOutput] = useState('983');
  const [predictions, setPredictions] = useState<Record<string, { natural: string; ai: string }>>({});
  
  useEffect(() => {
    if (input.length === 3) {
      const newPredictions = Object.entries(patternRules).reduce((acc, [name, rule]) => {
        acc[name] = rule(input);
        return acc;
      }, {} as Record<string, { natural: string; ai: string }>);
      
      setPredictions(newPredictions);
    }
  }, [input]);

  const matchCount = Object.values(predictions).reduce((count, pred) => {
    const outputAI = output.split('').map(d => naturalToAI[d]).join('');
    if (pred.natural === output || pred.ai === outputAI) {
      return count + 1;
    }
    return count;
  }, 0);

  return (
    <Card className="w-full max-w-6xl mx-auto">
      <CardContent className="p-6">
        <h1 className="text-2xl font-bold mb-6">Pattern Prediction System</h1>

        <div className="mb-6">
          <div className="flex gap-8 items-end">
            <div>
              <Label htmlFor="input">Input Pattern</Label>
              <Input
                id="input"
                value={input}
                onChange={(e) => setInput(e.target.value.replace(/[^0-9]/g, '').slice(0, 3))}
                className="w-32 text-center text-xl font-mono"
                maxLength={3}
              />
            </div>
            <div>
              <Label htmlFor="output">Actual Output (Optional)</Label>
              <Input
                id="output"
                value={output}
                onChange={(e) => setOutput(e.target.value.replace(/[^0-9]/g, '').slice(0, 3))}
                className="w-32 text-center text-xl font-mono"
                maxLength={3}
              />
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <ArrowRight className="w-4 h-4" />
              AI: {input.split('').map(d => naturalToAI[d]).join('')}
            </div>
            {output && matchCount > 0 && (
              <Badge variant="success" className="ml-auto">
                {matchCount} {matchCount === 1 ? 'Match' : 'Matches'} Found
              </Badge>
            )}
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-semibold">Pattern Predictions</h2>
            {output && (
              <Badge variant="secondary">
                Actual: {output} (AI: {output.split('').map(d => naturalToAI[d]).join('')})
              </Badge>
            )}
          </div>

          <div className="space-y-4">
            {Object.entries(predictions).map(([name, prediction]) => (
              <PredictionRow 
                key={name}
                name={name}
                prediction={prediction}
                output={output}
                description={patternDescriptions[name as keyof typeof patternDescriptions].description}
                transform={patternDescriptions[name as keyof typeof patternDescriptions].transform}
              />
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export { PatternDisplay }