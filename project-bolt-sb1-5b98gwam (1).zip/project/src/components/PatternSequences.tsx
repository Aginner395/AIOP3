import React from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';

interface PatternSequencesProps {
  pattern: string;
  rows?: number;
}

export const PatternSequences: React.FC<PatternSequencesProps> = ({
  pattern,
  rows = 10
}) => {
  const generateSequence = (startPattern: string): string[] => {
    const sequences: string[] = [startPattern];
    let currentNum = parseInt(startPattern);
    
    for (let i = 1; i < rows; i++) {
      currentNum = (currentNum + 1) % 1000;
      sequences.push(currentNum.toString().padStart(3, '0'));
    }
    return sequences;
  };

  const sequences = generateSequence(pattern);

  return (
    <Card className="p-4">
      <div className="space-y-4">
        <h3 className="font-medium">Pattern Sequence</h3>
        <div className="grid gap-2">
          {sequences.map((seq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center space-x-4 bg-gray-50 p-2 rounded hover:bg-gray-100 transition-colors"
            >
              <span className="text-sm text-gray-500 w-8">#{index + 1}</span>
              <span className="font-mono">{seq}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </Card>
  );
};