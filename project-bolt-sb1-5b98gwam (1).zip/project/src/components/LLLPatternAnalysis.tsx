import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { naturalToAi, lArray, hArray } from '@/lib/ai/constants';
import { processAI1, processAI4, processAI6 } from '@/lib/ai/processors';
import { PatternGrid } from './PatternGrid';

interface LLLPatternAnalysisProps {
  input: string;
  output?: string;
}

interface PatternSet {
  original: string;
  variations: {
    lll: string;
    llh: string;
    lhl: string;
    lhh: string;
  };
  confidence: number;
  matchesOutput?: boolean;
}

export const LLLPatternAnalysis: React.FC<LLLPatternAnalysisProps> = ({
  input,
  output
}) => {
  const [copiedLeft, setCopiedLeft] = React.useState(false);
  const [copiedRight, setCopiedRight] = React.useState(false);
  const { toast } = useToast();

  const getHighConfidencePrediction = (input: string): string | null => {
    if (input.length !== 3) return null;

    const aiInput = input.split('').map(d => naturalToAi[d]).join('');
    const allResults = [
      ...processAI1(input),
      ...processAI4(input),
      ...processAI6(input)
    ];

    const bestMatch = allResults.reduce((best, current) => {
      const currentConfidence = current.isKeyMatch ? 0.9 : 0.7;
      return best.confidence > currentConfidence ? best : {
        pattern: current.patterns.lll,
        confidence: currentConfidence
      };
    }, { pattern: '', confidence: 0 });

    return bestMatch.pattern || aiInput;
  };

  const generateVariations = (set: string) => {
    const aiNumbers = set.split('').map(d => {
      return Object.values(naturalToAi).includes(d) ? d : naturalToAi[d];
    }).join('');

    return {
      lll: aiNumbers.split('').map(d => lArray[d]).join(''),
      llh: lArray[aiNumbers[0]] + lArray[aiNumbers[1]] + hArray[aiNumbers[2]],
      lhl: lArray[aiNumbers[0]] + hArray[aiNumbers[1]] + lArray[aiNumbers[2]],
      lhh: lArray[aiNumbers[0]] + hArray[aiNumbers[1]] + hArray[aiNumbers[2]]
    };
  };

  const generatePatternSets = (pattern: string): PatternSet[] => {
    if (pattern.length !== 3) return [];

    const prediction = getHighConfidencePrediction(pattern);
    if (!prediction) return [];

    const [a, b, c] = prediction.split('');
    const sets: string[] = [];

    sets.push(
      prediction,              // Original prediction
      [a, c, b].join(''),     // Back pair inverted
      [a, b, b].join(''),     // Duplicate middle
      [a, c, c].join(''),     // Duplicate last
      [a, b, a].join(''),     // Mirror with first
      [a, c, a].join(''),     // Mirror with first using last
      [a, a, b].join(''),     // Mirror first to middle
      [a, a, c].join('')      // Mirror first to middle with last
    );

    return sets.map((set, index) => {
      const variations = generateVariations(set);
      const matchesOutput = output ? 
        variations.lll === output || variations.llh === output : false;
      
      return {
        original: set,
        variations,
        confidence: index === 0 ? 0.95 : Math.max(0.5, 0.9 - (index * 0.1)),
        matchesOutput
      };
    });
  };

  const patternSets = React.useMemo(() => {
    return generatePatternSets(input);
  }, [input, output]);

  const matchingPatterns = patternSets.filter(set => set.matchesOutput);

  const copyPatternSide = async (side: 'left' | 'right') => {
    try {
      const firstFourSets = patternSets.slice(0, 4);
      const allSequences = firstFourSets.map(set => {
        const pattern = side === 'left' ? set.variations.lll : set.variations.llh;
        const baseRow = 1;
        const result = [];
        
        for (let row = 0; row < 10; row++) {
          const rowNumbers = pattern.split('').map(num => {
            const offset = row - baseRow;
            return ((parseInt(num) + offset + 10) % 10).toString();
          });
          result.push(rowNumbers.join(''));
        }
        
        return result;
      });

      const allNumbers = allSequences.flat().join(' ');

      await navigator.clipboard.writeText(allNumbers);
      if (side === 'left') {
        setCopiedLeft(true);
        setTimeout(() => setCopiedLeft(false), 2000);
      } else {
        setCopiedRight(true);
        setTimeout(() => setCopiedRight(false), 2000);
      }

      toast({
        title: "Copied!",
        description: `All ${side === 'left' ? 'LLL' : 'LLH'} sequences copied to clipboard`,
      });
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  const getVariationColor = (type: string) => {
    switch (type) {
      case 'lll': return 'bg-blue-50 border-blue-200';
      case 'llh': return 'bg-green-50 border-green-200';
      case 'lhl': return 'bg-amber-50 border-amber-200';
      case 'lhh': return 'bg-purple-50 border-purple-200';
      default: return 'bg-gray-50 border-gray-200';
    }
  };

  if (patternSets.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-gray-500">
            Enter a valid 3-digit pattern to generate LLL variations
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div className="space-y-1">
              <h3 className="text-lg font-semibold">LLL Pattern Analysis</h3>
              <p className="text-sm text-gray-500">
                Based on highest confidence prediction
              </p>
            </div>
            <div className="flex items-center gap-4">
              {output && (
                <Badge variant="secondary">
                  {matchingPatterns.length} matches found
                </Badge>
              )}
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyPatternSide('left')}
                  className="transition-all duration-200 bg-blue-50 hover:bg-blue-100"
                >
                  {copiedLeft ? (
                    <Check className="h-4 w-4 text-green-500" />
                  ) : (
                    <Copy className="h-4 w-4 text-blue-600" />
                  )}
                  <span className="ml-2">{copiedLeft ? 'Copied!' : 'Copy LLL (Left)'}</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyPatternSide('right')}
                  className="transition-all duration-200 bg-green-50 hover:bg-green-100"
                >
                  {copiedRight ? (
                    <Check className="h-4 w-4 text-green-500" />
                  ) : (
                    <Copy className="h-4 w-4 text-green-600" />
                  )}
                  <span className="ml-2">{copiedRight ? 'Copied!' : 'Copy LLH (Right)'}</span>
                </Button>
              </div>
            </div>
          </div>

          <div className="grid gap-4">
            {patternSets.slice(0, 4).map((set, idx) => (
              <div 
                key={idx} 
                className={`bg-white p-4 rounded-lg border border-gray-200 shadow-sm ${
                  set.matchesOutput ? 'ring-2 ring-green-500' : ''
                }`}
              >
                <div className="flex justify-between items-center mb-3">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Set {idx + 1}</Badge>
                    <span className="font-mono text-sm">
                      {input} → {set.original}
                    </span>
                    {set.matchesOutput && (
                      <Badge variant="success">Match</Badge>
                    )}
                  </div>
                  <Badge variant="secondary">
                    {(set.confidence * 100).toFixed(0)}% confidence
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div 
                      className={`
                        flex justify-between items-center p-3 rounded-lg border mb-2
                        ${getVariationColor('lll')}
                      `}
                    >
                      <div className="space-y-1">
                        <span className="text-xs font-medium uppercase">
                          LLL
                        </span>
                        <div className="font-mono text-lg">{set.variations.lll}</div>
                      </div>
                      <Badge variant="outline" className="ml-2">Base</Badge>
                    </div>
                    
                    <div className="mt-2 scale-75 origin-top-left">
                      <PatternGrid
                        pattern={{
                          cells: set.variations.lll.split('').map((num, idx) => ({
                            row: 1,
                            col: idx,
                            num
                          })),
                          color: 'bg-blue-100'
                        }}
                        shapeName="LLL"
                      />
                    </div>
                  </div>

                  <div>
                    <div 
                      className={`
                        flex justify-between items-center p-3 rounded-lg border mb-2
                        ${getVariationColor('llh')}
                      `}
                    >
                      <div className="space-y-1">
                        <span className="text-xs font-medium uppercase">
                          LLH
                        </span>
                        <div className="font-mono text-lg">{set.variations.llh}</div>
                      </div>
                      <Badge variant="outline" className="ml-2">LLH</Badge>
                    </div>
                    
                    <div className="mt-2 scale-75 origin-top-left">
                      <PatternGrid
                        pattern={{
                          cells: set.variations.llh.split('').map((num, idx) => ({
                            row: 1,
                            col: idx,
                            num
                          })),
                          color: 'bg-green-100'
                        }}
                        shapeName="LLH"
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <h4 className="font-medium mb-2">Pattern Information</h4>
            <div className="grid grid-cols-3 gap-4">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-blue-100 border border-blue-200"></div>
                <span className="text-sm">LLL - All Low Numbers</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-green-100 border border-green-200"></div>
                <span className="text-sm">LLH - Low-Low-High</span>
              </div>
              {output && (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded border-2 border-green-500"></div>
                  <span className="text-sm">Output Match</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};