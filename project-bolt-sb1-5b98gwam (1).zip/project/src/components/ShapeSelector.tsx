import { Button } from "@/components/ui/button";
import { PatternGrid } from './PatternGrid';
import { ShapeSelectorProps } from '@/types/shapes';
import { Copy, Check } from 'lucide-react';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';

export const ShapeSelector = ({ shapes, selectedShape, onSelectShape }: ShapeSelectorProps) => {
  const [copiedAll, setCopiedAll] = useState(false);
  const { toast } = useToast();

  const copyAllShapesNumbers = async () => {
    try {
      // Generate numbers for all shapes
      const allNumbers = Object.values(shapes).map(pattern => {
        const sequences = Array(10).fill(null).map(() => Array(3).fill(''));
        
        // Generate sequences for each shape
        pattern.cells.forEach(cell => {
          const baseRow = cell.row;
          const baseNum = parseInt(cell.num);
          
          for (let row = 0; row < 10; row++) {
            let num;
            if (row < baseRow) {
              num = (baseNum - (baseRow - row) + 10) % 10;
            } else if (row > baseRow) {
              num = (baseNum + (row - baseRow)) % 10;
            } else {
              num = baseNum;
            }
            sequences[row][cell.col] = num.toString();
          }
        });

        // Convert sequences to horizontal sets
        return sequences.map(row => row.join('')).join(' ');
      }).join(' ');

      await navigator.clipboard.writeText(allNumbers);
      setCopiedAll(true);
      toast({
        title: "Copied!",
        description: "All numbers copied to clipboard",
      });
      setTimeout(() => setCopiedAll(false), 2000);
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button
          variant="outline"
          size="sm"
          onClick={copyAllShapesNumbers}
          className="transition-all duration-200"
        >
          {copiedAll ? (
            <Check className="h-4 w-4 text-green-500" />
          ) : (
            <Copy className="h-4 w-4" />
          )}
          <span className="ml-2">{copiedAll ? 'Copied!' : 'Copy All Numbers'}</span>
        </Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {Object.entries(shapes).map(([name, pattern]) => (
          <div
            key={name}
            className={`
              p-4 rounded-lg border transition-colors
              ${selectedShape === name ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:bg-accent'}
            `}
            onClick={() => onSelectShape(name)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                onSelectShape(name);
              }
            }}
          >
            <div className="flex flex-col items-center gap-2">
              <div className="text-sm font-medium">{name}</div>
              <div className="scale-75">
                <PatternGrid pattern={pattern} shapeName={name} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};