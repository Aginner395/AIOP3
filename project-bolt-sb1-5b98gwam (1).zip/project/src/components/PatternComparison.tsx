import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { naturalToAi } from '@/lib/ai/constants';

interface PatternComparisonProps {
  input: string;
  output: string;
}

interface ComparisonResult {
  type: string;
  confidence: number;
  relationship: string;
  prediction: string;
}

export const PatternComparison: React.FC<PatternComparisonProps> = ({ input, output }) => {
  const analyzePatterns = (): ComparisonResult | null => {
    if (input.length !== 3 || output.length !== 3) return null;

    // Convert to numbers for analysis
    const inputNums = input.split('').map(Number);
    const outputNums = output.split('').map(Number);

    // Check for direct relationships
    const differences = inputNums.map((num, idx) => outputNums[idx] - num);
    const aiInput = input.split('').map(d => naturalToAi[d]).join('');
    const aiOutput = output.split('').map(d => naturalToAi[d]).join('');

    // Analyze pattern relationship
    if (differences.every(d => d === differences[0])) {
      return {
        type: 'Linear',
        confidence: 0.9,
        relationship: `Constant difference of ${differences[0]}`,
        prediction: inputNums.map(n => (n + differences[0]) % 10).join('')
      };
    }

    if (aiInput === output) {
      return {
        type: 'AI Conversion',
        confidence: 1.0,
        relationship: 'Direct AI conversion pattern',
        prediction: aiOutput
      };
    }

    // Check for reverse pattern
    if (input === output.split('').reverse().join('')) {
      return {
        type: 'Reverse',
        confidence: 0.95,
        relationship: 'Pattern reversal',
        prediction: input.split('').reverse().join('')
      };
    }

    // Default to complex relationship
    return {
      type: 'Complex',
      confidence: 0.7,
      relationship: 'Multiple pattern transformations',
      prediction: calculateComplexPrediction(input, output)
    };
  };

  const calculateComplexPrediction = (input: string, output: string): string => {
    // Implement complex pattern prediction logic
    const inputNums = input.split('').map(Number);
    const outputNums = output.split('').map(Number);
    
    return inputNums.map((num, idx) => {
      const diff = (outputNums[idx] - num + 10) % 10;
      return ((num + diff) % 10).toString();
    }).join('');
  };

  const result = analyzePatterns();

  if (!result) {
    return (
      <Card className="mt-6">
        <CardContent className="p-4">
          <p className="text-gray-500 text-center">
            Enter both input and output patterns (3 digits each) to see analysis
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mt-6">
      <CardContent className="p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Pattern Relationship Analysis</h3>
            <Badge variant="secondary" className="text-sm">
              {result.type}
            </Badge>
          </div>

          <div className="grid gap-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium">Relationship Type</span>
                <span className="text-sm text-gray-500">
                  {(result.confidence * 100).toFixed(0)}% confidence
                </span>
              </div>
              <p className="text-sm text-gray-600">{result.relationship}</p>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="font-medium mb-2">Pattern Transformation</div>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-sm text-gray-500">Input</div>
                  <div className="font-mono text-lg">{input}</div>
                </div>
                <div className="flex items-center justify-center">
                  <span className="text-gray-400">→</span>
                </div>
                <div>
                  <div className="text-sm text-gray-500">Output</div>
                  <div className="font-mono text-lg">{output}</div>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="font-medium mb-2">Next Pattern Prediction</div>
              <div className="font-mono text-xl text-center">{result.prediction}</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};