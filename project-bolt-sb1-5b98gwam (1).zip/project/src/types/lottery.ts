export interface LotteryDraw {
  date: string;
  numbers: {
    midday: {
      pick3: string;
      pick4: string;
    };
    evening: {
      pick3: string;
      pick4: string;
    };
  };
}

export interface LotteryData {
  draws: LotteryDraw[];
  metadata: {
    lastUpdated: string;
    totalDraws: number;
    format: {
      pick3: string;
      pick4: string;
    };
  };
}