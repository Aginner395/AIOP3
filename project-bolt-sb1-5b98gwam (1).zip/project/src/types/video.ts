export interface VideoAnalysisResult {
  type: 'neutral' | 'bottomUp' | 'topUp' | 'triangle';
  confidence: number;
  videoCode: VideoCode[];
}

export interface VideoCode {
  value: string;
  position: number;
  set: number;
}

export interface VideoFormationProps {
  pattern: string;
  type: 'neutral' | 'bottomUp' | 'topUp' | 'triangle';
}

export interface VideoSequenceProps {
  startPattern: string;
  rows?: number;
}

export interface CombinedVideoProps {
  pattern: string;
}