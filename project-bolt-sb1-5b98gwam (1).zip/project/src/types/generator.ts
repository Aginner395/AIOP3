export interface PatternResult {
  aiSet: string;
  patterns: {
    lll: string;
    llh: string;
    lhl: string;
    lhh: string;
  };
  isKeyMatch?: boolean;
}

export interface AIPattern {
  type: string;
  value: string;
  probability: number;
}

export interface AISet {
  type: string;
  aiSet: string;
  patterns: {
    lll: string;
    llh: string;
    lhl: string;
    lhh: string;
  };
}

export interface Distribution {
  type: string;
  percentage: number;
}

export interface Analysis {
  distribution: Distribution[];
  insights: string[];
}

export interface PatternSet {
  basePattern: string;
  patterns: AIPattern[];
  analysis: Analysis;
}