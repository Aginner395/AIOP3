export interface Pattern {
  name: string;
  color: string;
  example: string;
  aiConverted: string;
  rules: string[];
}

export interface PatternDisplayProps {
  pattern: Pattern;
}

export interface PatternCell {
  row: number;
  col: number;
  num: string;
}

export interface CoreShape {
  color: string;
  cells: PatternCell[];
}