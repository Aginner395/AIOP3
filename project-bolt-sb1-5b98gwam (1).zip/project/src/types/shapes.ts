export interface PatternCell {
  row: number;
  col: number;
  num: string;
}

export interface CoreShape {
  color: string;
  cells: PatternCell[];
}

export interface CoreShapes {
  [key: string]: CoreShape;
}

export interface PatternGridProps {
  pattern: CoreShape;
  showConversion?: boolean;
  showInput?: boolean;
}

export interface ShapeSelectorProps {
  shapes: CoreShapes;
  selectedShape: string | null;
  onSelectShape: (name: string) => void;
}