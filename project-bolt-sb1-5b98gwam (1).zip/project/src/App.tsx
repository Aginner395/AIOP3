import { PatternMaster } from './components/PatternMaster';
import { PatternControl } from './components/PatternControl';
import './App.css';

function App() {
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-[90rem] mx-auto space-y-8">
        <h1 className="text-3xl font-bold text-center mb-8">Pattern Analysis System</h1>
        <PatternControl 
          onInputChange={(input) => console.log('Input changed:', input)}
          onOutputChange={(output) => console.log('Output changed:', output)}
          onPatternMatch={(matched) => console.log('Pattern matched:', matched)}
        />
        <PatternMaster />
      </div>
    </div>
  );
}

export default App;