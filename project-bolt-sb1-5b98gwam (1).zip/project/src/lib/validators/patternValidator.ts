export const validatePattern = (pattern: string): string | null => {
  if (!pattern) {
    return 'Pattern is required';
  }

  if (pattern.length !== 3) {
    return 'Pattern must be exactly 3 digits';
  }
  
  if (!/^\d{3}$/.test(pattern)) {
    return 'Pattern must contain only numbers';
  }
  
  return null;
};