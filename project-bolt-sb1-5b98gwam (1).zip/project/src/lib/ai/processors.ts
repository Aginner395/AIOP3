import { naturalToAi, aiBasePairs } from './constants';

interface PatternResult {
  aiSet: string;
  patterns: {
    lll: string;
    llh: string;
    lhl: string;
    lhh: string;
  };
  isKeyMatch?: boolean;
  shape?: {
    type: string;
    confidence: number;
    reasons: string[];
  };
}

function generatePatterns(set: string) {
  const lArray = { '5': '0', '7': '1', '9': '2', '1': '3', '3': '4' };
  const hArray = { '5': '5', '7': '6', '9': '7', '1': '8', '3': '9' };
  
  return {
    lll: set.split('').map(d => lArray[d]).join(''),
    llh: lArray[set[0]] + lArray[set[1]] + hArray[set[2]],
    lhl: lArray[set[0]] + hArray[set[1]] + lArray[set[2]],
    lhh: lArray[set[0]] + hArray[set[1]] + hArray[set[2]]
  };
}

function createPatternResult(set: string, isKeyMatch = false): PatternResult {
  return {
    aiSet: set,
    patterns: generatePatterns(set),
    isKeyMatch
  };
}

// AI Processor #1
export function processAI1(number: string): PatternResult[] {
  if (typeof number !== 'string') return [];

  const converted = number.split('').map(d => naturalToAi[d]);
  const [a, b, c] = converted;
  const basePairs = aiBasePairs[a]?.split(',') || [];
  const sets = new Set<string>();

  basePairs.forEach(pair => {
    [a, b, c].forEach(digit => sets.add(pair + digit));
  });

  [[a, b, c], [b, c, a], [c, a, b]].forEach(([x, y, z]) => {
    sets.add(x + y + z);
    sets.add(z + y + x);
  });

  return Array.from(sets).map(set => createPatternResult(set, set.includes(b)));
}

// AI Processor #4
export function processAI4(number: string): PatternResult[] {
  if (typeof number !== 'string') return [];

  const sets = new Set<string>();
  const isTriple = number[0] === number[1] && number[1] === number[2];
  const [a, b, c] = number.split('').map(d => naturalToAi[d]);

  if (isTriple) {
    const digit = naturalToAi[number[0]];
    const step = '7';
    [
      digit + digit + digit,
      step + digit + digit,
      digit + step + digit,
      digit + digit + step,
      step + step + digit,
      digit + step + step
    ].forEach(set => sets.add(set));
  } else {
    [
      a + b + b,
      b + b + c,
      a + a + b,
      b + c + c
    ].forEach(set => sets.add(set));
  }

  return Array.from(sets).map(set => createPatternResult(set));
}

// AI Processor #6
export function processAI6(number: string): PatternResult[] {
  if (typeof number !== 'string') return [];

  const sets = new Set<string>();
  const [a, b, c] = number.split('').map(d => naturalToAi[d]);
  const middleKey = b; // The middle digit is our key

  // Special case for triplets (000 or 555)
  if (number === "000" || number === "555") {
    const baseDigit = number === "000" ? naturalToAi['0'] : '5';
    const tripletSets = [
      baseDigit + baseDigit + baseDigit,
      '7' + baseDigit + '7',
      '9' + baseDigit + '9',
      '3' + baseDigit + '3'
    ];
    
    return tripletSets.map(set => createPatternResult(set, true));
  }

  // Add original pattern
  sets.add(a + b + c);

  // Generate rotations and variations
  [
    [a, b, c],   // Original
    [c, b, a],   // Reverse
    [b, a, c],   // Middle to front
    [b, c, a]    // Middle to front, last two swapped
  ].forEach(([x, y, z]) => {
    sets.add(x + y + z);
  });

  // Generate key-based variations
  if (middleKey) {
    // Add variations where middleKey appears in different positions
    [
      middleKey + a + c,
      a + middleKey + c,
      a + c + middleKey
    ].forEach(pattern => sets.add(pattern));

    // Add special key-based patterns
    [
      middleKey + middleKey + c,
      a + middleKey + middleKey,
      middleKey + a + middleKey
    ].forEach(pattern => sets.add(pattern));
  }

  // Process sequence progression
  let current = a + b + c;
  for (let i = 0; i < 3; i++) {
    const [x, y, z] = current.split('');
    current = naturalToAi[x] + b + naturalToAi[z];
    sets.add(current);
  }

  // Create results with proper key matching
  return Array.from(sets).map(pattern => {
    // A pattern is a key match if:
    // 1. It contains the middle key digit in any position
    // 2. The middle key appears at least twice
    // 3. The pattern maintains the key digit's position
    const isKeyMatch = pattern.split('').some((digit, idx) => {
      const keyCount = pattern.split(middleKey).length - 1;
      return (digit === middleKey && (idx === 1 || keyCount >= 2));
    });

    return createPatternResult(pattern, isKeyMatch);
  });
}