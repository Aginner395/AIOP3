export const aiColors = {
  ai1: {
    bg: 'bg-indigo-50',
    border: 'border-indigo-100',  
    text: 'text-indigo-700',
    title: 'text-indigo-600'
  },
  ai4: {
    bg: 'bg-emerald-50',
    border: 'border-emerald-100',
    text: 'text-emerald-700',
    title: 'text-emerald-600' 
  },
  ai6: {
    bg: 'bg-blue-50',
    border: 'border-blue-100',
    text: 'text-blue-700',
    title: 'text-blue-600'
  }
};

export const naturalToAi: Record<string, string> = {
  '0': '5', '5': '5', '1': '7', '6': '7', '2': '9',
  '7': '9', '3': '1', '8': '1', '4': '3', '9': '3'
};

export const lArray: Record<string, string> = {
  '5': '0', '7': '1', '9': '2', '1': '3', '3': '4'
};

export const hArray: Record<string, string> = {
  '5': '5', '7': '6', '9': '7', '1': '8', '3': '9'
};

export const aiBasePairs: Record<string, string> = {
  '1': '11,13,15',
  '3': '33,35,37',
  '5': '55,57,59',
  '7': '77,79,71',
  '9': '99,91,93'
};

export const stepSequence: Record<string, string[]> = {
  '99': ['99', '11', '33'], '91': ['91', '13', '35'], 
  '93': ['93', '15', '37'], '77': ['77', '99', '11'],
  '79': ['79', '91', '13'], '71': ['71', '93', '15'], 
  '55': ['55', '77', '99'], '57': ['57', '79', '91'],
  '59': ['59', '71', '93'], '33': ['33', '55', '77'], 
  '35': ['35', '57', '79'], '37': ['37', '59', '71'],
  '11': ['11', '33', '55'], '13': ['13', '35', '57'],
  '15': ['15', '37', '59']  
};