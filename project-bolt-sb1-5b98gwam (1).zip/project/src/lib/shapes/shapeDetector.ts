import { CoreShape } from '@/types/shapes';

interface ShapeMatch {
  name: string;
  confidence: number;
  reasons: string[];
  positions: [number, number][];
  transformation?: {
    type: string;
    increment: number;
    direction: 'up' | 'down' | 'neutral';
    basePattern?: string;
  };
}

export function detectShapes(pattern: string | number | null | undefined): ShapeMatch[] {
  // Handle invalid inputs
  if (pattern === null || pattern === undefined) {
    return [];
  }

  // Convert to string and clean
  const cleanPattern = String(pattern).trim();

  // Validate pattern length and format
  if (!cleanPattern || cleanPattern.length !== 3 || !/^\d{3}$/.test(cleanPattern)) {
    return [];
  }

  const matches: ShapeMatch[] = [];
  const digits = cleanPattern.split('').map(Number);

  // Validate digits
  if (digits.some(d => isNaN(d) || d < 0 || d > 9)) {
    return [];
  }

  // Calculate differences between adjacent digits
  const diffs = [digits[1] - digits[0], digits[2] - digits[1]];
  const absDiffs = diffs.map(Math.abs);
  const maxDiff = Math.max(...absDiffs);
  const minDiff = Math.min(...absDiffs);

  // 1. Neutral N Pattern
  if (Math.abs(digits[1] - digits[0]) <= 1 && Math.abs(digits[2] - digits[1]) <= 1) {
    matches.push({
      name: 'Neutral N',
      confidence: 0.95,
      reasons: [
        'Numbers in sequential order',
        'Small differences between adjacent digits',
        'Horizontal line formation'
      ],
      positions: [[4, 0], [4, 1], [4, 2]],
      transformation: {
        type: 'sequential',
        increment: 111,
        direction: 'neutral'
      }
    });
  }

  // 2. Bottom Up (BUC)
  if (digits[0] <= digits[1] && digits[2] > digits[1]) {
    matches.push({
      name: 'Bottom Up',
      confidence: 0.95,
      reasons: [
        'First two digits form base',
        'Last digit higher than base',
        'Forms upward progression'
      ],
      positions: [[6, 0], [6, 1], [4, 2]],
      transformation: {
        type: 'paired',
        increment: 222,
        direction: 'up'
      }
    });
  }

  // 3. Top Up (TUC)
  if (digits[1] >= digits[0] && digits[1] === digits[2]) {
    matches.push({
      name: 'Top Up',
      confidence: 0.95,
      reasons: [
        'Last two digits form top',
        'First digit lower than top',
        'Forms ascending pattern'
      ],
      positions: [[4, 0], [2, 1], [2, 2]],
      transformation: {
        type: 'paired',
        increment: 222,
        direction: 'up'
      }
    });
  }

  // 4. Triangle Down (TD)
  if (digits[1] < digits[0] && digits[1] < digits[2]) {
    matches.push({
      name: 'Triangle↓',
      confidence: 0.95,
      reasons: [
        'Middle number lower than outer numbers',
        'Forms V-shaped pattern',
        'Downward triangle formation'
      ],
      positions: [[4, 0], [6, 1], [4, 2]],
      transformation: {
        type: 'pivot',
        increment: 222,
        direction: 'down'
      }
    });
  }

  // 5. Triangle Up (TU)
  if (digits[1] > digits[0] && digits[1] > digits[2]) {
    matches.push({
      name: 'Triangle↑',
      confidence: 0.95,
      reasons: [
        'Middle number higher than outer numbers',
        'Forms inverted V-shape',
        'Upward triangle formation'
      ],
      positions: [[4, 0], [2, 1], [4, 2]],
      transformation: {
        type: 'pivot',
        increment: 222,
        direction: 'up'
      }
    });
  }

  // 6. Slash Up (SU)
  if (digits[0] < digits[1] && digits[1] < digits[2] && maxDiff >= 2) {
    matches.push({
      name: 'Slash Up',
      confidence: 0.95,
      reasons: [
        'Consistent ascending pattern',
        'Large gaps between numbers',
        'Steep diagonal formation'
      ],
      positions: [[6, 0], [4, 1], [2, 2]],
      transformation: {
        type: 'progressive',
        increment: 222,
        direction: 'up'
      }
    });
  }

  // 7. Slash Down (SD)
  if (digits[0] > digits[1] && digits[1] > digits[2] && maxDiff >= 2) {
    matches.push({
      name: 'Slash Down',
      confidence: 0.95,
      reasons: [
        'Consistent descending pattern',
        'Large gaps between numbers',
        'Steep diagonal formation'
      ],
      positions: [[2, 0], [4, 1], [6, 2]],
      transformation: {
        type: 'progressive',
        increment: 111,
        direction: 'down'
      }
    });
  }

  // 8. Top Down (TDC)
  if (digits[0] >= digits[1] && digits[2] < digits[1]) {
    matches.push({
      name: 'Top Down',
      confidence: 0.95,
      reasons: [
        'First two digits form top',
        'Last digit drops down',
        'Downward progression'
      ],
      positions: [[2, 0], [2, 1], [4, 2]],
      transformation: {
        type: 'paired',
        increment: 111,
        direction: 'down'
      }
    });
  }

  // 9. Bottom Down (BDC)
  if (digits[0] > digits[1] && digits[1] === digits[2]) {
    matches.push({
      name: 'Bottom Down',
      confidence: 0.95,
      reasons: [
        'Last two digits form bottom',
        'First digit higher than bottom',
        'Descending pattern'
      ],
      positions: [[4, 0], [6, 1], [6, 2]],
      transformation: {
        type: 'paired',
        increment: 111,
        direction: 'down'
      }
    });
  }

  // Sort by confidence and filter duplicates
  return matches
    .sort((a, b) => b.confidence - a.confidence)
    .filter((match, index, self) => 
      index === self.findIndex(m => m.name === match.name)
    );
}