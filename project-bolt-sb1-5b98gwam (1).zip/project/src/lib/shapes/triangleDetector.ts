import { CoreShape } from '@/types/shapes';

interface TriangleMatch {
  type: 'up' | 'down';
  confidence: number;
  reasons: string[];
}

export function detectTrianglePattern(pattern: string): TriangleMatch | null {
  const digits = pattern.split('').map(Number);
  const [first, middle, last] = digits;

  // Check for Triangle↓ pattern
  if (middle < first && middle < last && Math.abs(first - last) <= 2) {
    return {
      type: 'down',
      confidence: calculateConfidence(digits, 'down'),
      reasons: [
        'Middle number lower than outer numbers',
        'First and last numbers at similar level',
        'Forms downward triangle shape'
      ]
    };
  }

  // Check for Triangle↑ pattern
  if (middle > first && middle > last && Math.abs(first - last) <= 2) {
    return {
      type: 'up',
      confidence: calculateConfidence(digits, 'up'),
      reasons: [
        'Middle number higher than outer numbers',
        'First and last numbers at similar level',
        'Forms upward triangle shape'
      ]
    };
  }

  return null;
}

function calculateConfidence(digits: number[], type: 'up' | 'down'): number {
  let confidence = 0;
  const [first, middle, last] = digits;

  // Base confidence for triangle shape
  confidence += 0.4;

  // Check level difference between outer numbers
  const outerDiff = Math.abs(first - last);
  if (outerDiff === 0) confidence += 0.2;
  else if (outerDiff <= 1) confidence += 0.15;
  else if (outerDiff <= 2) confidence += 0.1;

  // Check middle number difference
  const middleDiff = type === 'down' 
    ? Math.min(first - middle, last - middle)
    : Math.min(middle - first, middle - last);
  
  if (middleDiff >= 3) confidence += 0.2;
  else if (middleDiff >= 2) confidence += 0.15;
  else confidence += 0.1;

  // Check for sequential progression
  const isSequential = Math.abs(last - first) === 2 * Math.abs(middle - first);
  if (isSequential) confidence += 0.2;

  return Math.min(confidence, 1);
}