interface PatternTransition {
  from: string;
  to: string;
  type: 'horizontal' | 'ascending' | 'descending';
  confidence: number;
  reasons: string[];
}

export function detectPatternTransition(fromPattern: string, toPattern: string): PatternTransition {
  const fromDigits = fromPattern.split('').map(Number);
  const toDigits = toPattern.split('').map(Number);

  // Determine transition type
  const isHorizontal = toDigits.every((d, i) => i === 0 || Math.abs(d - toDigits[i-1]) <= 1);
  const isAscending = toDigits.every((d, i) => i === 0 || d >= toDigits[i-1]);
  const isDescending = toDigits.every((d, i) => i === 0 || d <= toDigits[i-1]);

  const reasons: string[] = [];
  let confidence = 0.5;
  let type: 'horizontal' | 'ascending' | 'descending';

  if (isHorizontal) {
    type = 'horizontal';
    reasons.push('Numbers at similar level');
    reasons.push('Small differences between adjacent digits');
    confidence += 0.3;
  } else if (isAscending) {
    type = 'ascending';
    reasons.push('Numbers in ascending order');
    reasons.push('Progressive increase in values');
    confidence += 0.3;
  } else {
    type = 'descending';
    reasons.push('Numbers in descending order');
    reasons.push('Progressive decrease in values');
    confidence += 0.3;
  }

  // Check for pattern preservation
  const fromDiffs = [fromDigits[1] - fromDigits[0], fromDigits[2] - fromDigits[1]];
  const toDiffs = [toDigits[1] - toDigits[0], toDigits[2] - toDigits[1]];
  
  if (fromDiffs.some((diff, i) => Math.abs(diff - toDiffs[i]) <= 1)) {
    reasons.push('Maintains similar digit relationships');
    confidence += 0.2;
  }

  return {
    from: fromPattern,
    to: toPattern,
    type,
    confidence: Math.min(confidence, 1),
    reasons
  };
}