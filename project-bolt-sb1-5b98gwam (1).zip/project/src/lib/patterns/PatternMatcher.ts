import { PatternRule, GridPosition, patternDefinitions } from './PatternDefinition';

export interface PatternMatch {
  pattern: PatternRule;
  confidence: number;
  matches: string[];
}

export class PatternMatcher {
  private grid: string[][];

  constructor() {
    this.grid = Array(10).fill(null).map(() => Array(3).fill(''));
  }

  // Initialize grid with a pattern
  initializeGrid(pattern: string) {
    const digits = pattern.split('').map(Number);
    
    for (let row = 0; row < 10; row++) {
      for (let col = 0; col < 3; col++) {
        this.grid[row][col] = ((digits[col] + row) % 10).toString();
      }
    }
  }

  // Get value at grid position
  private getValue(pos: GridPosition): string {
    return this.grid[pos.row][pos.col];
  }

  // Generate sequence based on progression type
  private generateSequence(baseNum: number, progression: PatternRule['progression'], increment: number): string[] {
    const sequence: string[] = [];
    let current = baseNum;

    for (let i = 0; i < 5; i++) {
      sequence.push(current.toString().padStart(3, '0'));
      current = (current + increment) % 1000;
    }

    return sequence;
  }

  // Match pattern against grid
  matchPattern(pattern: PatternRule): PatternMatch | null {
    // Get values at pattern positions
    const values = pattern.positions.map(pos => this.getValue(pos));
    
    // Check if values form a valid pattern
    const baseNum = parseInt(values.join(''));
    if (isNaN(baseNum)) return null;

    // Generate sequence based on pattern progression
    const matches = this.generateSequence(baseNum, pattern.progression, pattern.increment);

    // Calculate confidence based on pattern characteristics
    let confidence = 0.5;
    
    // Increase confidence for consistent progressions
    const diffs = matches.slice(1).map((num, i) => 
      parseInt(num) - parseInt(matches[i])
    );
    
    if (diffs.every(d => d === pattern.increment)) {
      confidence += 0.3;
    }

    // Increase confidence for position alignment
    const alignedPositions = pattern.positions.every(pos => 
      pos.row >= 0 && pos.row < 10 && pos.col >= 0 && pos.col < 3
    );
    
    if (alignedPositions) {
      confidence += 0.2;
    }

    return {
      pattern,
      confidence,
      matches
    };
  }

  // Find all matching patterns for a given input
  findPatterns(input: string): PatternMatch[] {
    // Initialize grid with input pattern
    this.initializeGrid(input);

    // Match against all pattern definitions
    const matches = patternDefinitions
      .map(pattern => this.matchPattern(pattern))
      .filter((match): match is PatternMatch => match !== null)
      .sort((a, b) => b.confidence - a.confidence);

    return matches;
  }
}