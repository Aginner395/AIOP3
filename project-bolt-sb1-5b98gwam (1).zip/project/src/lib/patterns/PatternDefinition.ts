// Types for pattern definitions
export interface GridPosition {
  row: number;
  col: number;
}

export interface PatternRule {
  name: string;
  description: string;
  positions: GridPosition[];
  progression: 'natural' | 'ai' | 'slashUp' | 'slashDown';
  increment: number;
}

// Pattern definitions
export const patternDefinitions: PatternRule[] = [
  {
    name: 'Neutral',
    description: 'Horizontal line pattern',
    positions: [
      { row: 4, col: 0 },
      { row: 4, col: 1 },
      { row: 4, col: 2 }
    ],
    progression: 'natural',
    increment: 111
  },
  {
    name: 'SlashUp',
    description: 'Diagonal ascending pattern',
    positions: [
      { row: 6, col: 0 },
      { row: 4, col: 1 },
      { row: 2, col: 2 }
    ],
    progression: 'slashUp',
    increment: 222
  },
  {
    name: 'SlashDown',
    description: 'Diagonal descending pattern',
    positions: [
      { row: 2, col: 0 },
      { row: 4, col: 1 },
      { row: 6, col: 2 }
    ],
    progression: 'slashDown',
    increment: 111
  },
  {
    name: 'Triangle↑',
    description: 'Upward triangle pattern',
    positions: [
      { row: 4, col: 0 },
      { row: 2, col: 1 },
      { row: 4, col: 2 }
    ],
    progression: 'ai',
    increment: 222
  },
  {
    name: 'Triangle↓',
    description: 'Downward triangle pattern',
    positions: [
      { row: 4, col: 0 },
      { row: 6, col: 1 },
      { row: 4, col: 2 }
    ],
    progression: 'ai',
    increment: 222
  }
];