// Common chart configuration
export const commonChartConfig = {
  grid: {
    strokeDasharray: '3 3',
    stroke: '#ccc'
  },
  axis: {
    stroke: '#888',
    strokeWidth: 1,
    fontSize: 12,
    fontFamily: 'system-ui',
    padding: { left: 20, right: 20 }
  },
  tooltip: {
    style: {
      backgroundColor: 'white',
      border: '1px solid #ccc',
      borderRadius: '4px',
      padding: '8px'
    }
  },
  legend: {
    verticalAlign: 'top' as const,
    height: 36,
    iconSize: 10,
    wrapperStyle: { paddingBottom: '10px' },
    align: 'center' as const,
    layout: 'horizontal' as const
  }
} as const;

// Pattern Analyzer chart configuration
export const patternAnalyzerConfig = {
  margin: { top: 20, right: 30, left: 10, bottom: 10 },
  grid: commonChartConfig.grid,
  xAxis: {
    ...commonChartConfig.axis,
    type: 'number' as const,
    domain: [1, 3],
    ticks: [1, 2, 3],
    allowDecimals: false
  },
  yAxis: {
    ...commonChartConfig.axis,
    type: 'number' as const,
    domain: [0, 9],
    ticks: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    allowDecimals: false
  },
  tooltip: commonChartConfig.tooltip,
  legend: commonChartConfig.legend,
  referenceLine: {
    stroke: '#666',
    strokeWidth: 1
  },
  lines: {
    input: { stroke: '#8884d8', name: 'Input' },
    output: { stroke: '#82ca9d', name: 'Output' },
    aiInput: { stroke: '#ffc658', name: 'AI Input' },
    aiOutput: { stroke: '#ff7300', name: 'AI Output' }
  }
} as const;

// Line configuration
export const lineConfig = {
  type: 'monotone' as const,
  strokeWidth: 2,
  dot: { r: 4 },
  activeDot: { r: 6 }
} as const;

// Pattern Learning chart configuration
export const patternLearningConfig = {
  grid: commonChartConfig.grid,
  axis: commonChartConfig.axis,
  tooltip: commonChartConfig.tooltip,
  legend: commonChartConfig.legend,
  lines: {
    input: { stroke: '#8884d8', name: 'Input' },
    output: { stroke: '#82ca9d', name: 'Output' },
    difference: { stroke: '#ffc658', name: 'Difference' }
  }
} as const;

// Dimensional Analysis chart configuration
export const dimensionalAnalysisConfig = {
  grid: commonChartConfig.grid,
  tooltip: commonChartConfig.tooltip,
  angleAxis: {
    ...commonChartConfig.axis,
    type: 'category' as const
  },
  radiusAxis: {
    angle: 30,
    domain: [0, 100],
    ...commonChartConfig.axis
  },
  radar: {
    patternScore: {
      name: 'Pattern Score',
      dataKey: 'score',
      stroke: '#8884d8',
      fill: '#8884d8',
      fillOpacity: 0.6
    },
    confidence: {
      name: 'Confidence',
      dataKey: 'confidence',
      stroke: '#82ca9d',
      fill: '#82ca9d',
      fillOpacity: 0.6
    }
  }
} as const;