// ... (keep all existing processors)

// AI Engine #6
export function processAI6(number: string): PatternResult[] {
  // Special case for triplets (000 or 555)
  if (number === "000" || number === "555") {
    const baseDigit = number === "000" ? naturalToAi['0'] : '5';
    return [
      baseDigit + baseDigit + baseDigit,
      '7' + baseDigit + '7',
      '9' + baseDigit + '9',
      '3' + baseDigit + '3'
    ].map(set => ({
      aiSet: set,
      patterns: generatePatterns(set),
      isKeyMatch: true
    }));
  }

  const middleKey = naturalToAi[number[1]]; // b value
  const firstDigit = naturalToAi[number[0]]; // a value
  const lastDigit = naturalToAi[number[2]];  // c value

  // Generate the sequence progression
  const patterns = [];
  let current = firstDigit + middleKey + lastDigit;
  patterns.push(current);

  // Generate next patterns in sequence
  for (let i = 0; i < 3; i++) {
    const [a, b, c] = patterns[i].split('');
    const nextA = naturalToAi[a];
    const nextC = naturalToAi[c];
    patterns.push(nextA + middleKey + nextC);
  }

  // Filter patterns where middleKey appears in position a or c
  const matchedPatterns = patterns.filter(pattern => {
    const [a, , c] = pattern.split('');
    return a === middleKey || c === middleKey;
  });

  // Generate variations for matched patterns
  const results: PatternResult[] = [];

  matchedPatterns.forEach(pattern => {
    const [a, b, c] = pattern.split('');

    // Add original pattern
    results.push({
      aiSet: pattern,
      patterns: generatePatterns(pattern),
      isKeyMatch: true
    });

    // Generate variations based on where middleKey appears
    if (a === middleKey) {
      // If middleKey is in position a, generate rotations
      results.push({
        aiSet: b + a + c,
        patterns: generatePatterns(b + a + c),
        isKeyMatch: true
      });
      results.push({
        aiSet: c + a + b,
        patterns: generatePatterns(c + a + b),
        isKeyMatch: true
      });
    }

    if (c === middleKey) {
      // If middleKey is in position c, generate rotations
      results.push({
        aiSet: c + a + b,
        patterns: generatePatterns(c + a + b),
        isKeyMatch: true
      });
      results.push({
        aiSet: b + c + a,
        patterns: generatePatterns(b + c + a),
        isKeyMatch: true
      });
    }
  });

  // Remove duplicates
  const uniqueResults = results.filter((result, index, self) =>
    index === self.findIndex(r => r.aiSet === result.aiSet)
  );

  return uniqueResults;
}