import { PatternCell } from '@/types/patterns';
import { detectShapes } from '@/lib/shapes/shapeDetector';

interface GridCalibration {
  baseRow: number;
  cellWeights: number[][];
  shapeAlignment: {
    offset: number;
    confidence: number;
  };
}

export class GridCalibrator {
  private readonly gridSize = 10;
  private readonly columnCount = 3;
  private weights: number[][] = [];

  constructor() {
    this.initializeWeights();
  }

  private initializeWeights() {
    this.weights = Array(this.gridSize)
      .fill(null)
      .map(() => Array(this.columnCount).fill(1));
  }

  public calibrate(patterns: string[]): GridCalibration {
    this.initializeWeights();
    let optimalBaseRow = 4; // Default center
    let totalConfidence = 0;
    let shapeOffset = 0;

    patterns.forEach(pattern => {
      const shapes = detectShapes(pattern);
      if (shapes.length === 0) return;

      const dominantShape = shapes[0];
      totalConfidence += dominantShape.confidence;

      // Adjust weights based on shape positions
      dominantShape.positions.forEach(([row, col]) => {
        // Increase weight for this position and adjacent cells
        for (let r = Math.max(0, row - 1); r <= Math.min(this.gridSize - 1, row + 1); r++) {
          for (let c = Math.max(0, col - 1); c <= Math.min(this.columnCount - 1, col + 1); c++) {
            this.weights[r][c] *= 1 + (dominantShape.confidence * 0.2);
          }
        }
      });

      // Calculate optimal base row
      const shapeCenter = dominantShape.positions.reduce(
        (sum, [row]) => sum + row, 
        0
      ) / dominantShape.positions.length;
      
      optimalBaseRow = Math.round(
        (optimalBaseRow + shapeCenter) / 2
      );

      // Calculate shape alignment offset
      const currentOffset = shapeCenter - optimalBaseRow;
      shapeOffset = (shapeOffset + currentOffset) / 2;
    });

    // Normalize weights
    const maxWeight = Math.max(...this.weights.flat());
    this.weights = this.weights.map(row =>
      row.map(weight => weight / maxWeight)
    );

    return {
      baseRow: Math.min(Math.max(optimalBaseRow, 2), 7), // Keep within reasonable bounds
      cellWeights: this.weights,
      shapeAlignment: {
        offset: shapeOffset,
        confidence: totalConfidence / patterns.length
      }
    };
  }

  public generateOptimalGrid(pattern: string, calibration: GridCalibration): PatternCell[] {
    const digits = pattern.split('').map(Number);
    const cells: PatternCell[] = [];

    // Generate base positions
    digits.forEach((digit, col) => {
      let optimalRow = calibration.baseRow;
      
      // Adjust row based on weights
      const columnWeights = calibration.cellWeights.map(row => row[col]);
      const weightedSum = columnWeights.reduce((sum, weight, row) => 
        sum + weight * row, 0
      );
      const weightedAvg = weightedSum / columnWeights.reduce((a, b) => a + b, 0);
      
      optimalRow = Math.round(
        optimalRow + 
        (weightedAvg - calibration.baseRow) * calibration.shapeAlignment.confidence
      );

      cells.push({
        row: Math.min(Math.max(optimalRow, 0), this.gridSize - 1),
        col,
        num: digit.toString()
      });
    });

    return cells;
  }
}