import { PatternResult } from '@/types/generator';
import { naturalToAi, aiBasePairs } from '@/lib/ai/constants';
import { detectShapes } from '@/lib/shapes/shapeDetector';

interface HistoricalPattern {
  pattern: string;
  frequency: number;
  shapes: string[];
  transitions: Record<string, number>;
  aiMatches: string[];
}

interface PatternAnalysis {
  patterns: HistoricalPattern[];
  shapeDistribution: Record<string, number>;
  transitionMatrix: Record<string, Record<string, number>>;
  confidenceScore: number;
}

export class PatternAnalyzer {
  private historicalData: string[] = [];
  private analysis: PatternAnalysis | null = null;

  constructor(data: string[]) {
    this.historicalData = data;
  }

  public analyze(): PatternAnalysis {
    const patterns: HistoricalPattern[] = [];
    const shapeDistribution: Record<string, number> = {};
    const transitionMatrix: Record<string, Record<string, number>> = {};

    // Process each pattern in historical data
    this.historicalData.forEach((pattern, index) => {
      // Detect shapes
      const shapes = detectShapes(pattern).map(s => s.name);
      shapes.forEach(shape => {
        shapeDistribution[shape] = (shapeDistribution[shape] || 0) + 1;
      });

      // Track transitions
      if (index < this.historicalData.length - 1) {
        const nextPattern = this.historicalData[index + 1];
        if (!transitionMatrix[pattern]) {
          transitionMatrix[pattern] = {};
        }
        transitionMatrix[pattern][nextPattern] = 
          (transitionMatrix[pattern][nextPattern] || 0) + 1;
      }

      // Find AI matches
      const aiMatches = this.findAIMatches(pattern);

      // Add to patterns array
      const existingPattern = patterns.find(p => p.pattern === pattern);
      if (existingPattern) {
        existingPattern.frequency++;
      } else {
        patterns.push({
          pattern,
          frequency: 1,
          shapes,
          transitions: {},
          aiMatches
        });
      }
    });

    // Calculate transition probabilities
    patterns.forEach(pattern => {
      if (transitionMatrix[pattern.pattern]) {
        const total = Object.values(transitionMatrix[pattern.pattern])
          .reduce((sum, count) => sum + count, 0);
        
        pattern.transitions = Object.entries(transitionMatrix[pattern.pattern])
          .reduce((acc, [next, count]) => ({
            ...acc,
            [next]: count / total
          }), {});
      }
    });

    // Calculate confidence score based on pattern consistency
    const confidenceScore = this.calculateConfidenceScore(patterns, shapeDistribution);

    this.analysis = {
      patterns: patterns.sort((a, b) => b.frequency - a.frequency),
      shapeDistribution,
      transitionMatrix,
      confidenceScore
    };

    return this.analysis;
  }

  private findAIMatches(pattern: string): string[] {
    const matches: string[] = [];
    const converted = pattern.split('').map(d => naturalToAi[d]);
    const [a, b, c] = converted;

    // Check base pairs
    if (aiBasePairs[a]) {
      const basePairs = aiBasePairs[a].split(',');
      basePairs.forEach(pair => {
        matches.push(pair + c);
      });
    }

    // Check rotations
    [[a, b, c], [c, a, b], [b, c, a]].forEach(rotation => {
      matches.push(rotation.join(''));
    });

    return [...new Set(matches)];
  }

  private calculateConfidenceScore(
    patterns: HistoricalPattern[],
    shapeDistribution: Record<string, number>
  ): number {
    let score = 0;
    const totalPatterns = patterns.reduce((sum, p) => sum + p.frequency, 0);

    // Factor 1: Pattern frequency distribution (30%)
    const frequencyScore = patterns.reduce((sum, pattern) => {
      const frequency = pattern.frequency / totalPatterns;
      return sum + (frequency * Math.log(1 / frequency));
    }, 0);
    score += (frequencyScore / Math.log(patterns.length)) * 0.3;

    // Factor 2: Shape consistency (40%)
    const totalShapes = Object.values(shapeDistribution)
      .reduce((sum, count) => sum + count, 0);
    const shapeScore = Object.values(shapeDistribution)
      .reduce((sum, count) => {
        const probability = count / totalShapes;
        return sum + (probability * Math.log(1 / probability));
      }, 0);
    score += (shapeScore / Math.log(Object.keys(shapeDistribution).length)) * 0.4;

    // Factor 3: Transition stability (30%)
    const transitionScore = patterns.reduce((sum, pattern) => {
      const transitions = Object.values(pattern.transitions);
      if (transitions.length === 0) return sum;
      
      const entropy = transitions.reduce((e, prob) => {
        return e + (prob * Math.log(1 / prob));
      }, 0);
      return sum + entropy;
    }, 0) / patterns.length;
    score += (1 - (transitionScore / Math.log(patterns.length))) * 0.3;

    return Math.min(Math.max(score, 0), 1);
  }

  public getPredictions(currentPattern: string, count: number = 5): {
    pattern: string;
    confidence: number;
    reasoning: string[];
  }[] {
    if (!this.analysis) {
      this.analyze();
    }

    const predictions: {
      pattern: string;
      confidence: number;
      reasoning: string[];
    }[] = [];

    // Get current pattern's shape
    const currentShapes = detectShapes(currentPattern).map(s => s.name);
    
    // Find similar patterns
    const similarPatterns = this.analysis!.patterns
      .filter(p => p.shapes.some(s => currentShapes.includes(s)))
      .slice(0, 10);

    // Generate predictions
    similarPatterns.forEach(pattern => {
      // Get most likely transitions
      const transitions = Object.entries(pattern.transitions)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 3);

      transitions.forEach(([nextPattern, probability]) => {
        const confidence = probability * 
          (pattern.frequency / this.historicalData.length) *
          this.analysis!.confidenceScore;

        const reasoning = [
          `Pattern ${pattern.pattern} transitions to ${nextPattern} with ${(probability * 100).toFixed(1)}% probability`,
          `Historical frequency: ${pattern.frequency} occurrences`,
          `Matching shapes: ${pattern.shapes.filter(s => currentShapes.includes(s)).join(', ')}`,
          `AI matches: ${pattern.aiMatches.length} potential combinations`
        ];

        predictions.push({
          pattern: nextPattern,
          confidence,
          reasoning
        });
      });
    });

    // Sort by confidence and return top predictions
    return predictions
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, count);
  }
}