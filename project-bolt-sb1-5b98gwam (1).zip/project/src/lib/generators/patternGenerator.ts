import { AIPattern } from '@/types/generator';
import { lArray, hArray } from '@/constants/conversion';

export const generatePatterns = (set: string) => ({
  lll: set.split('').map(d => lArray[d]).join(''),
  llh: lArray[set[0]] + lArray[set[1]] + hArray[set[2]],
  lhl: lArray[set[0]] + hArray[set[1]] + lArray[set[2]],
  lhh: lArray[set[0]] + hArray[set[1]] + hArray[set[2]]
});