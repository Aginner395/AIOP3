import { AISet } from '@/types/generator';
import { generatePatterns } from '../patternGenerator';

export abstract class BaseAIProcessor {
  protected createSet(type: string, aiSet: string): AISet {
    return {
      type,
      aiSet,
      patterns: generatePatterns(aiSet)
    };
  }

  abstract process(input: string): AISet[];
}