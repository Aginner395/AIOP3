import { AISet } from '@/types/generator';
import { naturalToAi, aiBasePairs } from '@/constants/conversion';
import { BaseAIProcessor } from './baseProcessor';

export class AI1Processor extends BaseAIProcessor {
  process(input: string): AISet[] {
    const converted = input.split('').map(d => naturalToAi[d]);
    const [a] = converted;
    const basePairs = aiBasePairs[a].split(',');
    
    return basePairs.map(pair => 
      this.createSet('AI#1', pair + a)
    );
  }
}