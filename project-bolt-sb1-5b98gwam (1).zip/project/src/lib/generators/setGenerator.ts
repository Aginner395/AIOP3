import { AISet } from '@/types/generator';
import { AI1Processor } from './aiProcessors';

export const generateAISets = (input: string): AISet[] => {
  const processors = [
    new AI1Processor(),
    // We'll add the other processors next
  ];

  return processors.flatMap(processor => processor.process(input));
};