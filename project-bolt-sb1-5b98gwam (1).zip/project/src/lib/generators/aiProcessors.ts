import { AISet } from '@/types/generator';
import { naturalToAi, aiBasePairs } from '@/constants/conversion';
import { generatePatterns } from './patternGenerator';

export const processAI1 = (input: string): AISet[] => {
  const converted = input.split('').map(d => naturalToAi[d]);
  const [a] = converted;
  const basePairs = aiBasePairs[a].split(',');
  
  const firstSets = basePairs.map(pair => pair + a);
  const nextSets = firstSets.map(set => {
    const lastDigit = set[2];
    return set.slice(0, 2) + naturalToAi[lastDigit];
  });

  return [...firstSets, ...nextSets].map(set => ({
    type: 'AI#1',
    aiSet: set,
    patterns: generatePatterns(set)
  }));
};

export const processAI2 = (input: string): AISet[] => {
  const converted = input.split('').map(d => naturalToAi[d]);
  const [a, b, c] = converted;
  const basePairs = aiBasePairs[a].split(',');
  
  // Match original HTML implementation
  return basePairs.flatMap(pair => [
    { type: 'AI#2', aiSet: pair + a, patterns: generatePatterns(pair + a) },
    { type: 'AI#2', aiSet: pair + b, patterns: generatePatterns(pair + b) },
    { type: 'AI#2', aiSet: pair + c, patterns: generatePatterns(pair + c) }
  ]);
};

export const processAI3 = (input: string): AISet[] => {
  const firstDigit = naturalToAi[input[0]];
  const basePairs = aiBasePairs[firstDigit].split(',');
  
  return basePairs.map(pair => ({
    type: 'AI#3',
    aiSet: pair + '7',
    patterns: generatePatterns(pair + '7')
  }));
};

export const processAI4 = (input: string): AISet[] => {
  const converted = input.split('').map(d => naturalToAi[d]);
  const [a, , c] = converted;
  const basePairs = aiBasePairs[a].split(',');
  
  return basePairs.map(pair => ({
    type: 'AI#4',
    aiSet: pair + c,
    patterns: generatePatterns(pair + c)
  }));
};