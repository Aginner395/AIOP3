export const SYSTEMS = ['ACR', 'CRL', 'ATRAX'] as const;

export const SYSTEM_COLORS = {
  ACR: {
    text: 'text-blue-600',
    bg: 'bg-blue-50', 
    border: 'border-blue-200'
  },
  CRL: {
    text: 'text-emerald-600',
    bg: 'bg-emerald-50',
    border: 'border-emerald-200'
  },
  ATRAX: {
    text: 'text-red-600',
    bg: 'bg-red-50',
    border: 'border-red-200'
  }
} as const;

export const getTierClass = (system: string) => {
  switch (system) {
    case 'ACR':
      return 'text-blue-600';
    case 'CRL':
      return 'text-emerald-600';
    case 'ATRAX':
      return 'text-red-600';
    default:
      return 'text-gray-600';
  }
};