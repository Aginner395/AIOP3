import type { PatternSet } from '@/types/generator';
import { naturalToAi } from '@/constants/patterns';

export const generatePatternSet = (basePattern: string): PatternSet => {
  // Example implementation - replace with actual logic
  return {
    basePattern,
    patterns: [
      { type: 'Natural', value: basePattern, probability: 40 },
      { type: 'AI Converted', value: convertToAI(basePattern), probability: 35 },
      { type: 'Reversed', value: reverse(basePattern), probability: 15 },
      { type: 'Mirrored', value: mirror(basePattern), probability: 10 }
    ],
    analysis: {
      distribution: [
        { type: 'Sequential', percentage: 45 },
        { type: 'Random', percentage: 30 },
        { type: 'Symmetric', percentage: 25 }
      ],
      insights: [
        'Strong sequential pattern detected',
        'Moderate symmetry in distribution',
        'Low entropy in number selection'
      ]
    }
  };
};

const convertToAI = (pattern: string): string => 
  pattern.split('').map(d => naturalToAi[d]).join('');

const reverse = (pattern: string): string => 
  pattern.split('').reverse().join('');

const mirror = (pattern: string): string => 
  pattern.split('').map(d => (9 - parseInt(d)).toString()).join('');