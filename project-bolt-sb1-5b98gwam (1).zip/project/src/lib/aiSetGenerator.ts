import { AISet, AIPatterns } from '@/types/generator';
import { naturalToAi, aiBasePairs } from '@/constants/patterns';

const lArray: Record<string, string> = {
  '5': '0', '7': '1', '9': '2', '1': '3', '3': '4'
};

const hArray: Record<string, string> = {
  '5': '5', '7': '6', '9': '7', '1': '8', '3': '9'
};

const generatePatterns = (set: string): AIPatterns => ({
  lll: set.split('').map(d => lArray[d]).join(''),
  llh: lArray[set[0]] + lArray[set[1]] + hArray[set[2]],
  lhl: lArray[set[0]] + hArray[set[1]] + lArray[set[2]],
  lhh: lArray[set[0]] + hArray[set[1]] + hArray[set[2]]
});

const generateSequentialSet = (start: string): string[] => {
  const result = [];
  let current = parseInt(start);
  
  for (let i = 0; i < 3; i++) {
    result.push(current.toString().padStart(3, '0'));
    current = (current + 1) % 1000;
  }
  
  return result;
};

const processAI1 = (input: string): AISet[] => {
  const converted = input.split('').map(d => naturalToAi[d]);
  const [a, b, c] = converted;
  
  // Generate sequential sets for each digit
  const sets = [a, b, c].map(digit => {
    const baseSet = generateSequentialSet(digit);
    return {
      type: 'AI#1',
      aiSet: baseSet.join(''),
      patterns: generatePatterns(baseSet.join(''))
    };
  });
  
  return sets;
};

const processAI2 = (input: string): AISet[] => {
  const converted = input.split('').map(d => naturalToAi[d]);
  const [a] = converted;
  const basePairs = aiBasePairs[a].split(',');
  
  return basePairs.map(pair => ({
    type: 'AI#2',
    aiSet: pair + a,
    patterns: generatePatterns(pair + a)
  }));
};

const processAI3 = (input: string): AISet[] => {
  const firstDigit = naturalToAi[input[0]];
  const basePairs = aiBasePairs[firstDigit].split(',');
  
  return basePairs.map(pair => ({
    type: 'AI#3',
    aiSet: pair + '7',
    patterns: generatePatterns(pair + '7')
  }));
};

const processAI4 = (input: string): AISet[] => {
  const converted = input.split('').map(d => naturalToAi[d]);
  const [a, , c] = converted;
  const basePairs = aiBasePairs[a].split(',');
  
  return basePairs.map(pair => ({
    type: 'AI#4',
    aiSet: pair + c,
    patterns: generatePatterns(pair + c)
  }));
};

export const generateAISets = (input: string): AISet[] => {
  return [
    ...processAI1(input),
    ...processAI2(input),
    ...processAI3(input),
    ...processAI4(input)
  ];
};