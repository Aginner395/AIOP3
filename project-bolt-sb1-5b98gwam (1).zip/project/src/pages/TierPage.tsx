import { TierAnalysis } from '@/components/tier/TierAnalysis';

export default function TierPage() {
  return (
    <div className="container mx-auto py-8">
      <TierAnalysis />
    </div>
  );
}